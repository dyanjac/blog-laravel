<?php




if(count($portadas) > 0 )
{
	for ( $p=0; count($portadas) > $p ; $p++ ) 
	{

		echo $portadas[$p]->titulo ."<br>";


	}	

}

?><?php /**PATH C:\xampp\htdocs\blog\resources\views/test.blade.php ENDPATH**/ ?>
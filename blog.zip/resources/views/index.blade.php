

<html lang="es" prefix="og: https://ogp.me/ns#" class=" td-md-is-android td-md-is-chrome js_active  vc_mobile  vc_transform  vc_transform "><!--<![endif]--><head>
    <title>Noticiero TI & Telecom.</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="pingback" href="https://www.itwarelatam.com/xmlrpc.php">


    <!-- <script src="https://js.hscollectedforms.net/collectedforms.js" type="text/javascript" id="CollectedForms-7620000" crossorigin="anonymous" data-leadin-portal-id="7620000" data-leadin-env="prod" data-loader="hs-scriptloader" data-hsjs-portal="7620000" data-hsjs-env="prod"></script> -->

  <!--   <script src="https://js.hs-banner.com/7620000.js" type="text/javascript" id="cookieBanner-7620000" data-loader="hs-scriptloader" data-hsjs-portal="7620000" data-hsjs-env="prod"></script> -->

   <!--  <script src="https://js.hs-analytics.net/analytics/1603237500000/7620000.js" type="text/javascript" id="hs-analytics"></script>

    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/T9w1ROdplctW2nVKvNJYXH8o/recaptcha__es.js" crossorigin="anonymous" integrity="sha384-MgfjyuYPFemW7JNYDwx1bnt99ZJXCsQRzsCsjAkr2XaTBYltrk+PJk7Ck7gsG9Ml"></script>

    <script src="https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101"></script> -->

    <script src="https://www.itwarelatam.com/wp-includes/js/wp-emoji-release.min.js?ver=5.5.1" type="text/javascript" defer=""></script>
    <!-- <script src="https://cdn.onesignal.com/sdks/OneSignalPageSDKES6.js?v=151104" async=""></script>
    <style>._3emE9--dark-theme .-S-tR--ff-downloader{background:rgba(30,30,30,.93);border:1px solid rgba(82,82,82,.54);box-shadow:0 4px 7px rgba(30,30,30,.55);color:#fff}._3emE9--dark-theme .-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn{background:#3d4b52}._3emE9--dark-theme .-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn:hover{background:#131415}._3emE9--dark-theme .-S-tR--ff-downloader ._10vpG--footer{background:rgba(30,30,30,.93)}._2mDEx--white-theme .-S-tR--ff-downloader{background:#fff;border:1px solid rgba(82,82,82,.54);box-shadow:0 4px 7px rgba(30,30,30,.55);color:#314c75}._2mDEx--white-theme .-S-tR--ff-downloader ._6_Mtt--header{font-weight:700}._2mDEx--white-theme .-S-tR--ff-downloader ._2dFLA--container ._2bWNS--notice{border:0;color:rgba(0,0,0,.88)}._2mDEx--white-theme .-S-tR--ff-downloader ._10vpG--footer{background:#fff}.-S-tR--ff-downloader{display:block;overflow:hidden;position:fixed;bottom:20px;right:7.1%;width:330px;height:180px;background:rgba(30,30,30,.93);border-radius:2px;color:#fff;z-index:99999999;border:1px solid rgba(82,82,82,.54);box-shadow:0 4px 7px rgba(30,30,30,.55);transition:.5s}.-S-tR--ff-downloader._3M7UQ--minimize{height:62px}.-S-tR--ff-downloader._3M7UQ--minimize .nxuu4--file-info,.-S-tR--ff-downloader._3M7UQ--minimize ._6_Mtt--header{display:none}.-S-tR--ff-downloader ._6_Mtt--header{padding:10px;font-size:17px;font-family:sans-serif}.-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn{float:right;background:#f1ecec;height:20px;width:20px;text-align:center;padding:2px;margin-top:-10px;cursor:pointer}.-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn:hover{background:#e2dede}.-S-tR--ff-downloader ._13XQ2--error{color:red;padding:10px;font-size:12px;line-height:19px}.-S-tR--ff-downloader ._2dFLA--container{position:relative;height:100%}.-S-tR--ff-downloader ._2dFLA--container .nxuu4--file-info{padding:6px 15px 0;font-family:sans-serif}.-S-tR--ff-downloader ._2dFLA--container .nxuu4--file-info div{margin-bottom:5px;width:100%;overflow:hidden}.-S-tR--ff-downloader ._2dFLA--container ._2bWNS--notice{margin-top:21px;font-size:11px}.-S-tR--ff-downloader ._10vpG--footer{width:100%;bottom:0;position:absolute;font-weight:700}.-S-tR--ff-downloader ._10vpG--footer ._2V73d--loader{animation:n0BD1--rotation 3.5s linear forwards;position:absolute;top:-120px;left:calc(50% - 35px);border-radius:50%;border:5px solid #fff;border-top-color:#a29bfe;height:70px;width:70px;display:flex;justify-content:center;align-items:center}.-S-tR--ff-downloader ._10vpG--footer ._24wjw--loading-bar{width:100%;height:18px;background:#dfe6e9;border-radius:5px}.-S-tR--ff-downloader ._10vpG--footer ._24wjw--loading-bar ._1FVu9--progress-bar{height:100%;background:#8bc34a;border-radius:5px}.-S-tR--ff-downloader ._10vpG--footer ._2KztS--status{margin-top:10px}.-S-tR--ff-downloader ._10vpG--footer ._2KztS--status ._1XilH--state{float:left;font-size:.9em;letter-spacing:1pt;text-transform:uppercase;width:100px;height:20px;position:relative}.-S-tR--ff-downloader ._10vpG--footer ._2KztS--status ._1jiaj--percentage{float:right}</style></head><body data-rsssl="1" class="home page-template-default page page-id-19946 global-block-template-3 td-tech wpb-js-composer js-comp-ver-6.0.5 vc_responsive td-boxed-layout td-js-loaded" itemscope="itemscope" itemtype="https://schema.org/WebPage"><button class="sgpb-corner-bottom-left sgpb-floating-button sg-popup-id-29154" style="font-size: 16px;border-width: 5px;border-style: solid;border-radius: 5px;border-color: #5263eb;background-color: #fb0d6a;color: #ffffff;" data-popup-id="29154"><span class="sgpb-corner-floating-button-text">PulsoIT live</span></button><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1585781235461{background-color: #70b9ea !important;}.vc_custom_1585794527182{background-image: url(https://www.itwarelatam.com/wp-content/uploads/2020/04/Ciberseguridad-fondo.jpeg?id=26888) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1585781994098{background-color: #70b9ea !important;}.vc_custom_1585781193564{background-color: #70b9ea !important;}.vc_custom_1586051327594{padding-top: 10px !important;padding-right: 10px !important;padding-bottom: 10px !important;padding-left: 10px !important;background-color: #e8e8e8 !important;}</style>
 -->

    	<!-- Jetpack Site Verification Tags -->

<link rel="icon" type="image/png" href="https://www.itwarelatam.com/wp-content/uploads/2017/06/favicon-01.png"><link rel="apple-touch-icon-precomposed" sizes="76x76" href="https://www.itwarelatam.com/wp-content/uploads/2017/06/76.png">
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://www.itwarelatam.com/wp-content/uploads/2017/06/120.png">
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://www.itwarelatam.com/wp-content/uploads/2017/06/152.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://www.itwarelatam.com/wp-content/uploads/2017/06/114.png">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://www.itwarelatam.com/wp-content/uploads/2017/06/144.png">
<!-- All In One SEO Pack 3.7.1ob_start_detected [-1,-1] -->
<meta name="description" content="ITware es un sitio sobre tecnología de la innovación (IT) aplicada a negocios del sector.">
<meta name="keywords" content="ITware, Enfasys, CIO , Latin America Magazine, Revista de Tecnología, innovacion.">
<meta name="google-site-verification" content="xnR0zF3asxIH_529HxOTUzcS6sGHGZDW-tJlv0ujJCo">

<!-- <script type="application/ld+json" class="aioseop-schema">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://www.itwarelatam.com/#organization","url":"https://www.itwarelatam.com/","name":"ITwareLatam","sameAs":["https://www.facebook.com/ITwareLatam","https://www.twitter.com/ITwareLatam","https://www.youtube.com/channel/UC3-rBoUbepvSobpmo9w4OmQ","",""]},{"@type":"WebSite","@id":"https://www.itwarelatam.com/#website","url":"https://www.itwarelatam.com/","name":"ITware Latam","publisher":{"@id":"https://www.itwarelatam.com/#organization"}},{"@type":"WebPage","@id":"https://www.itwarelatam.com#webpage","url":"https://www.itwarelatam.com","inLanguage":"es","name":"ITware Latam","isPartOf":{"@id":"https://www.itwarelatam.com/#website"},"breadcrumb":{"@id":"https://www.itwarelatam.com#breadcrumblist"},"description":"ITware es un sitio sobre tecnología de la innovación (IT) aplicada a negocios del sector.","image":{"@type":"ImageObject","@id":"https://www.itwarelatam.com#primaryimage","url":"https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2017/06/logo_ITW_-Gradient.jpg?fit=616%2C616&ssl=1","width":616,"height":616},"primaryImageOfPage":{"@id":"https://www.itwarelatam.com#primaryimage"},"datePublished":"2017-06-09T19:13:25-03:00","dateModified":"2020-10-06T14:06:33-03:00","about":{"@id":"https://www.itwarelatam.com/#organization"}},{"@type":"BreadcrumbList","@id":"https://www.itwarelatam.com#breadcrumblist","itemListElement":[{"@type":"ListItem","position":1,"item":{"@type":"WebPage","@id":"https://www.itwarelatam.com/","url":"https://www.itwarelatam.com/","name":"ITware Latam"}}]}]}</script> -->
<link rel="canonical" href="https://www.itwarelatam.com/">
<meta property="og:type" content="website">
<meta property="og:title" content="ITware Latam | Noticias del Sector IT en Latinoamérica.">
<meta property="og:description" content="ITware es un sitio sobre tecnología de la innovación (IT) aplicada a negocios del sector.">
<meta property="og:url" content="https://www.itwarelatam.com/">
<meta property="og:site_name" content="ITware Latam">
<meta property="og:image" content="https://www.itwarelatam.com/wp-content/uploads/2017/06/logo_ITW_grey.jpg">
<meta property="fb:admins" content="https://graph.facebook.com/ITwareLatam">
<meta property="fb:app_id" content="www.facebook.com/ITwareLatam/">
<meta property="og:image:secure_url" content="https://www.itwarelatam.com/wp-content/uploads/2017/06/logo_ITW_grey.jpg">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@itwarelatam">
<meta name="twitter:domain" content="https://www.itwarelatam.com">
<meta name="twitter:title" content="ITware Latam | Noticias del Sector IT en Latinoamérica.">
<meta name="twitter:description" content="ITware es un sitio sobre tecnología de la innovación (IT) aplicada a negocios del sector.">
<meta name="twitter:image" content="https://www.itwarelatam.com/wp-content/uploads/2017/06/logo_ITW_grey.jpg">
			<!-- <script type="text/javascript"> -->
				<!-- window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date; -->
				<!-- ga('create', 'UA-45864188-1', { 'cookieDomain': 'www.itwarelatam.com' } ); -->
				<!-- // Plugins -->
				<!-- ga('require', 'displayfeatures');ga('require', 'outboundLinkTracker'); -->
				<!-- ga('send', 'pageview'); -->
			<!-- </script> -->
			<!-- <script async="" src="https://www.google-analytics.com/analytics.js"></script>
 -->		<!-- 	<script async="" src="https://www.itwarelatam.com/wp-content/plugins/all-in-one-seo-pack/public/js/vendor/autotrack.js?ver=3.7.1"></script> -->
				<!-- All In One SEO Pack -->
<!-- <link rel="dns-prefetch" href="//js.hs-scripts.com">
<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="dns-prefetch" href="//s.w.org">
<link rel="dns-prefetch" href="//v0.wordpress.com">
<link rel="dns-prefetch" href="//i0.wp.com">
<link rel="dns-prefetch" href="//i1.wp.com">
<link rel="dns-prefetch" href="//i2.wp.com">
<link rel="dns-prefetch" href="//c0.wp.com"> -->
<link rel="alternate" type="application/rss+xml" title="ITware Latam » Feed" href="https://www.itwarelatam.com/feed/">
<link rel="alternate" type="application/rss+xml" title="ITware Latam » Feed de los comentarios" href="https://www.itwarelatam.com/comments/feed/">
<link rel="alternate" type="application/rss+xml" title="ITware Latam » Comentario Home del feed" href="https://www.itwarelatam.com/home/feed/">
	<!-- 	<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.itwarelatam.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.1"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script> -->
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>


 {!!Html::style('assets/css/theme.css?ver=3.69.3')!!}

 {!!Html::style('assets/css/style.css?ver=72ece2de773553959e5098a544851753')!!}
 

<link crossorigin="anonymous" rel="stylesheet" id="google-fonts-style-css" href="https://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400%2C400italic%2C600%2C600italic%2C700%7CNova+Slim%3A400%7CRoboto%3A300%2C400%2C400italic%2C500%2C500italic%2C700%2C900&amp;ver=9.0.1" type="text/css" media="all">
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-css'  href='https://www.itwarelatam.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.5' type='text/css' media='screen' />
<![endif]-->


<link rel="stylesheet" id="js_composer_front-css" href="https://www.itwarelatam.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.0.5" type="text/css" media="all">
{!!Html::style('assets/themes/Newspaper/style.css?ver=9.0.1')!!}
{!!Html::style('assets/css/jetpack.css')!!}



{!!Html::script('assets/js/jquery.js')!!}
{!!Html::style('assets/css/jetpack.css')!!}


{!!Html::script('assets/js/Popup.js?ver=3.69.3')!!}
{!!Html::script('assets/js/PopupConfig.js?ver=3.69.3')!!}


{!!Html::script('assets/js/PopupBuilder.js?ver=3.69.3')!!}

<!-- <link rel="https://api.w.org/" href="https://www.itwarelatam.com/wp-json/">
<link rel="alternate" type="application/json" href="https://www.itwarelatam.com/wp-json/wp/v2/pages/19946">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.itwarelatam.com/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.itwarelatam.com/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 5.5.1">
<link rel="shortlink" href="https://www.itwarelatam.com/"> -->

<script>
	

</script>
			<script type="text/javascript">
				var _hsq = _hsq || [];
				_hsq.push(["setContentType", "standard-page"]);
			</script>
			<!-- DO NOT COPY THIS SNIPPET! End of Page Analytics Tracking for HubSpot WordPress plugin -->
						<script>
				(function() {
					var hbspt = window.hbspt = window.hbspt || {};
					hbspt.forms = hbspt.forms || {};
					hbspt._wpFormsQueue = [];
					hbspt.enqueueForm = function(formDef) {
						if (hbspt.forms && hbspt.forms.create) {
							hbspt.forms.create(formDef);
						} else {
							hbspt._wpFormsQueue.push(formDef);
						}
					}
					Object.defineProperty(window.hbspt.forms, 'create', {
						configurable: true,
						get: function() {
							return hbspt._wpCreateForm;
						},
						set: function(value) {
							hbspt._wpCreateForm = value;
							for (var i = 0; i < hbspt._wpFormsQueue.length; i++) {
								var formDef = hbspt._wpFormsQueue[i];
								hbspt._wpCreateForm.call(hbspt.forms, formDef);
							}
						},
					})
				})();
			</script>
		<style type="text/css">img#wpstats{display:none}</style>			<script>
				window.tdwGlobal = {"adminUrl":"https:\/\/www.itwarelatam.com\/wp-admin\/","wpRestNonce":"573bdab015","wpRestUrl":"https:\/\/www.itwarelatam.com\/wp-json\/","permalinkStructure":"\/%year%\/%monthnum%\/%day%\/%postname%\/"};
			</script>
	



<script>
    
    

	    var tdBlocksArray = []; //here we store all the items for the current page

	    //td_block class - each ajax block uses a object of this class for requests
	    function tdBlock() {
		    this.id = '';
		    this.block_type = 1; //block type id (1-234 etc)
		    this.atts = '';
		    this.td_column_number = '';
		    this.td_current_page = 1; //
		    this.post_count = 0; //from wp
		    this.found_posts = 0; //from wp
		    this.max_num_pages = 0; //from wp
		    this.td_filter_value = ''; //current live filter value
		    this.is_ajax_running = false;
		    this.td_user_action = ''; // load more or infinite loader (used by the animation)
		    this.header_color = '';
		    this.ajax_pagination_infinite_stop = ''; //show load more at page x
	    }


        // td_js_generator - mini detector
        (function(){
            var htmlTag = document.getElementsByTagName("html")[0];

	        if ( navigator.userAgent.indexOf("MSIE 10.0") > -1 ) {
                htmlTag.className += ' ie10';
            }

            if ( !!navigator.userAgent.match(/Trident.*rv\:11\./) ) {
                htmlTag.className += ' ie11';
            }

	        if ( navigator.userAgent.indexOf("Edge") > -1 ) {
                htmlTag.className += ' ieEdge';
            }

            if ( /(iPad|iPhone|iPod)/g.test(navigator.userAgent) ) {
                htmlTag.className += ' td-md-is-ios';
            }

            var user_agent = navigator.userAgent.toLowerCase();
            if ( user_agent.indexOf("android") > -1 ) {
                htmlTag.className += ' td-md-is-android';
            }

            if ( -1 !== navigator.userAgent.indexOf('Mac OS X')  ) {
                htmlTag.className += ' td-md-is-os-x';
            }

            if ( /chrom(e|ium)/.test(navigator.userAgent.toLowerCase()) ) {
               htmlTag.className += ' td-md-is-chrome';
            }

            if ( -1 !== navigator.userAgent.indexOf('Firefox') ) {
                htmlTag.className += ' td-md-is-firefox';
            }

            if ( -1 !== navigator.userAgent.indexOf('Safari') && -1 === navigator.userAgent.indexOf('Chrome') ) {
                htmlTag.className += ' td-md-is-safari';
            }

            if( -1 !== navigator.userAgent.indexOf('IEMobile') ){
                htmlTag.className += ' td-md-is-iemobile';
            }

        })();




        var tdLocalCache = {};

        ( function () {
            "use strict";

            tdLocalCache = {
                data: {},
                remove: function (resource_id) {
                    delete tdLocalCache.data[resource_id];
                },
                exist: function (resource_id) {
                    return tdLocalCache.data.hasOwnProperty(resource_id) && tdLocalCache.data[resource_id] !== null;
                },
                get: function (resource_id) {
                    return tdLocalCache.data[resource_id];
                },
                set: function (resource_id, cachedData) {
                    tdLocalCache.remove(resource_id);
                    tdLocalCache.data[resource_id] = cachedData;
                }
            };
        })();

    
    
var td_viewport_interval_list=[{"limitBottom":767,"sidebarWidth":228},{"limitBottom":1018,"sidebarWidth":300},{"limitBottom":1140,"sidebarWidth":324}];
var td_animation_stack_effect="type0";
var tds_animation_stack=true;
var td_animation_stack_specific_selectors=".entry-thumb, img";
var td_animation_stack_general_selectors=".td-animation-stack img, .td-animation-stack .entry-thumb, .post img";
var td_ajax_url="https:\/\/www.itwarelatam.com\/wp-admin\/admin-ajax.php?td_theme_name=Newspaper&v=9.0.1";
var td_get_template_directory_uri="https:\/\/www.itwarelatam.com\/wp-content\/themes\/Newspaper";
var tds_snap_menu="snap";
var tds_logo_on_sticky="";
var tds_header_style="10";
var td_please_wait="Por favor espera...";
var td_email_user_pass_incorrect="Usuario o contrase\u00f1a incorrecta!";
var td_email_user_incorrect="Correo electr\u00f3nico o nombre de usuario incorrecto!";
var td_email_incorrect="Correo electr\u00f3nico incorrecto!";
var tds_more_articles_on_post_enable="show";
var tds_more_articles_on_post_time_to_wait="3";
var tds_more_articles_on_post_pages_distance_from_top=1200;
var tds_theme_color_site_wide="#009dcc";
var tds_smart_sidebar="enabled";
var tdThemeName="Newspaper";
var td_magnific_popup_translation_tPrev="Anterior (tecla de flecha izquierda)";
var td_magnific_popup_translation_tNext="Siguiente (tecla de flecha derecha)";
var td_magnific_popup_translation_tCounter="%curr% de %total%";
var td_magnific_popup_translation_ajax_tError="El contenido de %url% no pudo cargarse.";
var td_magnific_popup_translation_image_tError="La imagen #%curr% no pudo cargarse.";
var tdDateNamesI18n={"month_names":["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"],"month_names_short":["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"],"day_names":["domingo","lunes","martes","mi\u00e9rcoles","jueves","viernes","s\u00e1bado"],"day_names_short":["Dom","Lun","Mar","Mi\u00e9","Jue","Vie","S\u00e1b"]};
var td_ad_background_click_link="";
var td_ad_background_click_target="";
</script>


<!-- Header style compiled by theme -->

<style>
    

		body {
			background-color:white;
		}
		.td-header-wrap .black-menu .sf-menu > .current-menu-item > a,
		    .td-header-wrap .black-menu .sf-menu > .current-menu-ancestor > a,
		    .td-header-wrap .black-menu .sf-menu > .current-category-ancestor > a,
		    .td-header-wrap .black-menu .sf-menu > li > a:hover,
		    .td-header-wrap .black-menu .sf-menu > .sfHover > a,
		    .td-header-style-12 .td-header-menu-wrap-full,
		    .sf-menu > .current-menu-item > a:after,
		    .sf-menu > .current-menu-ancestor > a:after,
		    .sf-menu > .current-category-ancestor > a:after,
		    .sf-menu > li:hover > a:after,
		    .sf-menu > .sfHover > a:after,
		    .td-header-style-12 .td-affix,
		    .header-search-wrap .td-drop-down-search:after,
		    .header-search-wrap .td-drop-down-search .btn:hover,
		    input[type=submit]:hover,
		    .td-read-more a,
		    .td-post-category:hover,
		    .td-grid-style-1.td-hover-1 .td-big-grid-post:hover .td-post-category,
		    .td-grid-style-5.td-hover-1 .td-big-grid-post:hover .td-post-category,
		    .td_top_authors .td-active .td-author-post-count,
		    .td_top_authors .td-active .td-author-comments-count,
		    .td_top_authors .td_mod_wrap:hover .td-author-post-count,
		    .td_top_authors .td_mod_wrap:hover .td-author-comments-count,
		    .td-404-sub-sub-title a:hover,
		    .td-search-form-widget .wpb_button:hover,
		    .td-rating-bar-wrap div,
		    .td_category_template_3 .td-current-sub-category,
		    .dropcap,
		    .td_wrapper_video_playlist .td_video_controls_playlist_wrapper,
		    .wpb_default,
		    .wpb_default:hover,
		    .td-left-smart-list:hover,
		    .td-right-smart-list:hover,
		    .woocommerce-checkout .woocommerce input.button:hover,
		    .woocommerce-page .woocommerce a.button:hover,
		    .woocommerce-account div.woocommerce .button:hover,
		    #bbpress-forums button:hover,
		    .bbp_widget_login .button:hover,
		    .td-footer-wrapper .td-post-category,
		    .td-footer-wrapper .widget_product_search input[type="submit"]:hover,
		    .woocommerce .product a.button:hover,
		    .woocommerce .product #respond input#submit:hover,
		    .woocommerce .checkout input#place_order:hover,
		    .woocommerce .woocommerce.widget .button:hover,
		    .single-product .product .summary .cart .button:hover,
		    .woocommerce-cart .woocommerce table.cart .button:hover,
		    .woocommerce-cart .woocommerce .shipping-calculator-form .button:hover,
		    .td-next-prev-wrap a:hover,
		    .td-load-more-wrap a:hover,
		    .td-post-small-box a:hover,
		    .page-nav .current,
		    .page-nav:first-child > div,
		    .td_category_template_8 .td-category-header .td-category a.td-current-sub-category,
		    .td_category_template_4 .td-category-siblings .td-category a:hover,
		    #bbpress-forums .bbp-pagination .current,
		    #bbpress-forums #bbp-single-user-details #bbp-user-navigation li.current a,
		    .td-theme-slider:hover .slide-meta-cat a,
		    a.vc_btn-black:hover,
		    .td-trending-now-wrapper:hover .td-trending-now-title,
		    .td-scroll-up,
		    .td-smart-list-button:hover,
		    .td-weather-information:before,
		    .td-weather-week:before,
		    .td_block_exchange .td-exchange-header:before,
		    .td_block_big_grid_9.td-grid-style-1 .td-post-category,
		    .td_block_big_grid_9.td-grid-style-5 .td-post-category,
		    .td-grid-style-6.td-hover-1 .td-module-thumb:after,
		    .td-pulldown-syle-2 .td-subcat-dropdown ul:after,
		    .td_block_template_9 .td-block-title:after,
		    .td_block_template_15 .td-block-title:before,
		    div.wpforms-container .wpforms-form div.wpforms-submit-container button[type=submit] {
		        background-color: #009dcc;
		    }

		    .td_block_template_4 .td-related-title .td-cur-simple-item:before {
		        border-color: #009dcc transparent transparent transparent !important;
		    }

		    .woocommerce .woocommerce-message .button:hover,
		    .woocommerce .woocommerce-error .button:hover,
		    .woocommerce .woocommerce-info .button:hover {
		        background-color: #009dcc !important;
		    }
		    
		    
		    .td_block_template_4 .td-related-title .td-cur-simple-item,
		    .td_block_template_3 .td-related-title .td-cur-simple-item,
		    .td_block_template_9 .td-related-title:after {
		        background-color: #009dcc;
		    }

		    .woocommerce .product .onsale,
		    .woocommerce.widget .ui-slider .ui-slider-handle {
		        background: none #009dcc;
		    }

		    .woocommerce.widget.widget_layered_nav_filters ul li a {
		        background: none repeat scroll 0 0 #009dcc !important;
		    }

		    a,
		    cite a:hover,
		    .td_mega_menu_sub_cats .cur-sub-cat,
		    .td-mega-span h3 a:hover,
		    .td_mod_mega_menu:hover .entry-title a,
		    .header-search-wrap .result-msg a:hover,
		    .td-header-top-menu .td-drop-down-search .td_module_wrap:hover .entry-title a,
		    .td-header-top-menu .td-icon-search:hover,
		    .td-header-wrap .result-msg a:hover,
		    .top-header-menu li a:hover,
		    .top-header-menu .current-menu-item > a,
		    .top-header-menu .current-menu-ancestor > a,
		    .top-header-menu .current-category-ancestor > a,
		    .td-social-icon-wrap > a:hover,
		    .td-header-sp-top-widget .td-social-icon-wrap a:hover,
		    .td-page-content blockquote p,
		    .td-post-content blockquote p,
		    .mce-content-body blockquote p,
		    .comment-content blockquote p,
		    .wpb_text_column blockquote p,
		    .td_block_text_with_title blockquote p,
		    .td_module_wrap:hover .entry-title a,
		    .td-subcat-filter .td-subcat-list a:hover,
		    .td-subcat-filter .td-subcat-dropdown a:hover,
		    .td_quote_on_blocks,
		    .dropcap2,
		    .dropcap3,
		    .td_top_authors .td-active .td-authors-name a,
		    .td_top_authors .td_mod_wrap:hover .td-authors-name a,
		    .td-post-next-prev-content a:hover,
		    .author-box-wrap .td-author-social a:hover,
		    .td-author-name a:hover,
		    .td-author-url a:hover,
		    .td_mod_related_posts:hover h3 > a,
		    .td-post-template-11 .td-related-title .td-related-left:hover,
		    .td-post-template-11 .td-related-title .td-related-right:hover,
		    .td-post-template-11 .td-related-title .td-cur-simple-item,
		    .td-post-template-11 .td_block_related_posts .td-next-prev-wrap a:hover,
		    .comment-reply-link:hover,
		    .logged-in-as a:hover,
		    #cancel-comment-reply-link:hover,
		    .td-search-query,
		    .td-category-header .td-pulldown-category-filter-link:hover,
		    .td-category-siblings .td-subcat-dropdown a:hover,
		    .td-category-siblings .td-subcat-dropdown a.td-current-sub-category,
		    .widget a:hover,
		    .td_wp_recentcomments a:hover,
		    .archive .widget_archive .current,
		    .archive .widget_archive .current a,
		    .widget_calendar tfoot a:hover,
		    .woocommerce a.added_to_cart:hover,
		    .woocommerce-account .woocommerce-MyAccount-navigation a:hover,
		    #bbpress-forums li.bbp-header .bbp-reply-content span a:hover,
		    #bbpress-forums .bbp-forum-freshness a:hover,
		    #bbpress-forums .bbp-topic-freshness a:hover,
		    #bbpress-forums .bbp-forums-list li a:hover,
		    #bbpress-forums .bbp-forum-title:hover,
		    #bbpress-forums .bbp-topic-permalink:hover,
		    #bbpress-forums .bbp-topic-started-by a:hover,
		    #bbpress-forums .bbp-topic-started-in a:hover,
		    #bbpress-forums .bbp-body .super-sticky li.bbp-topic-title .bbp-topic-permalink,
		    #bbpress-forums .bbp-body .sticky li.bbp-topic-title .bbp-topic-permalink,
		    .widget_display_replies .bbp-author-name,
		    .widget_display_topics .bbp-author-name,
		    .footer-text-wrap .footer-email-wrap a,
		    .td-subfooter-menu li a:hover,
		    .footer-social-wrap a:hover,
		    a.vc_btn-black:hover,
		    .td-smart-list-dropdown-wrap .td-smart-list-button:hover,
		    .td_module_17 .td-read-more a:hover,
		    .td_module_18 .td-read-more a:hover,
		    .td_module_19 .td-post-author-name a:hover,
		    .td-instagram-user a,
		    .td-pulldown-syle-2 .td-subcat-dropdown:hover .td-subcat-more span,
		    .td-pulldown-syle-2 .td-subcat-dropdown:hover .td-subcat-more i,
		    .td-pulldown-syle-3 .td-subcat-dropdown:hover .td-subcat-more span,
		    .td-pulldown-syle-3 .td-subcat-dropdown:hover .td-subcat-more i,
		    .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-display-option:hover,
		    .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-display-option:hover i,
		    .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-link:hover,
		    .td-block-title-wrap .td-wrapper-pulldown-filter .td-pulldown-filter-item .td-cur-simple-item,
		    .td_block_template_2 .td-related-title .td-cur-simple-item,
		    .td_block_template_5 .td-related-title .td-cur-simple-item,
		    .td_block_template_6 .td-related-title .td-cur-simple-item,
		    .td_block_template_7 .td-related-title .td-cur-simple-item,
		    .td_block_template_8 .td-related-title .td-cur-simple-item,
		    .td_block_template_9 .td-related-title .td-cur-simple-item,
		    .td_block_template_10 .td-related-title .td-cur-simple-item,
		    .td_block_template_11 .td-related-title .td-cur-simple-item,
		    .td_block_template_12 .td-related-title .td-cur-simple-item,
		    .td_block_template_13 .td-related-title .td-cur-simple-item,
		    .td_block_template_14 .td-related-title .td-cur-simple-item,
		    .td_block_template_15 .td-related-title .td-cur-simple-item,
		    .td_block_template_16 .td-related-title .td-cur-simple-item,
		    .td_block_template_17 .td-related-title .td-cur-simple-item,
		    .td-theme-wrap .sf-menu ul .td-menu-item > a:hover,
		    .td-theme-wrap .sf-menu ul .sfHover > a,
		    .td-theme-wrap .sf-menu ul .current-menu-ancestor > a,
		    .td-theme-wrap .sf-menu ul .current-category-ancestor > a,
		    .td-theme-wrap .sf-menu ul .current-menu-item > a,
		    .td_outlined_btn {
		        color: #009dcc;
		    }

		    a.vc_btn-black.vc_btn_square_outlined:hover,
		    a.vc_btn-black.vc_btn_outlined:hover,
		    .td-mega-menu-page .wpb_content_element ul li a:hover,
		    .td-theme-wrap .td-aj-search-results .td_module_wrap:hover .entry-title a,
		    .td-theme-wrap .header-search-wrap .result-msg a:hover {
		        color: #009dcc !important;
		    }

		    .td-next-prev-wrap a:hover,
		    .td-load-more-wrap a:hover,
		    .td-post-small-box a:hover,
		    .page-nav .current,
		    .page-nav:first-child > div,
		    .td_category_template_8 .td-category-header .td-category a.td-current-sub-category,
		    .td_category_template_4 .td-category-siblings .td-category a:hover,
		    #bbpress-forums .bbp-pagination .current,
		    .post .td_quote_box,
		    .page .td_quote_box,
		    a.vc_btn-black:hover,
		    .td_block_template_5 .td-block-title > *,
		    .td_outlined_btn {
		        border-color: #009dcc;
		    }

		    .td_wrapper_video_playlist .td_video_currently_playing:after {
		        border-color: #009dcc !important;
		    }

		    .header-search-wrap .td-drop-down-search:before {
		        border-color: transparent transparent #009dcc transparent;
		    }

		    .block-title > span,
		    .block-title > a,
		    .block-title > label,
		    .widgettitle,
		    .widgettitle:after,
		    .td-trending-now-title,
		    .td-trending-now-wrapper:hover .td-trending-now-title,
		    .wpb_tabs li.ui-tabs-active a,
		    .wpb_tabs li:hover a,
		    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab.vc_active > a,
		    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab:hover > a,
		    .td_block_template_1 .td-related-title .td-cur-simple-item,
		    .woocommerce .product .products h2:not(.woocommerce-loop-product__title),
		    .td-subcat-filter .td-subcat-dropdown:hover .td-subcat-more, 
		    .td_3D_btn,
		    .td_shadow_btn,
		    .td_default_btn,
		    .td_round_btn, 
		    .td_outlined_btn:hover {
		    	background-color: #009dcc;
		    }

		    .woocommerce div.product .woocommerce-tabs ul.tabs li.active {
		    	background-color: #009dcc !important;
		    }

		    .block-title,
		    .td_block_template_1 .td-related-title,
		    .wpb_tabs .wpb_tabs_nav,
		    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container,
		    .woocommerce div.product .woocommerce-tabs ul.tabs:before {
		        border-color: #009dcc;
		    }
		    .td_block_wrap .td-subcat-item a.td-cur-simple-item {
			    color: #009dcc;
			}


		    
		    .td-grid-style-4 .entry-title
		    {
		        background-color: rgba(0, 157, 204, 0.7);
		    }

		    
		    .block-title > span,
		    .block-title > span > a,
		    .block-title > a,
		    .block-title > label,
		    .widgettitle,
		    .widgettitle:after,
		    .td-trending-now-title,
		    .td-trending-now-wrapper:hover .td-trending-now-title,
		    .wpb_tabs li.ui-tabs-active a,
		    .wpb_tabs li:hover a,
		    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab.vc_active > a,
		    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab:hover > a,
		    .td_block_template_1 .td-related-title .td-cur-simple-item,
		    .woocommerce .product .products h2:not(.woocommerce-loop-product__title),
		    .td-subcat-filter .td-subcat-dropdown:hover .td-subcat-more,
		    .td-weather-information:before,
		    .td-weather-week:before,
		    .td_block_exchange .td-exchange-header:before,
		    .td-theme-wrap .td_block_template_3 .td-block-title > *,
		    .td-theme-wrap .td_block_template_4 .td-block-title > *,
		    .td-theme-wrap .td_block_template_7 .td-block-title > *,
		    .td-theme-wrap .td_block_template_9 .td-block-title:after,
		    .td-theme-wrap .td_block_template_10 .td-block-title::before,
		    .td-theme-wrap .td_block_template_11 .td-block-title::before,
		    .td-theme-wrap .td_block_template_11 .td-block-title::after,
		    .td-theme-wrap .td_block_template_14 .td-block-title,
		    .td-theme-wrap .td_block_template_15 .td-block-title:before,
		    .td-theme-wrap .td_block_template_17 .td-block-title:before {
		        background-color: #293b54;
		    }

		    .woocommerce div.product .woocommerce-tabs ul.tabs li.active {
		    	background-color: #293b54 !important;
		    }

		    .block-title,
		    .td_block_template_1 .td-related-title,
		    .wpb_tabs .wpb_tabs_nav,
		    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container,
		    .woocommerce div.product .woocommerce-tabs ul.tabs:before,
		    .td-theme-wrap .td_block_template_5 .td-block-title > *,
		    .td-theme-wrap .td_block_template_17 .td-block-title,
		    .td-theme-wrap .td_block_template_17 .td-block-title::before {
		        border-color: #293b54;
		    }

		    .td-theme-wrap .td_block_template_4 .td-block-title > *:before,
		    .td-theme-wrap .td_block_template_17 .td-block-title::after {
		        border-color: #293b54 transparent transparent transparent;
		    }
		    
		    .td-theme-wrap .td_block_template_4 .td-related-title .td-cur-simple-item:before {
		        border-color: #293b54 transparent transparent transparent !important;
		    }

		    
		    .sf-menu > .current-menu-item > a:after,
		    .sf-menu > .current-menu-ancestor > a:after,
		    .sf-menu > .current-category-ancestor > a:after,
		    .sf-menu > li:hover > a:after,
		    .sf-menu > .sfHover > a:after,
		    .td_block_mega_menu .td-next-prev-wrap a:hover,
		    .td-mega-span .td-post-category:hover,
		    .td-header-wrap .black-menu .sf-menu > li > a:hover,
		    .td-header-wrap .black-menu .sf-menu > .current-menu-ancestor > a,
		    .td-header-wrap .black-menu .sf-menu > .sfHover > a,
		    .header-search-wrap .td-drop-down-search:after,
		    .header-search-wrap .td-drop-down-search .btn:hover,
		    .td-header-wrap .black-menu .sf-menu > .current-menu-item > a,
		    .td-header-wrap .black-menu .sf-menu > .current-menu-ancestor > a,
		    .td-header-wrap .black-menu .sf-menu > .current-category-ancestor > a {
		        background-color: #2189ce;
		    }


		    .td_block_mega_menu .td-next-prev-wrap a:hover {
		        border-color: #2189ce;
		    }

		    .header-search-wrap .td-drop-down-search:before {
		        border-color: transparent transparent #2189ce transparent;
		    }

		    .td_mega_menu_sub_cats .cur-sub-cat,
		    .td_mod_mega_menu:hover .entry-title a,
		    .td-theme-wrap .sf-menu ul .td-menu-item > a:hover,
		    .td-theme-wrap .sf-menu ul .sfHover > a,
		    .td-theme-wrap .sf-menu ul .current-menu-ancestor > a,
		    .td-theme-wrap .sf-menu ul .current-category-ancestor > a,
		    .td-theme-wrap .sf-menu ul .current-menu-item > a {
		        color: #2189ce;
		    }
		    
		    
		    
		    @media (max-width: 767px) {
		        body .td-header-wrap .td-header-main-menu {
		            background-color: #003a4f !important;
		        }
		    }


		    
		    .td-menu-background:before,
		    .td-search-background:before {
		        background: #36a9e1;
		        background: -moz-linear-gradient(top, #36a9e1 0%, #844893 100%);
		        background: -webkit-gradient(left top, left bottom, color-stop(0%, #36a9e1), color-stop(100%, #844893));
		        background: -webkit-linear-gradient(top, #36a9e1 0%, #844893 100%);
		        background: -o-linear-gradient(top, #36a9e1 0%, @mobileu_gradient_two_mob 100%);
		        background: -ms-linear-gradient(top, #36a9e1 0%, #844893 100%);
		        background: linear-gradient(to bottom, #36a9e1 0%, #844893 100%);
		        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#36a9e1', endColorstr='#844893', GradientType=0 );
		    }

		    
		    .td-banner-wrap-full,
		    .td-header-style-11 .td-logo-wrap-full {
		        background-color: #f7f7f7;
		    }

		    .td-header-style-11 .td-logo-wrap-full {
		        border-bottom: 0;
		    }

		    @media (min-width: 1019px) {
		        .td-header-style-2 .td-header-sp-recs,
		        .td-header-style-5 .td-a-rec-id-header > div,
		        .td-header-style-5 .td-g-rec-id-header > .adsbygoogle,
		        .td-header-style-6 .td-a-rec-id-header > div,
		        .td-header-style-6 .td-g-rec-id-header > .adsbygoogle,
		        .td-header-style-7 .td-a-rec-id-header > div,
		        .td-header-style-7 .td-g-rec-id-header > .adsbygoogle,
		        .td-header-style-8 .td-a-rec-id-header > div,
		        .td-header-style-8 .td-g-rec-id-header > .adsbygoogle,
		        .td-header-style-12 .td-a-rec-id-header > div,
		        .td-header-style-12 .td-g-rec-id-header > .adsbygoogle {
		            margin-bottom: 24px !important;
		        }
		    }

		    @media (min-width: 768px) and (max-width: 1018px) {
		        .td-header-style-2 .td-header-sp-recs,
		        .td-header-style-5 .td-a-rec-id-header > div,
		        .td-header-style-5 .td-g-rec-id-header > .adsbygoogle,
		        .td-header-style-6 .td-a-rec-id-header > div,
		        .td-header-style-6 .td-g-rec-id-header > .adsbygoogle,
		        .td-header-style-7 .td-a-rec-id-header > div,
		        .td-header-style-7 .td-g-rec-id-header > .adsbygoogle,
		        .td-header-style-8 .td-a-rec-id-header > div,
		        .td-header-style-8 .td-g-rec-id-header > .adsbygoogle,
		        .td-header-style-12 .td-a-rec-id-header > div,
		        .td-header-style-12 .td-g-rec-id-header > .adsbygoogle {
		            margin-bottom: 14px !important;
		        }
		    }

		     
		    .td-footer-wrapper::before {
		        background-image: url('');
		    }

		    
		    .td-footer-wrapper::before {
		        background-size: 100% auto;
		    }

		    
		    .top-header-menu > li > a,
		    .td-weather-top-widget .td-weather-now .td-big-degrees,
		    .td-weather-top-widget .td-weather-header .td-weather-city,
		    .td-header-sp-top-menu .td_data_time {
		        font-family:"Nova Slim";
			
		    }
		    
		    ul.sf-menu > .td-menu-item > a,
		    .td-theme-wrap .td-header-menu-social {
		        font-family:"Open Sans";
			font-weight:300;
			
		    }
		    
		    .block-title > span,
		    .block-title > a,
		    .widgettitle,
		    .td-trending-now-title,
		    .wpb_tabs li a,
		    .vc_tta-container .vc_tta-color-grey.vc_tta-tabs-position-top.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tab > a,
		    .td-theme-wrap .td-related-title a,
		    .woocommerce div.product .woocommerce-tabs ul.tabs li a,
		    .woocommerce .product .products h2:not(.woocommerce-loop-product__title),
		    .td-theme-wrap .td-block-title {
		        font-family:"Open Sans";
			
		    }
		    
		    .td-excerpt,
		    .td_module_14 .td-excerpt {
		        font-family:"Open Sans";
			font-size:13px;
			line-height:21px;
			
		    }


			
			.post .td-post-header .entry-title {
				font-family:"Open Sans";
			
			}
		    
		    .td-post-template-default .td-post-header .entry-title {
		        font-family:"Open Sans";
			font-weight:300;
			
		    }
		    
		    .td-post-content p,
		    .td-post-content {
		        font-family:"Open Sans";
			font-size:17px;
			line-height:31px;
			
		    }
		    
		    .td-post-template-default .td-post-sub-title,
		    .td-post-template-1 .td-post-sub-title,
		    .td-post-template-4 .td-post-sub-title,
		    .td-post-template-5 .td-post-sub-title,
		    .td-post-template-9 .td-post-sub-title,
		    .td-post-template-10 .td-post-sub-title,
		    .td-post-template-11 .td-post-sub-title {
		        font-size:18px;
			line-height:26px;
			font-style:normal;
			font-weight:600;
			
		    }
</style>


<!-- Button style compiled by theme -->

<style>
    .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > .current-category-ancestor > a,
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > .current-menu-ancestor > a,
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > .current-menu-item > a,
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > .sfHover > a,
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > li > a:hover,
                .tdm_block_column_content:hover .tdm-col-content-title-url .tdm-title,
                .tds-button2 .tdm-btn-text,
                .tds-button2 i,
                .tds-button5:hover .tdm-btn-text,
                .tds-button5:hover i,
                .tds-button6 .tdm-btn-text,
                .tds-button6 i,
                .tdm_block_list .tdm-list-item i,
                .tdm_block_pricing .tdm-pricing-feature i,
                .tdm-social-item i {
                  color: #009dcc;
                }
                .tdm-menu-active-style5 .td-header-menu-wrap .sf-menu > .current-menu-item > a,
                .tdm-menu-active-style5 .td-header-menu-wrap .sf-menu > .current-menu-ancestor > a,
                .tdm-menu-active-style5 .td-header-menu-wrap .sf-menu > .current-category-ancestor > a,
                .tdm-menu-active-style5 .td-header-menu-wrap .sf-menu > li > a:hover,
                .tdm-menu-active-style5 .td-header-menu-wrap .sf-menu > .sfHover > a,
                .tds-button1,
                .tds-button6:after,
                .tds-title2 .tdm-title-line:after,
                .tds-title3 .tdm-title-line:after,
                .tdm_block_pricing.tdm-pricing-featured:before,
                .tdm_block_pricing.tds_pricing2_block.tdm-pricing-featured .tdm-pricing-header,
                .tds-progress-bar1 .tdm-progress-bar:after,
                .tds-progress-bar2 .tdm-progress-bar:after,
                .tds-social3 .tdm-social-item {
                  background-color: #009dcc;
                }
                .tdm-menu-active-style4 .tdm-header .sf-menu > .current-menu-item > a,
                .tdm-menu-active-style4 .tdm-header .sf-menu > .current-menu-ancestor > a,
                .tdm-menu-active-style4 .tdm-header .sf-menu > .current-category-ancestor > a,
                .tdm-menu-active-style4 .tdm-header .sf-menu > li > a:hover,
                .tdm-menu-active-style4 .tdm-header .sf-menu > .sfHover > a,
                .tds-button2:before,
                .tds-button6:before,
                .tds-progress-bar3 .tdm-progress-bar:after {
                  border-color: #009dcc;
                }
                .tdm-btn-style1 {
					background-color: #009dcc;
				}
				.tdm-btn-style2:before {
				    border-color: #009dcc;
				}
				.tdm-btn-style2 {
				    color: #009dcc;
				}
				.tdm-btn-style3 {
				    -webkit-box-shadow: 0 2px 16px #009dcc;
                    -moz-box-shadow: 0 2px 16px #009dcc;
                    box-shadow: 0 2px 16px #009dcc;
				}
				.tdm-btn-style3:hover {
				    -webkit-box-shadow: 0 4px 26px #009dcc;
                    -moz-box-shadow: 0 4px 26px #009dcc;
                    box-shadow: 0 4px 26px #009dcc;
				}
				
				
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > .current-menu-item > a,
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > .current-menu-ancestor > a,
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > .current-category-ancestor > a,
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > li > a:hover,
                .tdm-menu-active-style3 .tdm-header.td-header-wrap .sf-menu > .sfHover > a {
                  color: #2189ce;
                }
                .tdm-menu-active-style4 .tdm-header .sf-menu > .current-menu-item > a,
                .tdm-menu-active-style4 .tdm-header .sf-menu > .current-menu-ancestor > a,
                .tdm-menu-active-style4 .tdm-header .sf-menu > .current-category-ancestor > a,
                .tdm-menu-active-style4 .tdm-header .sf-menu > li > a:hover,
                .tdm-menu-active-style4 .tdm-header .sf-menu > .sfHover > a {
                  border-color: #2189ce;
                }
                .tdm-menu-active-style5 .tdm-header .td-header-menu-wrap .sf-menu > .current-menu-item > a,
                .tdm-menu-active-style5 .tdm-header .td-header-menu-wrap .sf-menu > .current-menu-ancestor > a,
                .tdm-menu-active-style5 .tdm-header .td-header-menu-wrap .sf-menu > .current-category-ancestor > a,
                .tdm-menu-active-style5 .tdm-header .td-header-menu-wrap .sf-menu > li > a:hover,
                .tdm-menu-active-style5 .tdm-header .td-header-menu-wrap .sf-menu > .sfHover > a {
                  background-color: #2189ce;
                }
</style>

<noscript>

	<style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>	

	<style id="tdw-css-placeholder"></style>



        <div class="td-scroll-up"><i class="td-icon-menu-up"></i></div>
    
    <div class="td-menu-background" style="height: 711px;"></div>
	<div id="td-mobile-nav" style="min-height: 641px;">

    <div class="td-mobile-container">
        <!-- mobile menu top section -->
        <div class="td-menu-socials-wrap">
            <!-- socials -->
            <div class="td-menu-socials">
                
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.facebook.com/ITwareLatam/" title="Facebook">
                <i class="td-icon-font td-icon-facebook"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.linkedin.com/company/itwarelatam" title="Linkedin">
                <i class="td-icon-font td-icon-linkedin"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.itwarelatam.com/feed" title="RSS">
                <i class="td-icon-font td-icon-rss"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.twitter.com/ITwareLatam" title="Twitter">
                <i class="td-icon-font td-icon-twitter"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.youtube.com/itwarelatam" title="Youtube">
                <i class="td-icon-font td-icon-youtube"></i>
            </a>
        </span>            </div>
            <!-- close button -->
            <div class="td-mobile-close">
                <a href="#"><i class="td-icon-close-mobile"></i></a>
            </div>
        </div>

        <!-- login section -->
        
        <!-- menu section -->
			<div class="td-mobile-content">
				 <div class="menu-menu-principal-container">
				 	<ul id="menu-menu-principal" class="td-mobile-main-menu">
				 		<li id="menu-item-19960" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-19946 current_page_item menu-item-first menu-item-19960"><a href="https://http://www.caracasdigital.com/">Newsletter</a></li>

						<li id="menu-item-19962" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19962"><a href="https://http://www.caracasdigital.com/category/corporativo/">Susribirse</a></li>
						<li id="menu-item-19963" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19963"><a href="https://http://www.caracasdigital.com/category/empresas-2/">Negocios &amp; Mercadeo </a></li>
						<li id="menu-item-19964" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19964"><a href="https://http://www.caracasdigital.com/category/productos/">Copa Telecom</a></li>
						<li id="menu-item-19965" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19965"><a href="https://http://www.caracasdigital.com/category/software_y_servicios/">Big data</a></li>
						<li id="menu-item-19966" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19966"><a href="https://http://www.caracasdigital.com/category/canales/">Quienes Somos</a></li>
						<li id="menu-item-25706" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25706"><a href="https://http://www.caracasdigital.com/cybersecurity/">Contactenos</a></li> <!-- -->
					</ul>
				</div>
			</div>
    </div>

    <!-- register/login section -->
    </div>    
    <div class="td-search-background" style="height: 711px;"></div>
		<div class="td-search-wrap-mob">
			<div class="td-drop-down-search" aria-labelledby="td-header-search-button">
				<form method="get" class="td-search-form" action="https://www.itwarelatam.com/">
					<!-- close button -->
					<div class="td-search-close">
						<a href="#"><i class="td-icon-close-mobile"></i></a>
					</div>
					<div role="search" class="td-search-input">
						<span>Buscar</span>
						<input id="td-header-search-mob" type="text" value="" name="s" autocomplete="off">
					</div>
				</form>
				<div id="td-aj-search-mob"></div>
			</div>
		</div>    
    
    <div id="td-outer-wrap" class="td-theme-wrap">
    
        <!--
Header style 10
-->






	<center> <img src="http://www.caracasdigital.com/baner/Abside-950X75-new-CD.gif"></center>
	<center> <img src="http://www.caracasdigital.com/baner/Banner CaracasDigital.jpg"></center>





<div class="td-header-wrap td-header-style-10 ">
    
	<div class="td-header-top-menu-full td-container-wrap td_stretch_container">
		<div class="td-container td-header-row td-header-top-menu">
            <!-- LOGIN MODAL -->
		</div>
	</div>

    <div class="td-banner-wrap-full td-logo-wrap-full td-logo-mobile-loaded td-container-wrap td_stretch_container">
		

		<div id="td_uid_27_5f8f778c757cc" class="tdc-row">
<div class="vc_row td_uid_119_5f8f778c757d6_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_119_5f8f778c757d6_rand {
                    min-height: 0;
                }
</style>
		
<!-- <div class="vc_column td_uid_120_5f8f778c759d9_rand  wpb_column vc_column_container tdc-column td-pb-span12">
		<div class="wpb_wrapper">
			<div class="wpb_wrapper td_block_single_image td_block_wrap  td_block_wrap vc_single_image td_uid_121_5f8f778c75b1c_rand  td-single-image- td-pb-border-top td_block_template_3"><a class="td_single_image_bg" style="background-image: url('http://www.caracasdigital.com/baner/Abside-950X75-new-CD.gif'); background-size: cover; background-repeat: no-repeat; background-position: center center;" href="https://www.facebook.com/ITwareLatam/" target="_blank" rel="bookmark"></a>
				<style>
				/* custom css */
				.td_uid_121_5f8f778c75b1c_rand .td_single_image_bg {
									height: 65px;
									padding-bottom: 0;
								}
				</style>
			</div>
			<div class="wpb_wrapper td_block_single_image td_block_wrap  td_block_wrap vc_single_image td_uid_121_5f8f778c75b1c_rand  td-single-image- "><a class="td_single_image_bg" style="background-image: url('http://www.caracasdigital.com/baner/Abside-950X75-new-CD.gif'); background-size: cover; background-repeat: no-repeat; background-position: center center;" href="https://www.facebook.com/ITwareLatam/" target="_blank" rel="bookmark"></a>
				<style>
				/* custom css */
				.td_uid_121_5f8f778c75b1c_rand .td_single_image_bg {
									height: 65px;
									padding-bottom: 0;
								}
				</style>
			</div>

		</div>
	</div> -->

	<div class="vc_column td_uid_120_5f8f778c759d9_rand  wpb_column vc_column_container tdc-column td-pb-span4">
		<div class="wpb_wrapper">
			<div class="wpb_wrapper td_block_single_image td_block_wrap  td_block_wrap vc_single_image td_uid_121_5f8f778c75b0c_rand  td-single-image- td-pb-border-top td_block_template_3">
				<div class="td-header-sp-logo"   >
		    <h1 class="td-logo">		
		       <a class="td-main-logo" href="http://www.caracasdigital.com/" >
				 <img class="td-retina-data td-retina-version" data-retina="http://caracasdigital.com/images/caracasdigital.gif" src="http://caracasdigital.com/images/caracasdigital.gif" style="margin-top: 25px; " alt="ITware Latam. Noticias del sector IT en Latinoamérica." title="ITware Latam. Noticias del sector IT en Latinoamérica." width="300">
					<span class="td-visual-hidden">Caracas Digiral</span>
				</a>
			</h1>  
    			
		</div>

				<!-- <a class="td_single_image_bg" style="background-image: url('https://store.compudiskett.com.pe/images/caracasdigital.gif'); background-size: cover; background-repeat: no-repeat; background-position: center center;" href="https://www.facebook.com/ITwareLatam/" target="_blank" rel="bookmark"></a> -->
				<style>
				/* custom css */
				.td_uid_121_5f8f778c75b0c_rand .td_single_image_bg {
									height: 170px;
									padding-bottom: 0;
								}
				</style>
			</div>

		</div>
	</div>

	<div class="vc_column td_uid_120_5f8f778c759d9_rand  wpb_column vc_column_container tdc-column td-pb-span5">
		<div class="wpb_wrapper">
			<div class="wpb_wrapper td_block_single_image td_block_wrap  td_block_wrap vc_single_image td_uid_121_5f8f778c75b9c_rand  td-single-image- td-pb-border-top td_block_template_3" style="margin-top: 25px;">

				<a class="td_single_image_bg" style="background-image: url('http://www.caracasdigital.com/baner/Abside-950X75-new-CD.gif'); background-size: 468px; background-repeat: no-repeat; background-position: center center;" href="https://www.facebook.com/ITwareLatam/" target="_blank" rel="bookmark"></a>
				<style>
				/* custom css */
				.td_uid_121_5f8f778c75b9c_rand .td_single_image_bg {
									height: 60px;
									width: 468px;
									margin-top: : 25px;
									padding-bottom: 0;
								}
				</style>
			</div>

		</div>
	</div>

	<div class="vc_column td_uid_122_5f8f778c7cad0_rand  wpb_column vc_column_container tdc-column td-pb-span3"><div class="wpb_wrapper">
		<div class="wpb_wrapper td_block_wrap vc_raw_html td_uid_123_5f8f778c7cc02_rand " style="height: 60;margin-top: 25px;"><div class="td-fix-index">

		<div class="td-drop-down-search td-drop-down-search-open"  style="max-width:200px; ">
		            <form method="get" class="td-search-form" action="https://www.itwarelatam.com/">
		                <div role="search" class="td-head-form-search-wrap">


		                 <input id="td-header-search" type="text" value="" name="s" autocomplete="off">
		                 
		                  <div  class="wpb_button btn" style="width:20px;margin-top: 15px; "> <svg style="width:20px;"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50"><path d="M 21 3 C 11.601563 3 4 10.601563 4 20 C 4 29.398438 11.601563 37 21 37 C 24.355469 37 27.460938 36.015625 30.09375 34.34375 L 42.375 46.625 L 46.625 42.375 L 34.5 30.28125 C 36.679688 27.421875 38 23.878906 38 20 C 38 10.601563 30.398438 3 21 3 Z M 21 7 C 28.199219 7 34 12.800781 34 20 C 34 27.199219 28.199219 33 21 33 C 13.800781 33 8 27.199219 8 20 C 8 12.800781 13.800781 7 21 7 Z"></path></svg></div>
		                </div>
		            </form>
		            <div id="td-aj-search"></div>
        	</div>

	</div></div></div>
	</div>
</div>
</div>

	
		<!-- <div class="td-header-sp-logo"  style="background-color: blue;" >
		    <h1 class="td-logo" style="position: relative;" >		
		      
				<center> <img   src="http://www.caracasdigital.com/baner/Banner CaracasDigital.jpg" style="width:468px;height:60px;margin-top: 0px; margin-top:10%; "></center>
				
			</h1>  
    			
		</div>

		

		<div class="td-drop-down-search td-drop-down-search-open"  style="margin-top: -100px;margin-right:22%;max-width:180px;  ">
		            <form method="get" class="td-search-form" action="https://www.itwarelatam.com/">
		                <div role="search" class="td-head-form-search-wrap">


		                 <input id="td-header-search" type="text" value="" name="s" autocomplete="off">
		                 
		                  <div  class="wpb_button btn" style="width:20px;margin-top: 15px; "> <svg style="width:20px;"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50"><path d="M 21 3 C 11.601563 3 4 10.601563 4 20 C 4 29.398438 11.601563 37 21 37 C 24.355469 37 27.460938 36.015625 30.09375 34.34375 L 42.375 46.625 L 46.625 42.375 L 34.5 30.28125 C 36.679688 27.421875 38 23.878906 38 20 C 38 10.601563 30.398438 3 21 3 Z M 21 7 C 28.199219 7 34 12.800781 34 20 C 34 27.199219 28.199219 33 21 33 C 13.800781 33 8 27.199219 8 20 C 8 12.800781 13.800781 7 21 7 Z"></path></svg></div>
		                </div>
		            </form>
		            <div id="td-aj-search"></div>
        	</div>  -->

		
        	<!-- BANNER TOP -->
        	

    </div>

	<div class="td-header-menu-wrap-full td-container-wrap td_stretch_container" style="height: 54px;">
        
        <div class="td-header-menu-wrap td-header-gradient ">
			<div class="td-container td-header-row td-header-main-menu">
				<div id="td-header-menu" role="navigation">
    <div id="td-top-mobile-toggle"><a href="#"><i class="td-icon-font td-icon-mobile"></i></a></div>

    <div class="td-main-menu-logo td-logo-in-header" >
        <a class="td-mobile-logo td-sticky-disable" href="https://www.itwarelatam.com/">
				<img class="td-retina-data td-retina-version" data-retina="http://www.caracasdigital.com/images/caracasdigital-nm.png" src="http://www.caracasdigital.com/images/caracasdigital-nm.png" alt="ITware Latam. Noticias del sector IT en Latinoamérica." title="ITware Latam. Noticias del sector IT en Latinoamérica.">
			</a>

			<a class="td-header-logo td-sticky-disable" href="https://www.itwarelatam.com/">
				<img class="td-retina-data td-retina-version" data-retina="https://store.compudiskett.com.pe/images/caracasdigital.gif" src="https://store.compudiskett.com.pe/images/caracasdigital.gif" alt="ITware Latam. Noticias del sector IT en Latinoamérica." title="ITware Latam. Noticias del sector IT en Latinoamérica." style="margin-bottom: 25px;">
			</a>
	    </div>

    <div class="menu-menu-principal-container">

    	<ul id="menu-menu-principal-1" class="sf-menu sf-js-enabled"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-19946 current_page_item menu-item-first td-menu-item td-normal-menu menu-item-19960"><a href="https://http://www.caracasdigital.com/">Newsletter</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-19962"><a href="https://http://www.caracasdigital.com/category/corporativo/">Susribirse</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-19963"><a href="https://http://www.caracasdigital.com/category/empresas-2/">Negocios &amp; Mercadeo</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-19964"><a href="https://http://www.caracasdigital.com/category/productos/">Copa Telecom</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-19965"><a href="https://http://www.caracasdigital.com/category/software_y_servicios/">Big data</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category td-menu-item td-normal-menu menu-item-19966"><a href="https://http://www.caracasdigital.com/category/canales/">Quienes Somos</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page td-menu-item td-normal-menu menu-item-25706"><a href="https://http://www.caracasdigital.com/cybersecurity/">Contactenos</a></li>
</ul>
					

</div></div>


    <div class="header-search-wrap">
        <div class="td-search-btns-wrap">
            <a id="td-header-search-button" href="#" role="button" class="dropdown-toggle " data-toggle="dropdown"><i class="td-icon-search" style="width:20px;margin-top: 15px;display:none;  " ></i>
            	<!-- <svg style="width:20px;margin-top: 15px; " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50"><path d="M 21 3 C 11.601563 3 4 10.601563 4 20 C 4 29.398438 11.601563 37 21 37 C 24.355469 37 27.460938 36.015625 30.09375 34.34375 L 42.375 46.625 L 46.625 42.375 L 34.5 30.28125 C 36.679688 27.421875 38 23.878906 38 20 C 38 10.601563 30.398438 3 21 3 Z M 21 7 C 28.199219 7 34 12.800781 34 20 C 34 27.199219 28.199219 33 21 33 C 13.800781 33 8 27.199219 8 20 C 8 12.800781 13.800781 7 21 7 Z"></path></svg> -->
            </a>
           
            <a id="td-header-search-button-mob" href="#" role="button" class="dropdown-toggle " data-toggle="dropdown" style="" ><i class="td-icon-search"></i>

            	<!-- <svg  style="width:20px;margin-top:15px;  " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50"><path d="M 21 3 C 11.601563 3 4 10.601563 4 20 C 4 29.398438 11.601563 37 21 37 C 24.355469 37 27.460938 36.015625 30.09375 34.34375 L 42.375 46.625 L 46.625 42.375 L 34.5 30.28125 C 36.679688 27.421875 38 23.878906 38 20 C 38 10.601563 30.398438 3 21 3 Z M 21 7 C 28.199219 7 34 12.800781 34 20 C 34 27.199219 28.199219 33 21 33 C 13.800781 33 8 27.199219 8 20 C 8 12.800781 13.800781 7 21 7 Z"></path></svg> -->
            </a>
        </div>

        <div class="td-drop-down-search" aria-labelledby="td-header-search-button">
            <form method="get" class="td-search-form" action="https://www.itwarelatam.com/">
                <div role="search" class="td-head-form-search-wrap">
                    <input id="td-header-search" type="text" value="" name="s" autocomplete="off"><input class="wpb_button wpb_btn-inverse btn" type="submit" id="td-header-search-top" value="Buscar">
                </div>
            </form>
            <div id="td-aj-search"></div>
        </div>
    </div>
			</div>
		</div>
	</div>

    
</div>        
            <div class="td-main-content-wrap td-main-page-wrap td-container-wrap">
                <div class="tdc-content-wrap">
                    <div id="td_uid_1_5f8f778bdc740" class="tdc-row"><div class="vc_row td_uid_1_5f8f778bdc74a_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_1_5f8f778bdc74a_rand {
                    min-height: 0;
                }
</style><div class="vc_column td_uid_2_5f8f778bdccae_rand  wpb_column vc_column_container tdc-column td-pb-span12"><div class="wpb_wrapper"><div class="td_block_wrap td_block_big_grid_fl_10 td_uid_3_5f8f778bdcfe5_rand td-grid-style-4 td-hover-1 td-big-grids-fl td-big-grids-scroll td-big-grids-margin td-pb-border-top td_block_template_3" data-td-block-uid="td_uid_3_5f8f778bdcfe5">
<style>
/* custom css */


/* phone */
@media (max-width: 767px){
body .td_uid_3_5f8f778bdcfe5_rand .td_block_inner .td-big-grid-column .td-big-grid-meta .entry-title {
					@mx25f_title
				}
				.td_uid_3_5f8f778bdcfe5_rand .td-big-grid-column .td-post-category {
					@mx25f_cat
				}
				
				body .td_uid_3_5f8f778bdcfe5_rand .td_block_inner .td-big-grid-scroll .td-big-grid-meta .entry-title {
					@mx19f_title
				}
				.td_uid_3_5f8f778bdcfe5_rand .td-big-grid-scroll .td-post-category {
					@mx19f_cat
				}
				.td_uid_3_5f8f778bdcfe5_rand .td-big-grid-scroll .td-module-meta-info {
					@mx19f_meta
				}
}
</style>

	<div id="td_uid_3_5f8f778bdcfe5" class="td_block_inner">
		<div class="td-big-grid-wrapper td-posts-5">
		    <span class="td-big-grid-column">


		 <?php 

				 if(count($portadas) > 0 )
				{	


					for ( $p=0; 2 > $p ; $p++ ) 
					 {
						?>
						
					<div class="td_module_mx25 td_module_wrap td-animation-stack td-big-grid-post-0 td-big-grid-post td-mx-15"> 
			            <div class="td-module-image">

			                <div class="td-module-thumb"><a href="http://www.caracasdigital.com/index.php?keyword=TI&x=6934" rel="bookmark" class="td-image-wrap" title="Estudio de HP revela el auge del “empleado empoderado”"><span class="entry-thumb td-thumb-css td-animation-stack-type0-1" style="background-image: url(http://www.caracasdigital.com/noticias/<?php echo $portadas[$p]->fotos;  ?>?resize=485%2C360&ssl=2
			                )">
			                	

			                </span></a></div>            </div>

			            <div class="td-meta-info-container">
			                <div class="td-meta-align">
			                    <div class="td-big-grid-meta">
			                       <h3 class="entry-title td-module-title">
			                       	<a href="http://www.caracasdigital.com/index.php?keyword=TI&x=6934" rel="bookmark" title="Estudio de HP revela el auge del “empleado empoderado”"><?php echo $portadas[$p]->titulo; ?></a>
			                       </h3>                    
			                   </div>

			                   <div class="td-module-meta-info">
		                        <span class="td-post-date">
		                        	<time class="entry-date updated td-module-date" datetime="2020-10-15T13:09:58+00:00"><?php echo $portadas[$p]->ffecha; ?></time>
		                        </span>                    
		                    </div>

			                </div>
			            </div>
			       	 </div>

						<?php
					}	

				}


		 ?>

        
        
     <!--    <div class="td_module_mx25 td_module_wrap td-animation-stack td-big-grid-post-1 td-big-grid-post td-mx-15">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="http://www.caracasdigital.com/index.php?keyword=TI&x=6935" rel="bookmark" class="td-image-wrap" title="América Latina registra 5 mil ataques de ransomware por día"><span class="entry-thumb td-thumb-css td-animation-stack-type0-1" style="background-image: url(http://www.caracasdigital.com/images/noticias/carlos-blanco-abside-en-caracas-digital.jpg)"></span></a></div>            </div>

            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                                                <h3 class="entry-title td-module-title"><a href="http://www.caracasdigital.com/index.php?keyword=TI&x=6935" rel="bookmark" title="América Latina registra 5 mil ataques de ransomware por día">ABSIDE apoya a las organizaciones en su proceso de conversión a empresas inteligentes</a></h3>                    </div>
                </div>
            </div>
        </div> -->

        <div class="clearfix"></div>
    </span>

        <div class="td-big-grid-scroll">

		        <div class="td_module_mx19 td_module_wrap td-animation-stack td-big-grid-post-2 td-big-grid-post td-mx-23">
		            <div class="td-module-image">
		                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/hp-lanza-tecnologias-de-impresion-patient%e2%80%90firs/" rel="bookmark" class="td-image-wrap" title="HP lanza tecnologías de impresión Patient-First"><span class="entry-thumb td-thumb-css td-animation-stack-type0-1" style="background-image: url(http://www.caracasdigital.com/noticias/<?php echo $portadas[2]->fotos;  ?>)"></span></a></div>            </div>

		            <div class="td-meta-info-container">
		                <div class="td-meta-align">
		                    <div class="td-big-grid-meta">
		                                                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/hp-lanza-tecnologias-de-impresion-patient%e2%80%90firs/" rel="bookmark" title="HP lanza tecnologías de impresión Patient-First"><?php echo $portadas[2]->titulo; ?></a></h3>                    </div>

		                    <div class="td-module-meta-info">
		                        <span class="td-post-date">
		                        	<time class="entry-date updated td-module-date" datetime="2020-10-15T13:09:58+00:00"><?php echo $portadas[$p]->ffecha; ?></time>
		                        </span>                    
		                    </div>
		                </div>
		            </div>
		        </div>

        
		        <div class="td_module_mx25 td_module_wrap td-animation-stack td-big-grid-post-3 td-big-grid-post td-mx-15">
		            <div class="td-module-image">
		                <div class="td-module-thumb"><a href="http://www.caracasdigital.com/index.php?keyword=TI&x=6940" rel="bookmark" class="td-image-wrap" title="Nutanix lanza una plataforma de gestión de datos para entornos híbridos y multi-nube"><span class="entry-thumb td-thumb-css td-animation-stack-type0-1" style="background-image: url(http://www.caracasdigital.com/noticias/<?php echo $portadas[3]->fotos;  ?>)"></span></a></div>            </div>

		            <div class="td-meta-info-container">
		                <div class="td-meta-align">
		                    <div class="td-big-grid-meta">
		                                                <h3 class="entry-title td-module-title"><a href="http://www.caracasdigital.com/index.php?keyword=TI&x=6940" rel="bookmark" title="Nutanix lanza una plataforma de gestión de datos para entornos híbridos y multi-nube"><?php echo $portadas[3]->titulo; ?></a></h3>                    </div>
		                     <data></data>iv class="td-module-meta-info">
		                        <span class="td-post-date">
		                        	<time class="entry-date updated td-module-date" datetime="2020-10-15T13:09:58+00:00"><?php echo $portadas[3]->ffecha; ?></time>
		                        </span>                    
		                    </div>

		                </div>
		            </div>
		        </div>

		        
		        <div class="td_module_mx25 td_module_wrap td-animation-stack td-big-grid-post-4 td-big-grid-post td-mx-15">
		            <div class="td-module-image">
		                <div class="td-module-thumb"><a href="http://www.caracasdigital.com/index.php?keyword=TI&x=6927" rel="bookmark" class="td-image-wrap" title="NVIDIA presenta la nueva familia BlueField de DPUs"><span class="entry-thumb td-thumb-css td-animation-stack-type0-1" style="background-image: url(http://www.caracasdigital.com/noticias/<?php echo $portadas[4]->fotos;  ?>)"></span></a></div>            </div>

		            <div class="td-meta-info-container">
		                <div class="td-meta-align">
		                    <div class="td-big-grid-meta">
		                                                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/08/nvidia-presenta-la-nueva-familia-bluefield-de-dpus/" rel="bookmark" title="NVIDIA presenta la nueva familia BlueField de DPUs"><?php echo $portadas[4]->titulo; ?></a></h3>                   
		                   </div>
		                   <div class="td-module-meta-info">
		                        <span class="td-post-date">
		                        	<time class="entry-date updated td-module-date" datetime="2020-10-15T13:09:58+00:00"><?php echo $portadas[4]->ffecha; ?></time>
		                        </span>                    
		                    </div>
		                </div>
		            </div>
		        </div>

        </div>



        <div class="clearfix"></div></div></div></div> <!-- ./block --></div></div></div></div>
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_1_5f8f778bdc740 .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_1_5f8f778bdc740 .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

<div id="td_uid_3_5f8f778be64f6" class="tdc-row">
	<div class="vc_row td_uid_4_5f8f778be64ff_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_4_5f8f778be64ff_rand {
                    min-height: 0;
                }
</style>
<div class="vc_column td_uid_5_5f8f778be6720_rand  wpb_column vc_column_container tdc-column td-pb-span8">
	<div class="wpb_wrapper">

	<div class="wpb_wrapper td_block_wrap vc_raw_html td_uid_6_5f8f778be6843_rand ">

<!-- BANNER Cybersecurity	<div class="td-fix-index">
<a class="vc_single_image-wrapper vc_box_border_grey" href="https://www.itwarelatam.com/2020/08/24/revista-cybersecurity-3-seguridad-en-la-nube/" target="_blank" rel="noopener"><img class="vc_single_image-img " title="banner-web" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/banner_edicio´n_n3.gif?resize=695%2C170&amp;ssl=1" alt="banner-web" width="320" height="78"></a>
</div>-->


</div>

<div class="td_block_wrap td_block_7 td_uid_7_5f8f778be6a36_rand td-pb-border-top td_block_template_1 td-column-2 td_block_padding" data-td-block-uid="td_uid_7_5f8f778be6a36">

<!-- 	<script>

var block_td_uid_7_5f8f778be6a36 = new tdBlock();
block_td_uid_7_5f8f778be6a36.id = "td_uid_7_5f8f778be6a36";
block_td_uid_7_5f8f778be6a36.atts = '{"custom_title":"\u00daLTIM\u00c1S NOTICIAS","block_template_id":"td_block_template_1","limit":"12","tdc_css":"","separator":"","custom_url":"","m6_tl":"","post_ids":"","category_id":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","m6f_title_font_header":"","m6f_title_font_title":"Article title","m6f_title_font_settings":"","m6f_title_font_family":"","m6f_title_font_size":"","m6f_title_font_line_height":"","m6f_title_font_style":"","m6f_title_font_weight":"","m6f_title_font_transform":"","m6f_title_font_spacing":"","m6f_title_":"","m6f_cat_font_title":"Article category tag","m6f_cat_font_settings":"","m6f_cat_font_family":"","m6f_cat_font_size":"","m6f_cat_font_line_height":"","m6f_cat_font_style":"","m6f_cat_font_weight":"","m6f_cat_font_transform":"","m6f_cat_font_spacing":"","m6f_cat_":"","m6f_meta_font_title":"Article meta info","m6f_meta_font_settings":"","m6f_meta_font_family":"","m6f_meta_font_size":"","m6f_meta_font_line_height":"","m6f_meta_font_style":"","m6f_meta_font_weight":"","m6f_meta_font_transform":"","m6f_meta_font_spacing":"","m6f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","td_column_number":2,"header_color":"","color_preset":"","border_top":"","class":"td_uid_7_5f8f778be6a36_rand","tdc_css_class":"td_uid_7_5f8f778be6a36_rand","tdc_css_class_style":"td_uid_7_5f8f778be6a36_rand_style"}';
block_td_uid_7_5f8f778be6a36.td_column_number = "2";
block_td_uid_7_5f8f778be6a36.block_type = "td_block_7";
block_td_uid_7_5f8f778be6a36.post_count = "12";
block_td_uid_7_5f8f778be6a36.found_posts = "4594";
block_td_uid_7_5f8f778be6a36.header_color = "";
block_td_uid_7_5f8f778be6a36.ajax_pagination_infinite_stop = "";
block_td_uid_7_5f8f778be6a36.max_num_pages = "383";
tdBlocksArray.push(block_td_uid_7_5f8f778be6a36);
</script>
 -->
<div class="td-block-title-wrap"><h4 class="block-title td-block-title"><span class="td-pulldown-size">ÚLTIMÁS NOTICIAS</span></h4></div>
<div id="td_uid_7_5f8f778be6a36" class="td_block_inner">


<?php 
	
	$c=0;

	for( $r=0 ; intval( (count($noticias) / 2 )) > $r; $r++  ) 
	{
		//$c++;
	?>

	<div class="td-block-row">

			<div class="td-block-span6">

		        <div class="td_module_6 td_module_wrap td-animation-stack">

		        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/19/hipernet-se-asocia-con-solidworks/" rel="bookmark" class="td-image-wrap" title="Hipernet se asocia con SolidWorks"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="http://www.caracasdigital.com/noticias/pe/<?php echo $noticias[($r*2)]->fotos; ?>" srcset="http://www.caracasdigital.com/noticias/pe/<?php echo $noticias[($r*2)]->fotos; ?>" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Hipernet se asocia con SolidWorks"></a></div>
		        <div class="item-details">
		            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/19/hipernet-se-asocia-con-solidworks/" rel="bookmark" title="Hipernet se asocia con SolidWorks"><?php echo $noticias[($r*2)]->titulo; ?></a></h3>            <div class="td-module-meta-info">
		                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-19T18:18:59+00:00"><?php echo $noticias[($r*2)]->ffecha; ?></time></span>                            </div>
		        </div>

		        </div>

		        
			</div> <!-- ./td-block-span6 -->

			<div class="td-block-span6">

		        <div class="td_module_6 td_module_wrap td-animation-stack">

		        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/19/store-in-the-cloud-un-mercado-de-ti-para-que-los-minoristas-emerjan-mas-fuertes/" rel="bookmark" class="td-image-wrap" title="Store in the Cloud: un mercado de TI para que los minoristas emerjan más fuertes"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="http://www.caracasdigital.com/noticias/pe/<?php echo $noticias[($r*2)]->fotos; ?>" srcset="http://www.caracasdigital.com/noticias/pe/<?php echo $noticias[(($r*2)+1)]->fotos; ?>" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Store in the Cloud: un mercado de TI para que los minoristas emerjan más fuertes"></a></div>
		        <div class="item-details">
		            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/19/store-in-the-cloud-un-mercado-de-ti-para-que-los-minoristas-emerjan-mas-fuertes/" rel="bookmark" title="Store in the Cloud: un mercado de TI para que los minoristas emerjan más fuertes"><?php echo $noticias[(($r*2)+1)]->titulo; ?></a></h3>            <div class="td-module-meta-info">
		                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-19T17:42:52+00:00"><?php echo $noticias[(($r*2)+1)]->ffecha; ?></time></span>                            </div>
		        </div>

		        </div>

		        
			</div> <!-- ./td-block-span6 -->
	</div><!--./row-fluid-->

<?php }?>

</div></div> <!-- ./block -->

<!-- BANNER PulsoIT-->

<!-- <div class="wpb_wrapper td_block_wrap vc_raw_html td_uid_8_5f8f778c075e2_rand ">
<div class="td-fix-index">
<div id="container" align="center">
<a href="https://www.pulsoit.com.ar" target="new">
<img src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Pulso-it-.-Enfasys-.-Portada-Facebook.png?w=696&amp;ssl=1" alt="" width="320" height="118">
</a>
<p></p>
</div>
</div>
</div> -->

<div class="td_block_wrap td_block_25 td_uid_9_5f8f778c078a7_rand td-pb-border-top td_block_template_3 td-column-2" data-td-block-uid="td_uid_9_5f8f778c078a7"><script>var block_td_uid_9_5f8f778c078a7 = new tdBlock();
block_td_uid_9_5f8f778c078a7.id = "td_uid_9_5f8f778c078a7";
block_td_uid_9_5f8f778c078a7.atts = '{"custom_title":"CORPORATIVO Y VALOR AGREGADO","custom_url":"https:\/\/www.itwarelatam.com\/category\/corporativo\/","category_id":"4541","limit":"7","td_ajax_filter_type":"td_category_ids_filter","td_ajax_filter_ids":"276, 199, 1304, 226, 151, 22, 966, 835, 209, 153, 346, 329","separator":"","block_template_id":"","mx17_tl":"","m6_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","offset":"","el_class":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx17f_title_font_header":"","mx17f_title_font_title":"Article title","mx17f_title_font_settings":"","mx17f_title_font_family":"","mx17f_title_font_size":"","mx17f_title_font_line_height":"","mx17f_title_font_style":"","mx17f_title_font_weight":"","mx17f_title_font_transform":"","mx17f_title_font_spacing":"","mx17f_title_":"","mx17f_cat_font_title":"Article category tag","mx17f_cat_font_settings":"","mx17f_cat_font_family":"","mx17f_cat_font_size":"","mx17f_cat_font_line_height":"","mx17f_cat_font_style":"","mx17f_cat_font_weight":"","mx17f_cat_font_transform":"","mx17f_cat_font_spacing":"","mx17f_cat_":"","mx17f_meta_font_title":"Article meta info","mx17f_meta_font_settings":"","mx17f_meta_font_family":"","mx17f_meta_font_size":"","mx17f_meta_font_line_height":"","mx17f_meta_font_style":"","mx17f_meta_font_weight":"","mx17f_meta_font_transform":"","mx17f_meta_font_spacing":"","mx17f_meta_":"","m6f_title_font_header":"","m6f_title_font_title":"Article title","m6f_title_font_settings":"","m6f_title_font_family":"","m6f_title_font_size":"","m6f_title_font_line_height":"","m6f_title_font_style":"","m6f_title_font_weight":"","m6f_title_font_transform":"","m6f_title_font_spacing":"","m6f_title_":"","m6f_cat_font_title":"Article category tag","m6f_cat_font_settings":"","m6f_cat_font_family":"","m6f_cat_font_size":"","m6f_cat_font_line_height":"","m6f_cat_font_style":"","m6f_cat_font_weight":"","m6f_cat_font_transform":"","m6f_cat_font_spacing":"","m6f_cat_":"","m6f_meta_font_title":"Article meta info","m6f_meta_font_settings":"","m6f_meta_font_family":"","m6f_meta_font_size":"","m6f_meta_font_line_height":"","m6f_meta_font_style":"","m6f_meta_font_weight":"","m6f_meta_font_transform":"","m6f_meta_font_spacing":"","m6f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":2,"header_color":"","color_preset":"","border_top":"","class":"td_uid_9_5f8f778c078a7_rand","tdc_css_class":"td_uid_9_5f8f778c078a7_rand","tdc_css_class_style":"td_uid_9_5f8f778c078a7_rand_style"}';
block_td_uid_9_5f8f778c078a7.td_column_number = "2";
block_td_uid_9_5f8f778c078a7.block_type = "td_block_25";
block_td_uid_9_5f8f778c078a7.post_count = "7";
block_td_uid_9_5f8f778c078a7.found_posts = "1708";
block_td_uid_9_5f8f778c078a7.header_color = "";
block_td_uid_9_5f8f778c078a7.ajax_pagination_infinite_stop = "";
block_td_uid_9_5f8f778c078a7.max_num_pages = "244";
tdBlocksArray.push(block_td_uid_9_5f8f778c078a7);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/category/corporativo/" class="td-pulldown-size">CORPORATIVO Y VALOR AGREGADO</a></h4><div class="td-pulldown-syle-3 td-subcat-filter" id="td_pulldown_td_uid_9_5f8f778c078a7"><ul class="td-subcat-list" id="td_pulldown_td_uid_9_5f8f778c078a7_list"></ul><div class="td-subcat-dropdown" style=""><div class="td-subcat-more" aria-haspopup="true"><span>Más</span><i class="td-icon-read-down"></i></div><ul class="td-pulldown-filter-list"><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_10_5f8f778c1174b" data-td_filter_value="" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">All</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_11_5f8f778c1174e" data-td_filter_value="276" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Big Data</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_12_5f8f778c11750" data-td_filter_value="199" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Cloud</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_13_5f8f778c11751" data-td_filter_value="1304" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Contact Centers</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_14_5f8f778c11753" data-td_filter_value="226" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Data Centers</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_15_5f8f778c11754" data-td_filter_value="151" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Infraestructura</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_16_5f8f778c11755" data-td_filter_value="966" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Comunicaciones</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_17_5f8f778c11756" data-td_filter_value="835" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Colaboración</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_18_5f8f778c11757" data-td_filter_value="209" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">UC</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_19_5f8f778c11758" data-td_filter_value="153" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Seguridad</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_20_5f8f778c11759" data-td_filter_value="346" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Telecomunicaciones</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_21_5f8f778c1175b" data-td_filter_value="329" data-td_block_id="td_uid_9_5f8f778c078a7" href="#">Virtualización</a></li></ul></div></div></div><div id="td_uid_9_5f8f778c078a7" class="td_block_inner">

	<div class="td-block-row">

	<div class="td-block-span6">

        <div class="td_module_mx17 td_module_wrap td-animation-stack">
            <div class="meta-info-container">
                <div class="td-module-image">
                    <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/16/america-latina-registra-5-mil-ataques-de-ransomware-por-dia/" rel="bookmark" class="td-image-wrap" title="América Latina registra 5 mil ataques de ransomware por día"><img width="534" height="462" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Santiago_Pontiroli_Kaspersky.jpg?resize=534%2C462&amp;ssl=1" alt="" title="América Latina registra 5 mil ataques de ransomware por día"></a></div>                                    </div>
                <div class="td-module-meta-info">
                    <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/16/america-latina-registra-5-mil-ataques-de-ransomware-por-dia/" rel="bookmark" title="América Latina registra 5 mil ataques de ransomware por día">América Latina registra 5 mil ataques de ransomware por día</a></h3>                                        <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-16T11:20:44+00:00">16 octubre, 2020</time></span>                                    </div>
            </div>
        </div>

        
	</div> <!-- ./td-block-span6 -->

	<div class="td-block-span6">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/anna-kendrick-es-the-most-dangerous-celebrity-del-ano-segun-estudio-anual-de-mcafee/" rel="bookmark" class="td-image-wrap" title="Anna Kendrick es The Most Dangerous Celebrity del año, según estudio anual de McAfee"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Anna-Kendrick-Seth-Meyers.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Anna-Kendrick-Seth-Meyers.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Anna-Kendrick-Seth-Meyers.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Anna-Kendrick-Seth-Meyers.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="Anna-Kendrick-Seth-Meyers" title="Anna Kendrick es The Most Dangerous Celebrity del año, según estudio anual de McAfee"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/anna-kendrick-es-the-most-dangerous-celebrity-del-ano-segun-estudio-anual-de-mcafee/" rel="bookmark" title="Anna Kendrick es The Most Dangerous Celebrity del año, según estudio anual de McAfee">Anna Kendrick es The Most Dangerous Celebrity del año, según estudio...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-15T10:32:14+00:00">15 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/oea-y-cisco-primera-reunion-del-consejo-de-innovacion-en-ciberseguridad-capitulo-colombia/" rel="bookmark" class="td-image-wrap" title="OEA y Cisco: Primera Reunión del Consejo de Innovación en Ciberseguridad capítulo Colombia"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Cisco-OEA.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Cisco-OEA.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Cisco-OEA.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Cisco-OEA.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="OEA y Cisco: Primera Reunión del Consejo de Innovación en Ciberseguridad capítulo Colombia"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/oea-y-cisco-primera-reunion-del-consejo-de-innovacion-en-ciberseguridad-capitulo-colombia/" rel="bookmark" title="OEA y Cisco: Primera Reunión del Consejo de Innovación en Ciberseguridad capítulo Colombia">OEA y Cisco: Primera Reunión del Consejo de Innovación en Ciberseguridad...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-15T10:27:44+00:00">15 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/13/f5-realiza-su-encuesta-anual-global-sobre-el-estado-actual-de-apps/" rel="bookmark" class="td-image-wrap" title="F5 realiza su Encuesta Anual Global sobre el estado actual de apps."><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/person-city-fisheye-hero_og_xl.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/person-city-fisheye-hero_og_xl.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/person-city-fisheye-hero_og_xl.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/person-city-fisheye-hero_og_xl.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="F5 realiza su Encuesta Anual Global sobre el estado actual de apps."></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/13/f5-realiza-su-encuesta-anual-global-sobre-el-estado-actual-de-apps/" rel="bookmark" title="F5 realiza su Encuesta Anual Global sobre el estado actual de apps.">F5 realiza su Encuesta Anual Global sobre el estado actual de...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-13T16:18:18+00:00">13 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/13/nutanix-lanza-una-plataforma-de-gestion-de-datos-para-entornos-hibridos-y-multi-nube/" rel="bookmark" class="td-image-wrap" title="Nutanix lanza una plataforma de gestión de datos para entornos híbridos y multi-nube"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Era-2.0-Nutanix.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Era-2.0-Nutanix.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Era-2.0-Nutanix.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Era-2.0-Nutanix.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Nutanix lanza una plataforma de gestión de datos para entornos híbridos y multi-nube"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/13/nutanix-lanza-una-plataforma-de-gestion-de-datos-para-entornos-hibridos-y-multi-nube/" rel="bookmark" title="Nutanix lanza una plataforma de gestión de datos para entornos híbridos y multi-nube">Nutanix lanza una plataforma de gestión de datos para entornos híbridos...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-13T16:11:59+00:00">13 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/13/lumen-amplia-su-data-center-de-bogota/" rel="bookmark" class="td-image-wrap" title="Lumen amplía su Data Center de Bogotá"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Lumen-1.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Lumen-1.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Lumen-1.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Lumen-1.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Lumen amplía su Data Center de Bogotá"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/13/lumen-amplia-su-data-center-de-bogota/" rel="bookmark" title="Lumen amplía su Data Center de Bogotá">Lumen amplía su Data Center de Bogotá</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-13T10:07:38+00:00">13 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/10/las-cinco-medidas-de-ciberseguridad-que-toda-organizacion-deberia-implementar-en-la-era-post-covid/" rel="bookmark" class="td-image-wrap" title="Las cinco medidas de ciberseguridad que toda organización debería implementar en la era post-COVID"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Ciberseguridad-Indra-Maestra-scaled.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Ciberseguridad-Indra-Maestra-scaled.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Ciberseguridad-Indra-Maestra-scaled.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Ciberseguridad-Indra-Maestra-scaled.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Las cinco medidas de ciberseguridad que toda organización debería implementar en la era post-COVID"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/10/las-cinco-medidas-de-ciberseguridad-que-toda-organizacion-deberia-implementar-en-la-era-post-covid/" rel="bookmark" title="Las cinco medidas de ciberseguridad que toda organización debería implementar en la era post-COVID">Las cinco medidas de ciberseguridad que toda organización debería implementar en...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-10T10:12:29+00:00">10 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span6 --></div><!--./row-fluid--></div></div> <!-- ./block --><div class="td_block_wrap td_block_25 td_uid_22_5f8f778c16cff_rand td-pb-border-top td_block_template_3 td-column-2" data-td-block-uid="td_uid_22_5f8f778c16cff"><script>var block_td_uid_22_5f8f778c16cff = new tdBlock();
block_td_uid_22_5f8f778c16cff.id = "td_uid_22_5f8f778c16cff";
block_td_uid_22_5f8f778c16cff.atts = '{"custom_title":"SOFTWARE Y SERVICIOS","custom_url":"https:\/\/www.itwarelatam.com\/category\/software_y_servicios\/","category_id":"152","limit":"7","td_ajax_filter_type":"td_category_ids_filter","td_ajax_filter_ids":"685,2979,258,315","separator":"","block_template_id":"","mx17_tl":"","m6_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","offset":"","el_class":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx17f_title_font_header":"","mx17f_title_font_title":"Article title","mx17f_title_font_settings":"","mx17f_title_font_family":"","mx17f_title_font_size":"","mx17f_title_font_line_height":"","mx17f_title_font_style":"","mx17f_title_font_weight":"","mx17f_title_font_transform":"","mx17f_title_font_spacing":"","mx17f_title_":"","mx17f_cat_font_title":"Article category tag","mx17f_cat_font_settings":"","mx17f_cat_font_family":"","mx17f_cat_font_size":"","mx17f_cat_font_line_height":"","mx17f_cat_font_style":"","mx17f_cat_font_weight":"","mx17f_cat_font_transform":"","mx17f_cat_font_spacing":"","mx17f_cat_":"","mx17f_meta_font_title":"Article meta info","mx17f_meta_font_settings":"","mx17f_meta_font_family":"","mx17f_meta_font_size":"","mx17f_meta_font_line_height":"","mx17f_meta_font_style":"","mx17f_meta_font_weight":"","mx17f_meta_font_transform":"","mx17f_meta_font_spacing":"","mx17f_meta_":"","m6f_title_font_header":"","m6f_title_font_title":"Article title","m6f_title_font_settings":"","m6f_title_font_family":"","m6f_title_font_size":"","m6f_title_font_line_height":"","m6f_title_font_style":"","m6f_title_font_weight":"","m6f_title_font_transform":"","m6f_title_font_spacing":"","m6f_title_":"","m6f_cat_font_title":"Article category tag","m6f_cat_font_settings":"","m6f_cat_font_family":"","m6f_cat_font_size":"","m6f_cat_font_line_height":"","m6f_cat_font_style":"","m6f_cat_font_weight":"","m6f_cat_font_transform":"","m6f_cat_font_spacing":"","m6f_cat_":"","m6f_meta_font_title":"Article meta info","m6f_meta_font_settings":"","m6f_meta_font_family":"","m6f_meta_font_size":"","m6f_meta_font_line_height":"","m6f_meta_font_style":"","m6f_meta_font_weight":"","m6f_meta_font_transform":"","m6f_meta_font_spacing":"","m6f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":2,"header_color":"","color_preset":"","border_top":"","class":"td_uid_22_5f8f778c16cff_rand","tdc_css_class":"td_uid_22_5f8f778c16cff_rand","tdc_css_class_style":"td_uid_22_5f8f778c16cff_rand_style"}';
block_td_uid_22_5f8f778c16cff.td_column_number = "2";
block_td_uid_22_5f8f778c16cff.block_type = "td_block_25";
block_td_uid_22_5f8f778c16cff.post_count = "7";
block_td_uid_22_5f8f778c16cff.found_posts = "386";
block_td_uid_22_5f8f778c16cff.header_color = "";
block_td_uid_22_5f8f778c16cff.ajax_pagination_infinite_stop = "";
block_td_uid_22_5f8f778c16cff.max_num_pages = "56";
tdBlocksArray.push(block_td_uid_22_5f8f778c16cff);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/category/software_y_servicios/" class="td-pulldown-size">SOFTWARE Y SERVICIOS</a></h4><div class="td-pulldown-syle-3 td-subcat-filter" id="td_pulldown_td_uid_22_5f8f778c16cff"><ul class="td-subcat-list" id="td_pulldown_td_uid_22_5f8f778c16cff_list"><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_23_5f8f778c1b828" data-td_filter_value="" data-td_block_id="td_uid_22_5f8f778c16cff" href="#">All</a></li></ul><div class="td-subcat-dropdown" style=""><div class="td-subcat-more" aria-haspopup="true"><span>Más</span><i class="td-icon-read-down"></i></div><ul class="td-pulldown-filter-list"><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_24_5f8f778c1b82b" data-td_filter_value="685" data-td_block_id="td_uid_22_5f8f778c16cff" href="#">Aplicaciones</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_25_5f8f778c1b82d" data-td_filter_value="2979" data-td_block_id="td_uid_22_5f8f778c16cff" href="#">Consultoría</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_26_5f8f778c1b82f" data-td_filter_value="258" data-td_block_id="td_uid_22_5f8f778c16cff" href="#">Desarrolladores</a></li></ul></div></div></div><div id="td_uid_22_5f8f778c16cff" class="td_block_inner">

	<div class="td-block-row">

	<div class="td-block-span6">

        <div class="td_module_mx17 td_module_wrap td-animation-stack">
            <div class="meta-info-container">
                <div class="td-module-image">
                    <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/19/hipernet-se-asocia-con-solidworks/" rel="bookmark" class="td-image-wrap" title="Hipernet se asocia con SolidWorks"><img width="534" height="462" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/hipernet.jpg?resize=534%2C462&amp;ssl=1" alt="" title="Hipernet se asocia con SolidWorks"></a></div>                                    </div>
                <div class="td-module-meta-info">
                    <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/19/hipernet-se-asocia-con-solidworks/" rel="bookmark" title="Hipernet se asocia con SolidWorks">Hipernet se asocia con SolidWorks</a></h3>                                        <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-19T18:18:59+00:00">19 octubre, 2020</time></span>                                    </div>
            </div>
        </div>

        
	</div> <!-- ./td-block-span6 -->

	<div class="td-block-span6">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/09/genexus-17-live-nuevas-tecnologias-para-un-nuevo-mundo/" rel="bookmark" class="td-image-wrap" title="GeneXus 17 Live: nuevas tecnologías para un nuevo mundo"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="GeneXus 17 Live: nuevas tecnologías para un nuevo mundo"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/09/genexus-17-live-nuevas-tecnologias-para-un-nuevo-mundo/" rel="bookmark" title="GeneXus 17 Live: nuevas tecnologías para un nuevo mundo">GeneXus 17 Live: nuevas tecnologías para un nuevo mundo</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-09T09:38:43+00:00">9 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/08/salesforce-anuncia-el-lanzamiento-de-digital-360/" rel="bookmark" class="td-image-wrap" title="Salesforce anuncia el lanzamiento de Digital 360"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/salesforce.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/salesforce.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/salesforce.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/salesforce.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Salesforce anuncia el lanzamiento de Digital 360"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/08/salesforce-anuncia-el-lanzamiento-de-digital-360/" rel="bookmark" title="Salesforce anuncia el lanzamiento de Digital 360">Salesforce anuncia el lanzamiento de Digital 360</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-08T09:41:52+00:00">8 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/06/nvidia-presento-la-solucion-dgx-superpod-para-empresas/" rel="bookmark" class="td-image-wrap" title="NVIDIA presentó la solución DGX SuperPOD para empresas"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="NVIDIA presentó la solución DGX SuperPOD para empresas"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/06/nvidia-presento-la-solucion-dgx-superpod-para-empresas/" rel="bookmark" title="NVIDIA presentó la solución DGX SuperPOD para empresas">NVIDIA presentó la solución DGX SuperPOD para empresas</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-06T09:46:56+00:00">6 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/25/transformacion-digital-con-la-tecnologia-open-source-como-herramienta-clave/" rel="bookmark" class="td-image-wrap" title="Transformación Digital con la tecnología Open Source como herramienta clave"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/ppal.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/ppal.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/ppal.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/ppal.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Transformación Digital con la tecnología Open Source como herramienta clave"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/25/transformacion-digital-con-la-tecnologia-open-source-como-herramienta-clave/" rel="bookmark" title="Transformación Digital con la tecnología Open Source como herramienta clave">Transformación Digital con la tecnología Open Source como herramienta clave</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-25T16:17:14+00:00">25 septiembre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/22/en-latinoamerica-las-aplicaciones-son-el-motor-de-la-economia-digital/" rel="bookmark" class="td-image-wrap" title="En Latinoamérica, las aplicaciones son el motor de la economía digital"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="En Latinoamérica, las aplicaciones son el motor de la economía digital"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/22/en-latinoamerica-las-aplicaciones-son-el-motor-de-la-economia-digital/" rel="bookmark" title="En Latinoamérica, las aplicaciones son el motor de la economía digital">En Latinoamérica, las aplicaciones son el motor de la economía digital</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-22T09:27:41+00:00">22 septiembre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/16/llega-una-nueva-edicion-del-red-hat-forum-a-america-latina-from-here-anywhere/" rel="bookmark" class="td-image-wrap" title="Llega una nueva edición del Red Hat Forum a América Latina  “From here, anywhere”"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Red-Hat-Forum.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Red-Hat-Forum.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Red-Hat-Forum.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Red-Hat-Forum.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Llega una nueva edición del Red Hat Forum a América Latina  “From here, anywhere”"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/16/llega-una-nueva-edicion-del-red-hat-forum-a-america-latina-from-here-anywhere/" rel="bookmark" title="Llega una nueva edición del Red Hat Forum a América Latina  “From here, anywhere”">Llega una nueva edición del Red Hat Forum a América Latina...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-16T17:39:34+00:00">16 septiembre, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span6 --></div><!--./row-fluid--></div></div> 









	<!-- ./block --><div class="td_block_wrap td_block_15 td_uid_27_5f8f778c21861_rand td-pb-border-top td_block_template_10 td-column-2 td_block_padding" data-td-block-uid="td_uid_27_5f8f778c21861"><script>var block_td_uid_27_5f8f778c21861 = new tdBlock();
block_td_uid_27_5f8f778c21861.id = "td_uid_27_5f8f778c21861";
block_td_uid_27_5f8f778c21861.atts = '{"custom_title":"PRODUCTOS","block_template_id":"td_block_template_10","category_id":"4542","limit":"9","separator":"","custom_url":"","mx4_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx4f_title_font_header":"","mx4f_title_font_title":"Article title","mx4f_title_font_settings":"","mx4f_title_font_family":"","mx4f_title_font_size":"","mx4f_title_font_line_height":"","mx4f_title_font_style":"","mx4f_title_font_weight":"","mx4f_title_font_transform":"","mx4f_title_font_spacing":"","mx4f_title_":"","mx4f_cat_font_title":"Article category tag","mx4f_cat_font_settings":"","mx4f_cat_font_family":"","mx4f_cat_font_size":"","mx4f_cat_font_line_height":"","mx4f_cat_font_style":"","mx4f_cat_font_weight":"","mx4f_cat_font_transform":"","mx4f_cat_font_spacing":"","mx4f_cat_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":2,"header_color":"","color_preset":"","border_top":"","class":"td_uid_27_5f8f778c21861_rand","tdc_css_class":"td_uid_27_5f8f778c21861_rand","tdc_css_class_style":"td_uid_27_5f8f778c21861_rand_style"}';
block_td_uid_27_5f8f778c21861.td_column_number = "2";
block_td_uid_27_5f8f778c21861.block_type = "td_block_15";
block_td_uid_27_5f8f778c21861.post_count = "9";
block_td_uid_27_5f8f778c21861.found_posts = "884";
block_td_uid_27_5f8f778c21861.header_color = "";
block_td_uid_27_5f8f778c21861.ajax_pagination_infinite_stop = "";
block_td_uid_27_5f8f778c21861.max_num_pages = "99";
tdBlocksArray.push(block_td_uid_27_5f8f778c21861);
</script>


<div class="td-block-title-wrap"><h4 class="td-block-title"><span class="td-pulldown-size">PRODUCTOS</span></h4>
</div>

<div id="td_uid_27_5f8f778c21861" class="td_block_inner td-column-2">

	<div class="td-block-row">

		<div class="td-block-span4">

	        <div class="td_module_mx4 td_module_wrap td-animation-stack">
	            <div class="td-module-image">
	                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/hp-lanza-tecnologias-de-impresion-patient%e2%80%90firs/" rel="bookmark" class="td-image-wrap" title="HP lanza tecnologías de impresión Patient-First"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-healthcare.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-healthcare.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-healthcare.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-healthcare.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-healthcare.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="HP lanza tecnologías de impresión Patient-First"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/hardware/" class="td-post-category">Hardware</a>            </div>

	            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/hp-lanza-tecnologias-de-impresion-patient%e2%80%90firs/" rel="bookmark" title="HP lanza tecnologías de impresión Patient-First">HP lanza tecnologías de impresión Patient-First</a></h3>
	        </div>

	        
		</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/08/nvidia-presenta-la-nueva-familia-bluefield-de-dpus/" rel="bookmark" class="td-image-wrap" title="NVIDIA presenta la nueva familia BlueField de DPUs"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_2_Nvidia.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_2_Nvidia.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_2_Nvidia.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_2_Nvidia.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_2_Nvidia.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="NVIDIA presenta la nueva familia BlueField de DPUs"></a></div>                <a href="https://http://www.caracasdigital.com/category/corporativo/data-centers/" class="td-post-category">Data Centers</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/08/nvidia-presenta-la-nueva-familia-bluefield-de-dpus/" rel="bookmark" title="NVIDIA presenta la nueva familia BlueField de DPUs">NVIDIA presenta la nueva familia BlueField de DPUs</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/01/intel-anuncia-procesadores-mejorados-con-iot/" rel="bookmark" class="td-image-wrap" title="Intel anuncia procesadores mejorados con IoT"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="Intel anuncia procesadores mejorados con IoT"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/hardware/" class="td-post-category">Hardware</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/01/intel-anuncia-procesadores-mejorados-con-iot/" rel="bookmark" title="Intel anuncia procesadores mejorados con IoT">Intel anuncia procesadores mejorados con IoT</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->

</div><!--./row-fluid-->

<div class="td-block-row">

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/17/nuevo-portafolio-de-productos-mcafee/" rel="bookmark" class="td-image-wrap" title="Nuevo portafolio de productos McAfee"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/together-is-power.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/together-is-power.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/together-is-power.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/together-is-power.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/together-is-power.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="together-is-power" title="Nuevo portafolio de productos McAfee"></a></div>                <a href="https://http://www.caracasdigital.com/category/corporativo/seguridad/ciberseguridad/" class="td-post-category">Ciberseguridad</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/17/nuevo-portafolio-de-productos-mcafee/" rel="bookmark" title="Nuevo portafolio de productos McAfee">Nuevo portafolio de productos McAfee</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/17/novedades-para-socios-de-negocios-desde-hp-reinvent/" rel="bookmark" class="td-image-wrap" title="Novedades para socios de negocios desde HP Reinvent"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/amplify.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/amplify.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/amplify.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/amplify.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/amplify.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="Novedades para socios de negocios desde HP Reinvent"></a></div>                <a href="https://http://www.caracasdigital.com/category/tipo-de-nota/eventos/" class="td-post-category">Eventos</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/17/novedades-para-socios-de-negocios-desde-hp-reinvent/" rel="bookmark" title="Novedades para socios de negocios desde HP Reinvent">Novedades para socios de negocios desde HP Reinvent</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/16/hp-anuncia-innovaciones-en-pcs-para-entornos-de-trabajo-hibridos/" rel="bookmark" class="td-image-wrap" title="HP anuncia innovaciones en PCs para entornos de trabajo híbridos"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-ppal.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-ppal.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-ppal.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-ppal.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-ppal.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="HP anuncia innovaciones en PCs para entornos de trabajo híbridos"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/hardware/" class="td-post-category">Hardware</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/16/hp-anuncia-innovaciones-en-pcs-para-entornos-de-trabajo-hibridos/" rel="bookmark" title="HP anuncia innovaciones en PCs para entornos de trabajo híbridos">HP anuncia innovaciones en PCs para entornos de trabajo híbridos</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->
</div><!--./row-fluid-->

<div class="td-block-row">

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/14/esutudio-revela-que-el-73-de-los-consumidores-prefieren-auriculares-inalambricos/" rel="bookmark" class="td-image-wrap" title="Estudio revela que el 73% de los consumidores prefieren auriculares inalámbricos"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?resize=218%2C150&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="Estudio revela que el 73% de los consumidores prefieren auriculares inalámbricos"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/movilidad/" class="td-post-category">Movilidad</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/14/esutudio-revela-que-el-73-de-los-consumidores-prefieren-auriculares-inalambricos/" rel="bookmark" title="Estudio revela que el 73% de los consumidores prefieren auriculares inalámbricos">Estudio revela que el 73% de los consumidores prefieren auriculares inalámbricos</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/07/hp-anuncia-nueva-serie-de-impresoras-latex-a-precios-mas-asequibles/" rel="bookmark" class="td-image-wrap" title="HP anuncia nueva serie de impresoras Latex a precios más asequibles"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="HP anuncia nueva serie de impresoras Latex a precios más asequibles"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/hardware/" class="td-post-category">Hardware</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/07/hp-anuncia-nueva-serie-de-impresoras-latex-a-precios-mas-asequibles/" rel="bookmark" title="HP anuncia nueva serie de impresoras Latex a precios más asequibles">HP anuncia nueva serie de impresoras Latex a precios más asequibles</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/08/28/7-de-cada-10-usuarios-no-tienen-cobertura-wi-fi-en-todas-las-habitaciones-de-la-casa/" rel="bookmark" class="td-image-wrap" title="7 de cada 10 usuarios no tienen cobertura Wi-Fi en todas las habitaciones de la casa"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="7 de cada 10 usuarios no tienen cobertura Wi-Fi en todas las habitaciones de la casa"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/movilidad/" class="td-post-category">Movilidad</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/08/28/7-de-cada-10-usuarios-no-tienen-cobertura-wi-fi-en-todas-las-habitaciones-de-la-casa/" rel="bookmark" title="7 de cada 10 usuarios no tienen cobertura Wi-Fi en todas las habitaciones de la casa">7 de cada 10 usuarios no tienen cobertura Wi-Fi en todas...</a></h3>
        </div>

        
	</div> 
	<!-- ./td-block-span4 -->
</div><!--./row-fluid-->


<div class="td-block-row">

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/14/esutudio-revela-que-el-73-de-los-consumidores-prefieren-auriculares-inalambricos/" rel="bookmark" class="td-image-wrap" title="Estudio revela que el 73% de los consumidores prefieren auriculares inalámbricos"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?resize=218%2C150&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Auriculares-inalambricos.png?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="Estudio revela que el 73% de los consumidores prefieren auriculares inalámbricos"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/movilidad/" class="td-post-category">Movilidad</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/14/esutudio-revela-que-el-73-de-los-consumidores-prefieren-auriculares-inalambricos/" rel="bookmark" title="Estudio revela que el 73% de los consumidores prefieren auriculares inalámbricos">Estudio revela que el 73% de los consumidores prefieren auriculares inalámbricos</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/07/hp-anuncia-nueva-serie-de-impresoras-latex-a-precios-mas-asequibles/" rel="bookmark" class="td-image-wrap" title="HP anuncia nueva serie de impresoras Latex a precios más asequibles"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/HP-Latex-R-Series.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="HP anuncia nueva serie de impresoras Latex a precios más asequibles"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/hardware/" class="td-post-category">Hardware</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/07/hp-anuncia-nueva-serie-de-impresoras-latex-a-precios-mas-asequibles/" rel="bookmark" title="HP anuncia nueva serie de impresoras Latex a precios más asequibles">HP anuncia nueva serie de impresoras Latex a precios más asequibles</a></h3>
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_mx4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/08/28/7-de-cada-10-usuarios-no-tienen-cobertura-wi-fi-en-todas-las-habitaciones-de-la-casa/" rel="bookmark" class="td-image-wrap" title="7 de cada 10 usuarios no tienen cobertura Wi-Fi en todas las habitaciones de la casa"><img width="218" height="150" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?resize=218%2C150&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?zoom=2&amp;resize=218%2C150&amp;ssl=1 436w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/qualcomm-new-normal.jpg?zoom=3&amp;resize=218%2C150&amp;ssl=1 654w" sizes="(max-width: 218px) 100vw, 218px" alt="" title="7 de cada 10 usuarios no tienen cobertura Wi-Fi en todas las habitaciones de la casa"></a></div>                <a href="https://http://www.caracasdigital.com/category/productos/movilidad/" class="td-post-category">Movilidad</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/08/28/7-de-cada-10-usuarios-no-tienen-cobertura-wi-fi-en-todas-las-habitaciones-de-la-casa/" rel="bookmark" title="7 de cada 10 usuarios no tienen cobertura Wi-Fi en todas las habitaciones de la casa">7 de cada 10 usuarios no tienen cobertura Wi-Fi en todas...</a></h3>
        </div>

        
	</div> 
	<!-- ./td-block-span4 -->
</div><!--./row-fluid-->

</div></div> <!-- ./block -->


<div class="clearfix"></div></div></div>


<div class="vc_column td_uid_28_5f8f778c2f94d_rand  wpb_column vc_column_container tdc-column td-pb-span4">
	<div class="wpb_wrapper">
		<div class="wpb_wrapper td_block_wrap vc_widget_sidebar td_uid_29_5f8f778c2fade_rand ">
			<aside class="td_block_template_3 widget widget_text">
				<h4 class="td-block-title"><span>Anunciantes</span></h4>			
				<div class="textwidget"><p><!-- GOCONNECT LOL --></p>
<div align="center"><a href="https://www.licenciasonline.com/" target="new" rel="noopener noreferrer"><img loading="lazy" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/300x250.gif?resize=300%2C250&amp;ssl=1" alt="" width="300" height="250" data-recalc-dims="1"><br>
</a></div>
<p><!-- BANNER APC--></p>
<div align="center"><a href="http://www.apc.com/template/country_selection.cfm?ref_url=/edge" target="new" rel="noopener noreferrer"><img src="https://i0.wp.com/www.enfasys.net/banners/schneider/banner_APC_300x250.gif?w=696&amp;ssl=1" alt="" width="300" height="250"></a></div>
<p><!-- Kaspersky--></p>
<div align="center"><a href="https://go.kaspersky.com/ITWareSP.html" target="new" rel="noopener noreferrer"><img loading="lazy" class="aligncenter size-full wp-image-45079" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/6_300x250.gif?resize=300%2C250&amp;ssl=1" alt="" width="300" height="250" data-recalc-dims="1"></a></div>
<p><!-- VERTIV --></p>
<div align="center"><a href="https://vertiv.biz/Inicieahora-GXT5-SP-V2" target="new" rel="noopener noreferrer"><img loading="lazy" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Vertiv_Liebert_GXT5_300x250.gif?resize=300%2C250&amp;ssl=1" alt="" width="300" height="250" data-recalc-dims="1"> </a></div>
<p><!--Hikvision


<div align="center"><a href="https://forms.gle/8JkJUntyRBqoviYKA" target="new" rel="noopener noreferrer"><img loading="lazy" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/piezas_enfasys_banners_minmoe.png?resize=300%2C250&#038;ssl=1" alt="" width="300" height="250" data-recalc-dims="1" /> </a></div>


--><br>
<!-- PC Discount--></p>
<div align="center"><a href="https://docs.google.com/forms/d/e/1FAIpQLScaj0-2F7s-_jolbCFJcrpL4FNBdRmneDKxPdv58gb8Lv-UBw/viewform" target="new" rel="noopener noreferrer"><img loading="lazy" class="aligncenter size-full wp-image-45079" src="https://i0.wp.com/www.enfasys.net/wp-content/uploads/2020/01/pc-discount-banner-300x250_enfasys-modificado-1.gif?resize=300%2C250&amp;ssl=1" alt="" width="300" height="250" data-recalc-dims="1"></a></div>
<p><!--BANNER_Croudstrike--></p>
<div align="center"><a href="https://registro.contenidoscrowdstrike.com/freetrial/?utm_source=mediaware&amp;utm_medium=banner&amp;utm_campaign=free_trial" target="new" rel="noopener noreferrer"><br>
<img src="https://i1.wp.com/www.enfasys.net/wp-content/uploads/2020/10/300x250-CS-Free-Trial-2.jpg?w=696&amp;ssl=1" alt="" width="300" height="250"></a></div>
</div>
		</aside><div class="td_block_wrap td_block_7 td_block_widget td_uid_30_5f8f778c322db_rand td-pb-border-top td_block_template_3 td-column-1 td_block_padding" data-td-block-uid="td_uid_30_5f8f778c322db">
<style>
.td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-pulldown-filter-link:hover,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-subcat-item a:hover,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-subcat-item .td-cur-simple-item,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-subcat-dropdown:hover .td-subcat-more span,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-subcat-dropdown:hover .td-subcat-more i {
                color: #54b948;
            }
            
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-block-title > * {
                background-color: #54b948;
            }

            
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td_module_wrap:hover .entry-title a,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td_quote_on_blocks,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-opacity-cat .td-post-category:hover,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-opacity-read .td-read-more a:hover,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-opacity-author .td-post-author-name a:hover,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-instagram-user a {
                color: #54b948;
            }

            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-next-prev-wrap a:hover,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-load-more-wrap a:hover {
                background-color: #54b948;
                border-color: #54b948;
            }

            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-read-more a,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-weather-information:before,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-weather-week:before,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-exchange-header:before,
            .td-theme-wrap .td-footer-wrapper .td_uid_30_5f8f778c322db_rand .td-post-category,
            .td-theme-wrap .td_uid_30_5f8f778c322db_rand .td-post-category:hover {
                background-color: #54b948;
            }
</style><script>var block_td_uid_30_5f8f778c322db = new tdBlock();
block_td_uid_30_5f8f778c322db.id = "td_uid_30_5f8f778c322db";
block_td_uid_30_5f8f778c322db.atts = '{"custom_title":"Veeam News","custom_url":"https:\/\/www.itwarelatam.com\/tag\/veeam\/","block_template_id":"","header_color":"#54b948","header_text_color":"#","accent_text_color":"#54b948","m6_tl":"","limit":"4","offset":"","el_class":"","post_ids":"","category_id":"","category_ids":"","tag_slug":"Veeam","autors_id":"","installed_post_types":"","sort":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","conditions":{"action":"show","match_all":"0","rules":[{"major":"page","minor":"front","has_children":false}]},"class":"td_block_widget td_uid_30_5f8f778c322db_rand","separator":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","m6f_title_font_header":"","m6f_title_font_title":"Article title","m6f_title_font_settings":"","m6f_title_font_family":"","m6f_title_font_size":"","m6f_title_font_line_height":"","m6f_title_font_style":"","m6f_title_font_weight":"","m6f_title_font_transform":"","m6f_title_font_spacing":"","m6f_title_":"","m6f_cat_font_title":"Article category tag","m6f_cat_font_settings":"","m6f_cat_font_family":"","m6f_cat_font_size":"","m6f_cat_font_line_height":"","m6f_cat_font_style":"","m6f_cat_font_weight":"","m6f_cat_font_transform":"","m6f_cat_font_spacing":"","m6f_cat_":"","m6f_meta_font_title":"Article meta info","m6f_meta_font_settings":"","m6f_meta_font_family":"","m6f_meta_font_size":"","m6f_meta_font_line_height":"","m6f_meta_font_style":"","m6f_meta_font_weight":"","m6f_meta_font_transform":"","m6f_meta_font_spacing":"","m6f_meta_":"","css":"","tdc_css":"","td_column_number":1,"color_preset":"","border_top":"","tdc_css_class":"td_uid_30_5f8f778c322db_rand","tdc_css_class_style":"td_uid_30_5f8f778c322db_rand_style"}';
block_td_uid_30_5f8f778c322db.td_column_number = "1";
block_td_uid_30_5f8f778c322db.block_type = "td_block_7";
block_td_uid_30_5f8f778c322db.post_count = "4";
block_td_uid_30_5f8f778c322db.found_posts = "80";
block_td_uid_30_5f8f778c322db.header_color = "#54b948";
block_td_uid_30_5f8f778c322db.ajax_pagination_infinite_stop = "";
block_td_uid_30_5f8f778c322db.max_num_pages = "20";
tdBlocksArray.push(block_td_uid_30_5f8f778c322db);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/tag/veeam/" class="td-pulldown-size">Veeam News</a></h4></div><div id="td_uid_30_5f8f778c322db" class="td_block_inner">

	<div class="td-block-span12">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/08/veeam-busca-acelerar-la-proteccion-de-cargas-de-trabajo-nativas-de-kubernetes/" rel="bookmark" class="td-image-wrap" title="Veeam busca acelerar la protección de cargas de trabajo nativas de Kubernetes"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Danny_Allan_VeeamON2020.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Danny_Allan_VeeamON2020.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Danny_Allan_VeeamON2020.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Danny_Allan_VeeamON2020.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Veeam busca acelerar la protección de cargas de trabajo nativas de Kubernetes"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/08/veeam-busca-acelerar-la-proteccion-de-cargas-de-trabajo-nativas-de-kubernetes/" rel="bookmark" title="Veeam busca acelerar la protección de cargas de trabajo nativas de Kubernetes">Veeam busca acelerar la protección de cargas de trabajo nativas de...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-08T09:13:53+00:00">8 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span12 -->

	<div class="td-block-span12">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/11/veeam-anticipo-novedades-en-su-portfolio-de-soluciones-de-disponibilidad/" rel="bookmark" class="td-image-wrap" title="Veeam anticipó novedades en su portfolio de soluciones de disponibilidad"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/n1-1.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/n1-1.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/n1-1.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/n1-1.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Veeam anticipó novedades en su portfolio de soluciones de disponibilidad"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/11/veeam-anticipo-novedades-en-su-portfolio-de-soluciones-de-disponibilidad/" rel="bookmark" title="Veeam anticipó novedades en su portfolio de soluciones de disponibilidad">Veeam anticipó novedades en su portfolio de soluciones de disponibilidad</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-11T17:59:06+00:00">11 septiembre, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span12 -->

	<div class="td-block-span12">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/11/veeam-nombra-nuevo-vicepresidente-de-ventas-para-america-latina-y-el-caribe/" rel="bookmark" class="td-image-wrap" title="Veeam nombra nuevo Vicepresidente de Ventas para América Latina y El Caribe"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Mauricio-Gonzalez_Veeam-1.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Mauricio-Gonzalez_Veeam-1.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Mauricio-Gonzalez_Veeam-1.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Mauricio-Gonzalez_Veeam-1.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Veeam nombra nuevo Vicepresidente de Ventas para América Latina y El Caribe"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/11/veeam-nombra-nuevo-vicepresidente-de-ventas-para-america-latina-y-el-caribe/" rel="bookmark" title="Veeam nombra nuevo Vicepresidente de Ventas para América Latina y El Caribe">Veeam nombra nuevo Vicepresidente de Ventas para América Latina y El...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-11T15:33:23+00:00">11 septiembre, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span12 -->

	<div class="td-block-span12">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/08/31/respete-las-caidas-por-que-las-interrupciones-son-tan-urgentes-como-las-amenazas-a-la-ciberseguridad/" rel="bookmark" class="td-image-wrap" title="Respete las caídas: por qué las interrupciones son tan urgentes como las amenazas a la ciberseguridad"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Respete las caídas: por qué las interrupciones son tan urgentes como las amenazas a la ciberseguridad"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/08/31/respete-las-caidas-por-que-las-interrupciones-son-tan-urgentes-como-las-amenazas-a-la-ciberseguridad/" rel="bookmark" title="Respete las caídas: por qué las interrupciones son tan urgentes como las amenazas a la ciberseguridad">Respete las caídas: por qué las interrupciones son tan urgentes como...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-08-31T11:02:59+00:00">31 agosto, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span12 --></div></div> <!-- ./block --><aside class="td_block_template_3 widget widget_text">			<div class="textwidget"><p><ins class="dcmads" style="display: inline-block; width: 300px; height: 250px; text-decoration: none;" data-dcm-placement="N410401.3657030ITWARELATAM.COM/B23030841.267588658" data-dcm-rendering-mode="iframe" data-dcm-https-only="" data-dcm-resettable-device-id="" data-dcm-app-id="" data-dcm-processed="y"><br>
  <script src="https://www.googletagservices.com/dcm/dcmads.js"></script><script src="https://www.googletagservices.com/dcm/impl_v63.js"></script><iframe marginwidth="0" marginheight="0" scrolling="no" frameborder="0" title="advertisement" src="https://ad.doubleclick.net/ddm/adi/N410401.3657030ITWARELATAM.COM/B23030841.267588658;dc_ver=63.178;sz=300x250;osdl=1;u_sd=3;dc_adk=1861669956;ord=r5c7y0;dc_rfl=0,https%3A%2F%2Fwww.itwarelatam.com%2F%23$0;xdt=0;crlt=bZQo6bIhy4;sttr=30;prcl=s" style="width: 100%; height: 100%; border: 0px; margin: 0px; padding: 0px;"></iframe><br>
</ins></p>
</div>
		</aside></div><div class="wpb_wrapper td_block_wrap vc_raw_html td_uid_31_5f8f778c389f2_rand "><div class="td-fix-index"><!-- BANNER NETSKOPE-->
<div id="container" align="center">
<href="https: resources.netskope.com="" webinars-on-demand="" trabajo-en-remoto-de-forma-segura-con-netskope"="" target="new">
<img src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/netskope_proteccion_trabajadores_remotos_banner_300x100.gif?w=696&amp;ssl=1" alt="" width="300" height="100">

<p></p>
</href="https:></div>


<!-- Smartfense -->
<div align="center"><a href="https://goconnect.licenciasonline.com/?utm_source=ItWare&amp;utm_medium=banner&amp;utm_campaign=website_goconnect" target="new"><img src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/SMARTFENSE-Banner300x250.gif?resize=300%2C250&amp;ssl=1" alt="" width="300" height="250">
</a></div></div></div>

<!-- <div class="wpb_wrapper td_block_wrap vc_raw_html td_uid_32_5f8f778c38a2b_rand ">
		<div class="td-fix-index">
			<a href="https://goconnect.licenciasonline.com/?utm_source=ItWare&amp;utm_medium=banner&amp;utm_campaign=website_goconnect" target="new">
		</a>

		<div id="container" align="center"><a href="https://goconnect.licenciasonline.com/?utm_source=ItWare&amp;utm_medium=banner&amp;utm_campaign=website_goconnect" target="new">
		    </a><a href="http://www.embluemail.com/solicitar-demo-email-marketing/" target="new">
		<img src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/mediaware-2020-1.png?w=696&amp;ssl=1" alt="" width="300" height="120">
		</a>
		</div></div>
</div> -->

<div class="wpb_wrapper td_block_wrap vc_raw_html td_uid_33_5f8f778c38a47_rand ">
	<div class="td-fix-index"><!-- BANNER DISENIA -->
		<div id="container" align="center">
		    <a href="https://www.diseniabox.com/" target="new">
		<img src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/disenia_banner_itwarelatam.gif?w=696&amp;ssl=1" alt="" width="300" height="120">
		</a>
		</div></div>
</div>

</div></div></div></div>
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_3_5f8f778be64f6 .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_3_5f8f778be64f6 .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

<!--<div id="td_uid_12_5f8f778c38bc4" class="tdc-row">
  <div class="vc_row vc_custom_1585781235461 td_uid_34_5f8f778c38bc8_rand  wpb_row td-pb-row">


<style scoped="">

/* tdc_composer_block - inline css att */
.vc_custom_1585781235461{background-color: #70b9ea !important;}
/* custom css */
.td_uid_34_5f8f778c38bc8_rand {
                    min-height: 0;
                }
</style>


<div class="vc_column td_uid_35_5f8f778c38dff_rand  wpb_column vc_column_container tdc-column td-pb-span12">

	<div class="wpb_wrapper">
		<section class="vc_cta3-container">
		<div class="vc_general vc_cta3 vc_cta3-style-3d vc_cta3-shape-rounded vc_cta3-align-left vc_cta3-color-black vc_cta3-icon-size-md vc_custom_1585781994098">
			<div class="vc_cta3_content-container">
				<div class="vc_cta3-content">
					<header class="vc_cta3-content-header"><h2 class="vc_custom_heading"><a href="https://http://www.caracasdigital.com/tag/coronavirus/" target=" _blank" title="Noticias sobre el coranavirus y el sector tecnológico">Coronavirus y el sector IT</a></h2>
					</header>
					<h2>#quedateencasa #somosresponsables #stayhome #staysafe #covid19</h2>
				</div>
			</div>
		</div>

</section>


<div class="td_block_wrap td_block_big_grid_7 vc_custom_1585781193564 td_uid_36_5f8f778c3af0a_rand td-grid-style-1 td-hover-1 td-big-grids td-pb-border-top td_block_template_3" data-td-block-uid="td_uid_36_5f8f778c3af0a">

<style>
/* custom css */


/* phone */
@media (max-width: 767px){
.td_uid_36_5f8f778c3af0a_rand .td_block_inner .td-big-grid-scroll .entry-title {
					@mx6f_title
				}
				.td_uid_36_5f8f778c3af0a_rand .td-big-grid-scroll .td-post-category {
					@mx6f_cat
				}
}
</style>

 <div id="td_uid_36_5f8f778c3af0a" class="td_block_inner">
	
	<div class="td-big-grid-wrapper">


        <div class="td_module_mx12 td-animation-stack td-big-grid-post-0 td-big-grid-post td-small-thumb">
            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/07/21/lenovo-apoya-a-las-comunidades-que-luchan-contra-el-covid-19-en-toda-america-latina/" rel="bookmark" class="td-image-wrap" title="Lenovo apoya a las comunidades que luchan contra el COVID-19 en toda América Latina"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/lenovo.jpg?resize=356%2C220&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/lenovo.jpg?resize=356%2C220&amp;ssl=1 356w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/lenovo.jpg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="Lenovo apoya a las comunidades que luchan contra el COVID-19 en toda América Latina"></a></div>            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                        <a href="https://http://www.caracasdigital.com/category/tipo-de-nota/opinion/" class="td-post-category">Opinion</a>                        <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/07/21/lenovo-apoya-a-las-comunidades-que-luchan-contra-el-covid-19-en-toda-america-latina/" rel="bookmark" title="Lenovo apoya a las comunidades que luchan contra el COVID-19 en toda América Latina">Lenovo apoya a las comunidades que luchan contra el COVID-19 en toda América Latina</a></h3>                    </div>
                    <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-21T10:53:41+00:00">21 julio, 2020</time></span>                    </div>
                </div>
            </div>

        </div>

        <div class="td-big-grid-scroll">


	        <div class="td_module_mx12 td-animation-stack td-big-grid-post-1 td-big-grid-post td-small-thumb">
	            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/07/08/tecnologia-y-compliance-grandes-desafios-en-epocas-de-covid19/" rel="bookmark" class="td-image-wrap" title="Tecnología y Compliance: Grandes Desafíos en épocas de Covid19."><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Complience6a.jpg?resize=356%2C220&amp;ssl=1" alt="" title="Tecnología y Compliance: Grandes Desafíos en épocas de Covid19."></a></div>            <div class="td-meta-info-container">
	                <div class="td-meta-align">
	                    <div class="td-big-grid-meta">
	                        <a href="https://http://www.caracasdigital.com/category/corporativo/seguridad/compliance/" class="td-post-category">Compliance</a>                        <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/07/08/tecnologia-y-compliance-grandes-desafios-en-epocas-de-covid19/" rel="bookmark" title="Tecnología y Compliance: Grandes Desafíos en épocas de Covid19.">Tecnología y Compliance: Grandes Desafíos en épocas de Covid19.</a></h3>                    </div>
	                    <div class="td-module-meta-info">
	                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-08T17:00:51+00:00">8 julio, 2020</time></span>                    </div>
	                </div>
	            </div>

	        </div>

	        
	        <div class="td_module_mx12 td-animation-stack td-big-grid-post-2 td-big-grid-post td-small-thumb">
	            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/07/07/complience-pymes-y-covid-19/" rel="bookmark" class="td-image-wrap" title="Compliance, PyMEs y COVID-19"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Complience1a.jpeg?resize=356%2C220&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Complience1a.jpeg?resize=356%2C220&amp;ssl=1 356w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Complience1a.jpeg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="Compliance, PyMEs y COVID-19"></a></div>            <div class="td-meta-info-container">
	                <div class="td-meta-align">
	                    <div class="td-big-grid-meta">
	                        <a href="https://http://www.caracasdigital.com/category/corporativo/seguridad/compliance/" class="td-post-category">Compliance</a>                        <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/07/07/complience-pymes-y-covid-19/" rel="bookmark" title="Compliance, PyMEs y COVID-19">Compliance, PyMEs y COVID-19</a></h3>                    </div>
	                    <div class="td-module-meta-info">
	                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-07T11:14:40+00:00">7 julio, 2020</time></span>                    </div>
	                </div>
	            </div>

	        </div>

	        
	        <div class="td_module_mx6 td-animation-stack td-big-grid-post-3 td-big-grid-post td-small-thumb">
	            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/06/10/creando-una-estrategia-efectiva-para-el-trabajo-remoto-los-efectos-de-la-pandemia-en-la-forma-de-trabajar/" rel="bookmark" class="td-image-wrap" title="Creando una estrategia efectiva para el trabajo remoto: los efectos de la pandemia en la forma de trabajar"><img width="265" height="198" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?resize=265%2C198&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?zoom=3&amp;resize=265%2C198&amp;ssl=1 795w" sizes="(max-width: 265px) 100vw, 265px" alt="" title="Creando una estrategia efectiva para el trabajo remoto: los efectos de la pandemia en la forma de trabajar"></a></div>            <div class="td-meta-info-container">
	                <div class="td-meta-align">
	                    <div class="td-big-grid-meta">
	                        <a href="https://http://www.caracasdigital.com/category/tipo-de-nota/opinion/" class="td-post-category">Opinion</a>                        <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/06/10/creando-una-estrategia-efectiva-para-el-trabajo-remoto-los-efectos-de-la-pandemia-en-la-forma-de-trabajar/" rel="bookmark" title="Creando una estrategia efectiva para el trabajo remoto: los efectos de la pandemia en la forma de trabajar">Creando una estrategia efectiva para el trabajo remoto: los efectos de la pandemia en la forma de trabajar</a></h3>                    </div>
	                </div>
	            </div>

	        </div>


	        
	        <div class="td_module_mx6 td-animation-stack td-big-grid-post-4 td-big-grid-post td-small-thumb">
	            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/05/26/tres-formas-de-asegurar-que-el-trabajo-remoto-sea-exitoso/" rel="bookmark" class="td-image-wrap" title="Tres formas de asegurar que el trabajo remoto sea exitoso"><img width="265" height="198" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=265%2C198&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?zoom=3&amp;resize=265%2C198&amp;ssl=1 795w" sizes="(max-width: 265px) 100vw, 265px" alt="" title="Tres formas de asegurar que el trabajo remoto sea exitoso"></a></div>            <div class="td-meta-info-container">
	                <div class="td-meta-align">
	                    <div class="td-big-grid-meta">
	                        <a href="https://http://www.caracasdigital.com/category/tipo-de-nota/opinion/" class="td-post-category">Opinion</a>                        <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/05/26/tres-formas-de-asegurar-que-el-trabajo-remoto-sea-exitoso/" rel="bookmark" title="Tres formas de asegurar que el trabajo remoto sea exitoso">Tres formas de asegurar que el trabajo remoto sea exitoso</a></h3>                    </div>
	                </div>
	            </div>

	        </div>


	        
	        <div class="td_module_mx6 td-animation-stack td-big-grid-post-5 td-big-grid-post td-small-thumb">
	            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/05/26/oracle-connect-como-seguir-transformandonos/" rel="bookmark" class="td-image-wrap" title="Oracle Connect: cómo seguir transformándonos"><img width="265" height="198" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?resize=265%2C198&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?zoom=3&amp;resize=265%2C198&amp;ssl=1 795w" sizes="(max-width: 265px) 100vw, 265px" alt="" title="Oracle Connect: cómo seguir transformándonos"></a></div>            <div class="td-meta-info-container">
	                <div class="td-meta-align">
	                    <div class="td-big-grid-meta">
	                        <a href="https://http://www.caracasdigital.com/category/tipo-de-nota/tendencias/" class="td-post-category">Tendencias</a>                        <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/05/26/oracle-connect-como-seguir-transformandonos/" rel="bookmark" title="Oracle Connect: cómo seguir transformándonos">Oracle Connect: cómo seguir transformándonos</a></h3>                    </div>
	                </div>
	            </div>

	        </div>


	        
	        <div class="td_module_mx6 td-animation-stack td-big-grid-post-6 td-big-grid-post td-small-thumb">
			            <div class="td-module-thumb">
			            	<a href="https://http://www.caracasdigital.com/2020/05/12/el-73-de-los-empleados-no-ha-recibido-orientacion-sobre-ciberseguridad-para-home-office/" rel="bookmark" class="td-image-wrap" title="El 73% de los empleados no ha recibido orientación sobre ciberseguridad para Home office"><img width="265" height="198" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?resize=265%2C198&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?resize=80%2C60&amp;ssl=1 80w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?resize=265%2C198&amp;ssl=1 265w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?resize=485%2C360&amp;ssl=1 485w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?zoom=3&amp;resize=265%2C198&amp;ssl=1 795w" sizes="(max-width: 265px) 100vw, 265px" alt="" title="El 73% de los empleados no ha recibido orientación sobre ciberseguridad para Home office"></a>
			            </div>            
			            <div class="td-meta-info-container">
			                <div class="td-meta-align">
			                    <div class="td-big-grid-meta">
			                        <a href="https://http://www.caracasdigital.com/category/corporativo/seguridad/ciberseguridad/" class="td-post-category">Ciberseguridad</a>                        <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/05/12/el-73-de-los-empleados-no-ha-recibido-orientacion-sobre-ciberseguridad-para-home-office/" rel="bookmark" title="El 73% de los empleados no ha recibido orientación sobre ciberseguridad para Home office">El 73% de los empleados no ha recibido orientación sobre ciberseguridad para Home office</a></h3>                    </div>
			                </div>
			            </div>

	       		 </div>


        </div>
    </div>

    <div class="clearfix"></div>
</div> 
</div>  ./block 
</div>
</div>


</div></div>-->
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_12_5f8f778c38bc4 .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_12_5f8f778c38bc4 .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

			<div id="td_uid_14_5f8f778c43fbc" class="tdc-row"><div class="vc_row td_uid_37_5f8f778c43fc4_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_37_5f8f778c43fc4_rand {
                    min-height: 0;
                }
</style><div class="vc_column td_uid_38_5f8f778c441ac_rand  wpb_column vc_column_container tdc-column td-pb-span12"><div class="wpb_wrapper"><div class="wpb_wrapper td_block_empty_space td_block_wrap vc_empty_space td_uid_39_5f8f778c442d9_rand " style="height: 32px"></div><div class="td_block_wrap td_block_1 td_uid_40_5f8f778c444e1_rand td-pb-border-top td_block_template_1 td-column-3" data-td-block-uid="td_uid_40_5f8f778c444e1">

	<script>var block_td_uid_40_5f8f778c444e1 = new tdBlock();
block_td_uid_40_5f8f778c444e1.id = "td_uid_40_5f8f778c444e1";
block_td_uid_40_5f8f778c444e1.atts = '{"custom_title":"EMPRESAS DEL SECTOR","custom_url":"https:\/\/www.itwarelatam.com\/category\/empresas-2\/","block_template_id":"td_block_template_1","category_id":"1305","limit":"9","td_ajax_filter_type":"td_category_ids_filter","separator":"","m4_tl":"","m4_el":"","m6_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","offset":"","el_class":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","m4f_title_font_header":"","m4f_title_font_title":"Article title","m4f_title_font_settings":"","m4f_title_font_family":"","m4f_title_font_size":"","m4f_title_font_line_height":"","m4f_title_font_style":"","m4f_title_font_weight":"","m4f_title_font_transform":"","m4f_title_font_spacing":"","m4f_title_":"","m4f_cat_font_title":"Article category tag","m4f_cat_font_settings":"","m4f_cat_font_family":"","m4f_cat_font_size":"","m4f_cat_font_line_height":"","m4f_cat_font_style":"","m4f_cat_font_weight":"","m4f_cat_font_transform":"","m4f_cat_font_spacing":"","m4f_cat_":"","m4f_meta_font_title":"Article meta info","m4f_meta_font_settings":"","m4f_meta_font_family":"","m4f_meta_font_size":"","m4f_meta_font_line_height":"","m4f_meta_font_style":"","m4f_meta_font_weight":"","m4f_meta_font_transform":"","m4f_meta_font_spacing":"","m4f_meta_":"","m4f_ex_font_title":"Article excerpt","m4f_ex_font_settings":"","m4f_ex_font_family":"","m4f_ex_font_size":"","m4f_ex_font_line_height":"","m4f_ex_font_style":"","m4f_ex_font_weight":"","m4f_ex_font_transform":"","m4f_ex_font_spacing":"","m4f_ex_":"","m6f_title_font_header":"","m6f_title_font_title":"Article title","m6f_title_font_settings":"","m6f_title_font_family":"","m6f_title_font_size":"","m6f_title_font_line_height":"","m6f_title_font_style":"","m6f_title_font_weight":"","m6f_title_font_transform":"","m6f_title_font_spacing":"","m6f_title_":"","m6f_cat_font_title":"Article category tag","m6f_cat_font_settings":"","m6f_cat_font_family":"","m6f_cat_font_size":"","m6f_cat_font_line_height":"","m6f_cat_font_style":"","m6f_cat_font_weight":"","m6f_cat_font_transform":"","m6f_cat_font_spacing":"","m6f_cat_":"","m6f_meta_font_title":"Article meta info","m6f_meta_font_settings":"","m6f_meta_font_family":"","m6f_meta_font_size":"","m6f_meta_font_line_height":"","m6f_meta_font_style":"","m6f_meta_font_weight":"","m6f_meta_font_transform":"","m6f_meta_font_spacing":"","m6f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":3,"header_color":"","color_preset":"","border_top":"","class":"td_uid_40_5f8f778c444e1_rand","tdc_css_class":"td_uid_40_5f8f778c444e1_rand","tdc_css_class_style":"td_uid_40_5f8f778c444e1_rand_style"}';
block_td_uid_40_5f8f778c444e1.td_column_number = "3";
block_td_uid_40_5f8f778c444e1.block_type = "td_block_1";
block_td_uid_40_5f8f778c444e1.post_count = "9";
block_td_uid_40_5f8f778c444e1.found_posts = "997";
block_td_uid_40_5f8f778c444e1.header_color = "";
block_td_uid_40_5f8f778c444e1.ajax_pagination_infinite_stop = "";
block_td_uid_40_5f8f778c444e1.max_num_pages = "111";
tdBlocksArray.push(block_td_uid_40_5f8f778c444e1);
</script>







<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->
<!---------------------------- MERCADEO -------------------------------------->


<div id="td_uid_11_5f9612fead140" class="tdc-row"><div class="vc_row vc_custom_1585781235461 td_uid_33_5f9612fead145_rand  wpb_row td-pb-row">
<style scoped="">

/* tdc_composer_block - inline css att */
.vc_custom_1585781235461{background-color:#087822 !important;}
/* custom css */
.td_uid_33_5f9612fead145_rand {
                    min-height: 0;
                }
</style><div class="vc_column td_uid_34_5f9612fead399_rand  wpb_column vc_column_container tdc-column td-pb-span12"><div class="wpb_wrapper"><section class="vc_cta3-container"><div class="vc_general vc_cta3 vc_cta3-style-3d vc_cta3-shape-rounded vc_cta3-align-left vc_cta3-color-black vc_cta3-icon-size-md vc_custom_1585781994098"><div class="vc_cta3_content-container"><div class="vc_cta3-content">

	<header class="vc_cta3-content-header">
	<!-- <h2 class="vc_custom_heading">
		<a href="https://www.itwarelatam.com/tag/coronavirus/" target=" _blank" title="Noticias sobre el coranavirus y el sector tecnológico">Negocios & Mercadeo</a>
	</h2> -->
	<img src="http://www.caracasdigital.com/images/caracasdigital-nm.png">
</header>
	
	<!-- <h2>#quedateencasa #somosresponsables #stayhome #staysafe #covid19</h2> -->
</div></div></div></section><div class="td_block_wrap td_block_big_grid_7 vc_custom_1585781193564 td_uid_35_5f9612feaf4fb_rand td-grid-style-1 td-hover-1 td-big-grids td-pb-border-top td_block_template_3" data-td-block-uid="td_uid_35_5f9612feaf4fb">
<style>
/* custom css */


/* phone */
@media (max-width: 767px){
.td_uid_35_5f9612feaf4fb_rand .td_block_inner .td-big-grid-scroll .entry-title {
					@mx6f_title
				}
				.td_uid_35_5f9612feaf4fb_rand .td-big-grid-scroll .td-post-category {
					@mx6f_cat
				}
}
</style><div id="td_uid_35_5f9612feaf4fb" class="td_block_inner"><div class="td-big-grid-wrapper">
        <div class="td_module_mx12 td-animation-stack td-big-grid-post-0 td-big-grid-post td-small-thumb">
            <div class="td-module-thumb"><a href="https://www.itwarelatam.com/2020/07/21/lenovo-apoya-a-las-comunidades-que-luchan-contra-el-covid-19-en-toda-america-latina/" rel="bookmark" class="td-image-wrap" title="Lenovo apoya a las comunidades que luchan contra el COVID-19 en toda América Latina"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-2" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/lenovo.jpg?resize=356%2C220&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/lenovo.jpg?resize=356%2C220&amp;ssl=1 356w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/lenovo.jpg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="Lenovo apoya a las comunidades que luchan contra el COVID-19 en toda América Latina"></a></div>            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                        <a href="https://www.itwarelatam.com/category/tipo-de-nota/opinion/" class="td-post-category">Opinion</a>                        <h3 class="entry-title td-module-title"><a href="https://www.itwarelatam.com/2020/07/21/lenovo-apoya-a-las-comunidades-que-luchan-contra-el-covid-19-en-toda-america-latina/" rel="bookmark" title="Lenovo apoya a las comunidades que luchan contra el COVID-19 en toda América Latina">Lenovo apoya a las comunidades que luchan contra el COVID-19 en toda América Latina</a></h3>                    </div>
                    <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-21T10:53:41+00:00">21 julio, 2020</time></span>                    </div>
                </div>
            </div>

        </div>

        <div class="td-big-grid-scroll">
        <div class="td_module_mx12 td-animation-stack td-big-grid-post-1 td-big-grid-post td-small-thumb">
            <div class="td-module-thumb"><a href="https://www.itwarelatam.com/2020/07/08/tecnologia-y-compliance-grandes-desafios-en-epocas-de-covid19/" rel="bookmark" class="td-image-wrap" title="Tecnología y Compliance: Grandes Desafíos en épocas de Covid19."><img width="356" height="220" class="entry-thumb td-animation-stack-type0-2" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Complience6a.jpg?resize=356%2C220&amp;ssl=1" alt="" title="Tecnología y Compliance: Grandes Desafíos en épocas de Covid19."></a></div>            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                        <a href="https://www.itwarelatam.com/category/corporativo/seguridad/compliance/" class="td-post-category">Compliance</a>                        <h3 class="entry-title td-module-title"><a href="https://www.itwarelatam.com/2020/07/08/tecnologia-y-compliance-grandes-desafios-en-epocas-de-covid19/" rel="bookmark" title="Tecnología y Compliance: Grandes Desafíos en épocas de Covid19.">Tecnología y Compliance: Grandes Desafíos en épocas de Covid19.</a></h3>                    </div>
                    <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-08T17:00:51+00:00">8 julio, 2020</time></span>                    </div>
                </div>
            </div>

        </div>

        
        <div class="td_module_mx12 td-animation-stack td-big-grid-post-2 td-big-grid-post td-small-thumb">
            <div class="td-module-thumb"><a href="https://www.itwarelatam.com/2020/07/07/complience-pymes-y-covid-19/" rel="bookmark" class="td-image-wrap" title="Compliance, PyMEs y COVID-19"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-2" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Complience1a.jpeg?resize=356%2C220&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Complience1a.jpeg?resize=356%2C220&amp;ssl=1 356w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Complience1a.jpeg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="Compliance, PyMEs y COVID-19"></a></div>            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                        <a href="https://www.itwarelatam.com/category/corporativo/seguridad/compliance/" class="td-post-category">Compliance</a>                        <h3 class="entry-title td-module-title"><a href="https://www.itwarelatam.com/2020/07/07/complience-pymes-y-covid-19/" rel="bookmark" title="Compliance, PyMEs y COVID-19">Compliance, PyMEs y COVID-19</a></h3>                    </div>
                    <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-07T11:14:40+00:00">7 julio, 2020</time></span>                    </div>
                </div>
            </div>

        </div>

        
        <div class="td_module_mx6 td-animation-stack td-big-grid-post-3 td-big-grid-post td-small-thumb">
            <div class="td-module-thumb"><a href="https://www.itwarelatam.com/2020/06/10/creando-una-estrategia-efectiva-para-el-trabajo-remoto-los-efectos-de-la-pandemia-en-la-forma-de-trabajar/" rel="bookmark" class="td-image-wrap" title="Creando una estrategia efectiva para el trabajo remoto: los efectos de la pandemia en la forma de trabajar"><img width="265" height="198" class="entry-thumb td-animation-stack-type0-2" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?resize=265%2C198&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Ruben_Belluomo_Infor.jpg?zoom=3&amp;resize=265%2C198&amp;ssl=1 795w" sizes="(max-width: 265px) 100vw, 265px" alt="" title="Creando una estrategia efectiva para el trabajo remoto: los efectos de la pandemia en la forma de trabajar"></a></div>            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                        <a href="https://www.itwarelatam.com/category/tipo-de-nota/opinion/" class="td-post-category">Opinion</a>                        <h3 class="entry-title td-module-title"><a href="https://www.itwarelatam.com/2020/06/10/creando-una-estrategia-efectiva-para-el-trabajo-remoto-los-efectos-de-la-pandemia-en-la-forma-de-trabajar/" rel="bookmark" title="Creando una estrategia efectiva para el trabajo remoto: los efectos de la pandemia en la forma de trabajar">Creando una estrategia efectiva para el trabajo remoto: los efectos de la pandemia en la forma de trabajar</a></h3>                    </div>
                </div>
            </div>

        </div>


        
        <div class="td_module_mx6 td-animation-stack td-big-grid-post-4 td-big-grid-post td-small-thumb">
            <div class="td-module-thumb"><a href="https://www.itwarelatam.com/2020/05/26/tres-formas-de-asegurar-que-el-trabajo-remoto-sea-exitoso/" rel="bookmark" class="td-image-wrap" title="Tres formas de asegurar que el trabajo remoto sea exitoso"><img width="265" height="198" class="entry-thumb td-animation-stack-type0-2" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=265%2C198&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Martín-Colombo-Veeam-Software.jpg?zoom=3&amp;resize=265%2C198&amp;ssl=1 795w" sizes="(max-width: 265px) 100vw, 265px" alt="" title="Tres formas de asegurar que el trabajo remoto sea exitoso"></a></div>            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                        <a href="https://www.itwarelatam.com/category/tipo-de-nota/opinion/" class="td-post-category">Opinion</a>                        <h3 class="entry-title td-module-title"><a href="https://www.itwarelatam.com/2020/05/26/tres-formas-de-asegurar-que-el-trabajo-remoto-sea-exitoso/" rel="bookmark" title="Tres formas de asegurar que el trabajo remoto sea exitoso">Tres formas de asegurar que el trabajo remoto sea exitoso</a></h3>                    </div>
                </div>
            </div>

        </div>


        
        <div class="td_module_mx6 td-animation-stack td-big-grid-post-5 td-big-grid-post td-small-thumb">
            <div class="td-module-thumb"><a href="https://www.itwarelatam.com/2020/05/26/oracle-connect-como-seguir-transformandonos/" rel="bookmark" class="td-image-wrap" title="Oracle Connect: cómo seguir transformándonos"><img width="265" height="198" class="entry-thumb td-animation-stack-type0-2" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?resize=265%2C198&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/Chris-Colbert-exdirector-general-de-Harvard-Innovation-LabsSe.jpg?zoom=3&amp;resize=265%2C198&amp;ssl=1 795w" sizes="(max-width: 265px) 100vw, 265px" alt="" title="Oracle Connect: cómo seguir transformándonos"></a></div>            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                        <a href="https://www.itwarelatam.com/category/tipo-de-nota/tendencias/" class="td-post-category">Tendencias</a>                        <h3 class="entry-title td-module-title"><a href="https://www.itwarelatam.com/2020/05/26/oracle-connect-como-seguir-transformandonos/" rel="bookmark" title="Oracle Connect: cómo seguir transformándonos">Oracle Connect: cómo seguir transformándonos</a></h3>                    </div>
                </div>
            </div>

        </div>


        
        <div class="td_module_mx6 td-animation-stack td-big-grid-post-6 td-big-grid-post td-small-thumb">
            <div class="td-module-thumb"><a href="https://www.itwarelatam.com/2020/05/12/el-73-de-los-empleados-no-ha-recibido-orientacion-sobre-ciberseguridad-para-home-office/" rel="bookmark" class="td-image-wrap" title="El 73% de los empleados no ha recibido orientación sobre ciberseguridad para Home office"><img width="265" height="198" class="entry-thumb td-animation-stack-type0-2" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?resize=265%2C198&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?resize=80%2C60&amp;ssl=1 80w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?resize=265%2C198&amp;ssl=1 265w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?resize=485%2C360&amp;ssl=1 485w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/report-covid-wfh-featured-900x592-1.jpg?zoom=3&amp;resize=265%2C198&amp;ssl=1 795w" sizes="(max-width: 265px) 100vw, 265px" alt="" title="El 73% de los empleados no ha recibido orientación sobre ciberseguridad para Home office"></a></div>            <div class="td-meta-info-container">
                <div class="td-meta-align">
                    <div class="td-big-grid-meta">
                        <a href="https://www.itwarelatam.com/category/corporativo/seguridad/ciberseguridad/" class="td-post-category">Ciberseguridad</a>                        <h3 class="entry-title td-module-title"><a href="https://www.itwarelatam.com/2020/05/12/el-73-de-los-empleados-no-ha-recibido-orientacion-sobre-ciberseguridad-para-home-office/" rel="bookmark" title="El 73% de los empleados no ha recibido orientación sobre ciberseguridad para Home office">El 73% de los empleados no ha recibido orientación sobre ciberseguridad para Home office</a></h3>                    </div>
                </div>
            </div>

        </div>


        </div></div><div class="clearfix"></div></div></div> <!-- ./block --></div></div></div></div>







<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->
<!---------------------------- FIN MERCADEO -------------------------------------->


<br>























<div class="td-block-title-wrap">

	<h4 class="block-title td-block-title"><a href="https://http://www.caracasdigital.com/category/empresas-2/" class="td-pulldown-size">EMPRESAS DEL SECTOR</a></h4>

	<div class="td-pulldown-syle-default td-subcat-filter" id="td_pulldown_td_uid_40_5f8f778c444e1">
		<ul class="td-subcat-list" id="td_pulldown_td_uid_40_5f8f778c444e1_list">				
			<li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1; margin-bottom: 5px;">
				<a class="td-subcat-link" id="td_uid_41_5f8f778c4b3c3" data-td_filter_value="" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">All</a>
			</li>
		</ul>
				<div class="td-subcat-dropdown" style=""><div class="td-subcat-more" aria-haspopup="true"><span>Más</span><i class="td-icon-read-down"></i></div><ul class="td-pulldown-filter-list"><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_42_5f8f778c4b3c7" data-td_filter_value="191" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Adquisiciones</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_43_5f8f778c4b3c9" data-td_filter_value="219" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Alianzas</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_44_5f8f778c4b3ca" data-td_filter_value="150" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Almacenamiento</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_45_5f8f778c4b3cc" data-td_filter_value="685" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Aplicaciones</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_46_5f8f778c4b3cd" data-td_filter_value="6870" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Arquitectura de seguridad</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_47_5f8f778c4b3ce" data-td_filter_value="276" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Big Data</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_48_5f8f778c4b3cf" data-td_filter_value="222" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">BYOD</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_49_5f8f778c4b3d0" data-td_filter_value="155" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Canales</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_50_5f8f778c4b3d2" data-td_filter_value="6686" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Ciberseguridad</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_51_5f8f778c4b3d3" data-td_filter_value="199" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Cloud</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_52_5f8f778c4b3d4" data-td_filter_value="835" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Colaboración</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_53_5f8f778c4b3d5" data-td_filter_value="424" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Comercio Electrónico</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_54_5f8f778c4b3d6" data-td_filter_value="7088" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Compliance</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_55_5f8f778c4b3d7" data-td_filter_value="966" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Comunicaciones</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_56_5f8f778c4b3d8" data-td_filter_value="2979" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Consultoría</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_57_5f8f778c4b3da" data-td_filter_value="1304" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Contact Centers</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_58_5f8f778c4b3db" data-td_filter_value="4541" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Corporativo</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_59_5f8f778c4b3dc" data-td_filter_value="226" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Data Centers</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_60_5f8f778c4b3dd" data-td_filter_value="1259" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">DC/POS</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_61_5f8f778c4b3de" data-td_filter_value="258" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Desarrolladores</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_62_5f8f778c4b3df" data-td_filter_value="6868" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Desarrollo de carrera</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_63_5f8f778c4b3e0" data-td_filter_value="5490" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Destacadas</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_64_5f8f778c4b3e1" data-td_filter_value="2509" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Emprendedorismo</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_65_5f8f778c4b3e2" data-td_filter_value="1305" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Empresas</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_66_5f8f778c4b3e3" data-td_filter_value="1854" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Energía</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_67_5f8f778c4b3e4" data-td_filter_value="724" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Entrenamiento</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_68_5f8f778c4b3e5" data-td_filter_value="6874" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Evaluación de riesgos</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_69_5f8f778c4b3e6" data-td_filter_value="195" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Eventos</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_70_5f8f778c4b3e7" data-td_filter_value="6941" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Expertos</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_71_5f8f778c4b3e8" data-td_filter_value="596" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Fotografía</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_72_5f8f778c4b3e9" data-td_filter_value="6869" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Framework y Gobernanza</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_73_5f8f778c4b3ea" data-td_filter_value="3719" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Gadgets</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_74_5f8f778c4b3eb" data-td_filter_value="305" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Hardware</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_75_5f8f778c4b3f8" data-td_filter_value="151" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Infraestructura</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_76_5f8f778c4b3f9" data-td_filter_value="6872" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Inteligencia de amenazas</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_77_5f8f778c4b3fa" data-td_filter_value="192" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Internet</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_78_5f8f778c4b3fb" data-td_filter_value="234" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Internet of Things</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_79_5f8f778c4b3fc" data-td_filter_value="5570" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Leading Case</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_80_5f8f778c4b3fd" data-td_filter_value="1009" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Marketing</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_81_5f8f778c4b3fe" data-td_filter_value="149" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Movilidad</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_82_5f8f778c4b3ff" data-td_filter_value="154" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Networking</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_83_5f8f778c4b400" data-td_filter_value="264" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Nombramientos</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_84_5f8f778c4b401" data-td_filter_value="316" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Open Source</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_85_5f8f778c4b407" data-td_filter_value="6871" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Operación de seguridad</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_86_5f8f778c4b408" data-td_filter_value="974" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Opinion</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_87_5f8f778c4b409" data-td_filter_value="4542" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Productos</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_88_5f8f778c4b40a" data-td_filter_value="639" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Responsabilidad Social</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_89_5f8f778c4b40b" data-td_filter_value="1095" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Review</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_90_5f8f778c4b40c" data-td_filter_value="313" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Revista Digital</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_91_5f8f778c4b40d" data-td_filter_value="642" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Sector Educación</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_92_5f8f778c4b40e" data-td_filter_value="193" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Sector Gobierno</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_93_5f8f778c4b40f" data-td_filter_value="1169" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Sector Retail</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_94_5f8f778c4b410" data-td_filter_value="153" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Seguridad</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_95_5f8f778c4b411" data-td_filter_value="6687" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Seguridad Electrónica</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_96_5f8f778c4b412" data-td_filter_value="794" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Servidores</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_97_5f8f778c4b413" data-td_filter_value="152" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Software &amp; Servicios</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_98_5f8f778c4b414" data-td_filter_value="346" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Telecomunicaciones</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_99_5f8f778c4b415" data-td_filter_value="196" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Tendencias</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_100_5f8f778c4b416" data-td_filter_value="4540" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Tipo de nota</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_101_5f8f778c4b417" data-td_filter_value="209" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">UC</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_102_5f8f778c4b418" data-td_filter_value="979" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Videoentrevistas</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_103_5f8f778c4b419" data-td_filter_value="329" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Virtualización</a></li><li class="td-subcat-item" style="transition: opacity 0.2s ease 0s; opacity: 1;"><a class="td-subcat-link" id="td_uid_104_5f8f778c4b41a" data-td_filter_value="6938" data-td_block_id="td_uid_40_5f8f778c444e1" href="#">Voces</a></li></ul></div></div></div><div id="td_uid_40_5f8f778c444e1" class="td_block_inner">

	<div class="td-block-row">

	<div class="td-block-span4">

        <div class="td_module_4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/19/hipernet-se-asocia-con-solidworks/" rel="bookmark" class="td-image-wrap" title="Hipernet se asocia con SolidWorks"><img width="324" height="235" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/hipernet.jpg?resize=324%2C235&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/hipernet.jpg?resize=324%2C235&amp;ssl=1 324w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/hipernet.jpg?zoom=2&amp;resize=324%2C235&amp;ssl=1 648w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/hipernet.jpg?zoom=3&amp;resize=324%2C235&amp;ssl=1 972w" sizes="(max-width: 324px) 100vw, 324px" alt="" title="Hipernet se asocia con SolidWorks"></a></div>                <a href="https://http://www.caracasdigital.com/category/empresas-2/alianzas/" class="td-post-category">Alianzas</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/19/hipernet-se-asocia-con-solidworks/" rel="bookmark" title="Hipernet se asocia con SolidWorks">Hipernet se asocia con SolidWorks</a></h3>
            <div class="td-module-meta-info">
                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-19T18:18:59+00:00">19 octubre, 2020</time></span>                            </div>

            <div class="td-excerpt">
                            </div>

            
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/16/llega-el-eretail-week-america-central-y-el-caribe-online-live-experience/" rel="bookmark" class="td-image-wrap" title="Llega el eRetail Week América Central y el Caribe Online [Live] experience"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/IMG_16102020_155816_1000_x_600_pixel.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/IMG_16102020_155816_1000_x_600_pixel.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/IMG_16102020_155816_1000_x_600_pixel.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/IMG_16102020_155816_1000_x_600_pixel.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Llega el eRetail Week América Central y el Caribe Online [Live] experience"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/16/llega-el-eretail-week-america-central-y-el-caribe-online-live-experience/" rel="bookmark" title="Llega el eRetail Week América Central y el Caribe Online [Live] experience">Llega el eRetail Week América Central y el Caribe Online [Live]...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-16T20:42:07+00:00">16 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/auriga-abre-su-primera-sede-en-latinoamerica/" rel="bookmark" class="td-image-wrap" title="Auriga abre su primera sede en Latinoamérica"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Auriga_-CEO-_-Vincenzo-Fiore.png?resize=100%2C70&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Auriga_-CEO-_-Vincenzo-Fiore.png?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Auriga_-CEO-_-Vincenzo-Fiore.png?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Auriga_-CEO-_-Vincenzo-Fiore.png?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Auriga abre su primera sede en Latinoamérica"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/auriga-abre-su-primera-sede-en-latinoamerica/" rel="bookmark" title="Auriga abre su primera sede en Latinoamérica">Auriga abre su primera sede en Latinoamérica</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-15T11:13:35+00:00">15 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/sap-designa-nuevo-coo-para-la-region-sur-de-latinoamerica/" rel="bookmark" class="td-image-wrap" title="SAP designa nuevo COO para la Región Sur de Latinoamérica"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Esteban_Samartin_SAP.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Esteban_Samartin_SAP.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Esteban_Samartin_SAP.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Esteban_Samartin_SAP.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="SAP designa nuevo COO para la Región Sur de Latinoamérica"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/sap-designa-nuevo-coo-para-la-region-sur-de-latinoamerica/" rel="bookmark" title="SAP designa nuevo COO para la Región Sur de Latinoamérica">SAP designa nuevo COO para la Región Sur de Latinoamérica</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-15T11:06:56+00:00">15 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/furukawa-distribuira-la-linea-de-productos-gofoton-en-latinoamerica/" rel="bookmark" class="td-image-wrap" title="Furukawa distribuirá la línea de productos Go!Foton en Latinoamérica"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/GoFoton.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/GoFoton.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/GoFoton.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/GoFoton.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Furukawa distribuirá la línea de productos Go!Foton en Latinoamérica"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/furukawa-distribuira-la-linea-de-productos-gofoton-en-latinoamerica/" rel="bookmark" title="Furukawa distribuirá la línea de productos Go!Foton en Latinoamérica">Furukawa distribuirá la línea de productos Go!Foton en Latinoamérica</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-15T10:57:23+00:00">15 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/13/avaya-designa-nuevo-director-general-en-mexico/" rel="bookmark" class="td-image-wrap" title="Avaya designa nuevo Director General en México"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Fernando-Ruiz-Galindo-Avaya.png?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Fernando-Ruiz-Galindo-Avaya.png?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Fernando-Ruiz-Galindo-Avaya.png?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Fernando-Ruiz-Galindo-Avaya.png?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Avaya designa nuevo Director General en México"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/13/avaya-designa-nuevo-director-general-en-mexico/" rel="bookmark" title="Avaya designa nuevo Director General en México">Avaya designa nuevo Director General en México</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-13T15:38:57+00:00">13 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/13/netskope-amplia-su-plantilla-en-america-latina/" rel="bookmark" class="td-image-wrap" title="Netskope amplía su plantilla  en América Latina"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Carlos-Jardim_-Sales-Engineer-Manager-Netskope-Latam_2.png?resize=100%2C70&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Carlos-Jardim_-Sales-Engineer-Manager-Netskope-Latam_2.png?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Carlos-Jardim_-Sales-Engineer-Manager-Netskope-Latam_2.png?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Carlos-Jardim_-Sales-Engineer-Manager-Netskope-Latam_2.png?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Netskope amplía su plantilla  en América Latina"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/13/netskope-amplia-su-plantilla-en-america-latina/" rel="bookmark" title="Netskope amplía su plantilla  en América Latina">Netskope amplía su plantilla  en América Latina</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-13T10:12:03+00:00">13 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/08/veeam-busca-acelerar-la-proteccion-de-cargas-de-trabajo-nativas-de-kubernetes/" rel="bookmark" class="td-image-wrap" title="Veeam busca acelerar la protección de cargas de trabajo nativas de Kubernetes"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Danny_Allan_VeeamON2020.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Danny_Allan_VeeamON2020.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Danny_Allan_VeeamON2020.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/Danny_Allan_VeeamON2020.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Veeam busca acelerar la protección de cargas de trabajo nativas de Kubernetes"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/08/veeam-busca-acelerar-la-proteccion-de-cargas-de-trabajo-nativas-de-kubernetes/" rel="bookmark" title="Veeam busca acelerar la protección de cargas de trabajo nativas de Kubernetes">Veeam busca acelerar la protección de cargas de trabajo nativas de...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-08T09:13:53+00:00">8 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/06/zoom-y-lumen-se-asocian-para-proveer-una-experiencia-de-colaboracion-mejorada/" rel="bookmark" class="td-image-wrap" title="Zoom y Lumen se asocian para proveer una experiencia de colaboración mejorada"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/lumen.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/lumen.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/lumen.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/lumen.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Zoom y Lumen se asocian para proveer una experiencia de colaboración mejorada"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/06/zoom-y-lumen-se-asocian-para-proveer-una-experiencia-de-colaboracion-mejorada/" rel="bookmark" title="Zoom y Lumen se asocian para proveer una experiencia de colaboración mejorada">Zoom y Lumen se asocian para proveer una experiencia de colaboración...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-06T10:03:07+00:00">6 octubre, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span4 --></div><!--./row-fluid--></div></div> <!-- ./block --><div class="td_block_wrap td_block_1 vc_custom_1586051327594 td_uid_105_5f8f778c5265f_rand td-pb-border-top td_block_template_1 td-column-3" data-td-block-uid="td_uid_105_5f8f778c5265f"><script>var block_td_uid_105_5f8f778c5265f = new tdBlock();
block_td_uid_105_5f8f778c5265f.id = "td_uid_105_5f8f778c5265f";
block_td_uid_105_5f8f778c5265f.atts = '{"custom_title":"CANALES, MAYORISTAS Y DISTRIBUIDORES","custom_url":"https:\/\/www.itwarelatam.com\/category\/canales\/","block_template_id":"td_block_template_1","category_id":"155","limit":"9","css":".vc_custom_1586051327594{padding-top: 10px !important;padding-right: 10px !important;padding-bottom: 10px !important;padding-left: 10px !important;background-color: #e8e8e8 !important;}","separator":"","m4_tl":"","m4_el":"","m6_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","m4f_title_font_header":"","m4f_title_font_title":"Article title","m4f_title_font_settings":"","m4f_title_font_family":"","m4f_title_font_size":"","m4f_title_font_line_height":"","m4f_title_font_style":"","m4f_title_font_weight":"","m4f_title_font_transform":"","m4f_title_font_spacing":"","m4f_title_":"","m4f_cat_font_title":"Article category tag","m4f_cat_font_settings":"","m4f_cat_font_family":"","m4f_cat_font_size":"","m4f_cat_font_line_height":"","m4f_cat_font_style":"","m4f_cat_font_weight":"","m4f_cat_font_transform":"","m4f_cat_font_spacing":"","m4f_cat_":"","m4f_meta_font_title":"Article meta info","m4f_meta_font_settings":"","m4f_meta_font_family":"","m4f_meta_font_size":"","m4f_meta_font_line_height":"","m4f_meta_font_style":"","m4f_meta_font_weight":"","m4f_meta_font_transform":"","m4f_meta_font_spacing":"","m4f_meta_":"","m4f_ex_font_title":"Article excerpt","m4f_ex_font_settings":"","m4f_ex_font_family":"","m4f_ex_font_size":"","m4f_ex_font_line_height":"","m4f_ex_font_style":"","m4f_ex_font_weight":"","m4f_ex_font_transform":"","m4f_ex_font_spacing":"","m4f_ex_":"","m6f_title_font_header":"","m6f_title_font_title":"Article title","m6f_title_font_settings":"","m6f_title_font_family":"","m6f_title_font_size":"","m6f_title_font_line_height":"","m6f_title_font_style":"","m6f_title_font_weight":"","m6f_title_font_transform":"","m6f_title_font_spacing":"","m6f_title_":"","m6f_cat_font_title":"Article category tag","m6f_cat_font_settings":"","m6f_cat_font_family":"","m6f_cat_font_size":"","m6f_cat_font_line_height":"","m6f_cat_font_style":"","m6f_cat_font_weight":"","m6f_cat_font_transform":"","m6f_cat_font_spacing":"","m6f_cat_":"","m6f_meta_font_title":"Article meta info","m6f_meta_font_settings":"","m6f_meta_font_family":"","m6f_meta_font_size":"","m6f_meta_font_line_height":"","m6f_meta_font_style":"","m6f_meta_font_weight":"","m6f_meta_font_transform":"","m6f_meta_font_spacing":"","m6f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","tdc_css":"","td_column_number":3,"header_color":"","color_preset":"","border_top":"","class":"td_uid_105_5f8f778c5265f_rand","tdc_css_class":"td_uid_105_5f8f778c5265f_rand","tdc_css_class_style":"td_uid_105_5f8f778c5265f_rand_style"}';
block_td_uid_105_5f8f778c5265f.td_column_number = "3";
block_td_uid_105_5f8f778c5265f.block_type = "td_block_1";
block_td_uid_105_5f8f778c5265f.post_count = "9";
block_td_uid_105_5f8f778c5265f.found_posts = "578";
block_td_uid_105_5f8f778c5265f.header_color = "";
block_td_uid_105_5f8f778c5265f.ajax_pagination_infinite_stop = "";
block_td_uid_105_5f8f778c5265f.max_num_pages = "65";
tdBlocksArray.push(block_td_uid_105_5f8f778c5265f);
</script>

<div class="td-block-title-wrap">
	<h4 class="block-title td-block-title"><a href="https://http://www.caracasdigital.com/category/canales/" class="td-pulldown-size">CANALES, MAYORISTAS Y DISTRIBUIDORES</a></h4></div><div id="td_uid_105_5f8f778c5265f" class="td_block_inner">

	<div class="td-block-row">

	<div class="td-block-span4">

        <div class="td_module_4 td_module_wrap td-animation-stack">
            <div class="td-module-image">
                <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/16/llega-una-nueva-edicion-del-red-hat-forum-a-america-latina-from-here-anywhere/" rel="bookmark" class="td-image-wrap" title="Llega una nueva edición del Red Hat Forum a América Latina  “From here, anywhere”"><img width="324" height="235" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Red-Hat-Forum.jpg?resize=324%2C235&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Red-Hat-Forum.jpg?resize=324%2C235&amp;ssl=1 324w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Red-Hat-Forum.jpg?zoom=2&amp;resize=324%2C235&amp;ssl=1 648w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Red-Hat-Forum.jpg?zoom=3&amp;resize=324%2C235&amp;ssl=1 972w" sizes="(max-width: 324px) 100vw, 324px" alt="" title="Llega una nueva edición del Red Hat Forum a América Latina  “From here, anywhere”"></a></div>                <a href="https://http://www.caracasdigital.com/category/tipo-de-nota/eventos/" class="td-post-category">Eventos</a>            </div>

            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/16/llega-una-nueva-edicion-del-red-hat-forum-a-america-latina-from-here-anywhere/" rel="bookmark" title="Llega una nueva edición del Red Hat Forum a América Latina  “From here, anywhere”">Llega una nueva edición del Red Hat Forum a América Latina...</a></h3>
            <div class="td-module-meta-info">
                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-16T17:39:34+00:00">16 septiembre, 2020</time></span>                            </div>

            <div class="td-excerpt">
                            </div>

            
        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/16/aplicaciones-nativas-tendencias-y-oportunidades-para-el-canal/" rel="bookmark" class="td-image-wrap" title="Aplicaciones nativas: tendencias y oportunidades para el canal"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Johny-Andres-Jimenez-Ortiz_LOL.png?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Johny-Andres-Jimenez-Ortiz_LOL.png?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Johny-Andres-Jimenez-Ortiz_LOL.png?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Johny-Andres-Jimenez-Ortiz_LOL.png?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Aplicaciones nativas: tendencias y oportunidades para el canal"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/16/aplicaciones-nativas-tendencias-y-oportunidades-para-el-canal/" rel="bookmark" title="Aplicaciones nativas: tendencias y oportunidades para el canal">Aplicaciones nativas: tendencias y oportunidades para el canal</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-16T17:17:26+00:00">16 septiembre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/09/licencias-online-presenta-las-opciones-para-apoyar-financieramente-a-sus-partners/" rel="bookmark" class="td-image-wrap" title="Licencias OnLine presenta las opciones para apoyar financieramente a sus partners"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/finanzas_lol.png?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/finanzas_lol.png?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/finanzas_lol.png?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/finanzas_lol.png?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Licencias OnLine presenta las opciones para apoyar financieramente a sus partners"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/09/licencias-online-presenta-las-opciones-para-apoyar-financieramente-a-sus-partners/" rel="bookmark" title="Licencias OnLine presenta las opciones para apoyar financieramente a sus partners">Licencias OnLine presenta las opciones para apoyar financieramente a sus partners</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-09T15:12:21+00:00">9 septiembre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/03/licencias-online-consolida-la-operacion-cloud-en-ecuador/" rel="bookmark" class="td-image-wrap" title="Licencias OnLine consolida la operación Cloud en Ecuador"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/IMG_02092020_120839_1000_x_600_pixel.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/IMG_02092020_120839_1000_x_600_pixel.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/IMG_02092020_120839_1000_x_600_pixel.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/IMG_02092020_120839_1000_x_600_pixel.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Licencias OnLine consolida la operación Cloud en Ecuador"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/03/licencias-online-consolida-la-operacion-cloud-en-ecuador/" rel="bookmark" title="Licencias OnLine consolida la operación Cloud en Ecuador">Licencias OnLine consolida la operación Cloud en Ecuador</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-03T12:08:27+00:00">3 septiembre, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/08/26/licencias-online-y-check-point-realizaron-su-cloud-journet-safety/" rel="bookmark" class="td-image-wrap" title="Licencias OnLine y Check Point realizaron su “Cloud Journet Safety”"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2018/01/Pablo_Barriga_Licencias_OnLine.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2018/01/Pablo_Barriga_Licencias_OnLine.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2018/01/Pablo_Barriga_Licencias_OnLine.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2018/01/Pablo_Barriga_Licencias_OnLine.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Licencias OnLine y Check Point realizaron su “Cloud Journet Safety”"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/08/26/licencias-online-y-check-point-realizaron-su-cloud-journet-safety/" rel="bookmark" title="Licencias OnLine y Check Point realizaron su “Cloud Journet Safety”">Licencias OnLine y Check Point realizaron su “Cloud Journet Safety”</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-08-26T18:13:47+00:00">26 agosto, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span4 -->

	<div class="td-block-span4">

        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/08/24/veeam-backup-365-por-que-es-importante-hacer-un-backup-de-office/" rel="bookmark" class="td-image-wrap" title="Veeam Backup 365 ¿Por qué es importante hacer un backup de Office?"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/Juan-Francisco-Tapia-Ingeniero-Preventa-en-Licencias-OnLine.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/Juan-Francisco-Tapia-Ingeniero-Preventa-en-Licencias-OnLine.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/Juan-Francisco-Tapia-Ingeniero-Preventa-en-Licencias-OnLine.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/Juan-Francisco-Tapia-Ingeniero-Preventa-en-Licencias-OnLine.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Veeam Backup 365 ¿Por qué es importante hacer un backup de Office?"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/08/24/veeam-backup-365-por-que-es-importante-hacer-un-backup-de-office/" rel="bookmark" title="Veeam Backup 365 ¿Por qué es importante hacer un backup de Office?">Veeam Backup 365 ¿Por qué es importante hacer un backup de...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-08-24T13:10:47+00:00">24 agosto, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/08/14/intcomex-anuncia-un-acuerdo-para-la-adquisicion-de-la-operacion-de-scansource/" rel="bookmark" class="td-image-wrap" title="Intcomex anuncia un acuerdo para la adquisición de la operación de ScanSource"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/scansource.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/scansource.jpg?resize=100%2C70&amp;ssl=1 100w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/scansource.jpg?resize=218%2C150&amp;ssl=1 218w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/scansource.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Intcomex anuncia un acuerdo para la adquisición de la operación de ScanSource"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/08/14/intcomex-anuncia-un-acuerdo-para-la-adquisicion-de-la-operacion-de-scansource/" rel="bookmark" title="Intcomex anuncia un acuerdo para la adquisición de la operación de ScanSource">Intcomex anuncia un acuerdo para la adquisición de la operación de...</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-08-14T15:19:01+00:00">14 agosto, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/07/30/licencias-online-presenta-su-alianza-con-red-hat-en-la-region/" rel="bookmark" class="td-image-wrap" title="Licencias OnLine presenta su alianza con Red Hat en la región"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Licencias-OnLine_Red-Hat.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Licencias-OnLine_Red-Hat.jpg?resize=100%2C70&amp;ssl=1 100w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Licencias-OnLine_Red-Hat.jpg?resize=218%2C150&amp;ssl=1 218w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Licencias-OnLine_Red-Hat.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Licencias OnLine presenta su alianza con Red Hat en la región"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/07/30/licencias-online-presenta-su-alianza-con-red-hat-en-la-region/" rel="bookmark" title="Licencias OnLine presenta su alianza con Red Hat en la región">Licencias OnLine presenta su alianza con Red Hat en la región</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-30T08:54:37+00:00">30 julio, 2020</time></span>                            </div>
        </div>

        </div>

        
        <div class="td_module_6 td_module_wrap td-animation-stack">

        <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/07/23/licencias-online-comercializa-las-soluciones-de-aqua-security-en-latinoamerica/" rel="bookmark" class="td-image-wrap" title="Licencias OnLine comercializa las soluciones de Aqua Security en Latinoamérica"><img width="100" height="70" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Carolina_bozza_AS.jpg?resize=100%2C70&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Carolina_bozza_AS.jpg?resize=100%2C70&amp;ssl=1 100w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Carolina_bozza_AS.jpg?resize=218%2C150&amp;ssl=1 218w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Carolina_bozza_AS.jpg?zoom=3&amp;resize=100%2C70&amp;ssl=1 300w" sizes="(max-width: 100px) 100vw, 100px" alt="" title="Licencias OnLine comercializa las soluciones de Aqua Security en Latinoamérica"></a></div>
        <div class="item-details">
            <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/07/23/licencias-online-comercializa-las-soluciones-de-aqua-security-en-latinoamerica/" rel="bookmark" title="Licencias OnLine comercializa las soluciones de Aqua Security en Latinoamérica">Licencias OnLine comercializa las soluciones de Aqua Security en Latinoamérica</a></h3>            <div class="td-module-meta-info">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-23T09:36:01+00:00">23 julio, 2020</time></span>                            </div>
        </div>

        </div>

        
	</div> <!-- ./td-block-span4 --></div><!--./row-fluid--></div></div> <!-- ./block --><div class="vc_row_inner td_uid_106_5f8f778c5ea55_rand  vc_row vc_inner wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_106_5f8f778c5ea55_rand {
                    position: relative !important;
                    top: 0;
                    transform: none;
                    -webkit-transform: none;
                }
</style><div class="vc_column_inner td_uid_107_5f8f778c5ec30_rand  wpb_column vc_column_container tdc-inner-column td-pb-span4"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div><div class="vc_column_inner td_uid_108_5f8f778c5ec93_rand  wpb_column vc_column_container tdc-inner-column td-pb-span4"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div><div class="vc_column_inner td_uid_109_5f8f778c5ecd0_rand  wpb_column vc_column_container tdc-inner-column td-pb-span4"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div></div></div></div></div></div>
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_14_5f8f778c43fbc .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_14_5f8f778c43fbc .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

			<div id="td_uid_21_5f8f778c5ee45" class="tdc-row"><div class="vc_row td_uid_110_5f8f778c5ee4b_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_110_5f8f778c5ee4b_rand {
                    min-height: 0;
                }
</style><div class="vc_column td_uid_111_5f8f778c5f008_rand  wpb_column vc_column_container tdc-column td-pb-span12"><div class="wpb_wrapper"></div></div></div></div>
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_21_5f8f778c5ee45 .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_21_5f8f778c5ee45 .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

			<div id="td_uid_23_5f8f778c5f06d" class="tdc-row"><div class="vc_row td_uid_112_5f8f778c5f070_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_112_5f8f778c5f070_rand {
                    min-height: 0;
                }
</style><div class="vc_column td_uid_113_5f8f778c5f20a_rand  wpb_column vc_column_container tdc-column td-pb-span4"><div class="wpb_wrapper"><div class="td_block_wrap td_block_19 td_uid_114_5f8f778c5f4fe_rand td-pb-border-top td_block_template_10 td-column-1" data-td-block-uid="td_uid_114_5f8f778c5f4fe"><script>var block_td_uid_114_5f8f778c5f4fe = new tdBlock();
block_td_uid_114_5f8f778c5f4fe.id = "td_uid_114_5f8f778c5f4fe";
block_td_uid_114_5f8f778c5f4fe.atts = '{"custom_title":"INTERNET","custom_url":"https:\/\/www.itwarelatam.com\/category\/tipo-de-nota\/internet\/","block_template_id":"td_block_template_10","category_id":"192","separator":"","mx1_tl":"","mx2_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","limit":"5","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx1f_title_font_header":"","mx1f_title_font_title":"Article title","mx1f_title_font_settings":"","mx1f_title_font_family":"","mx1f_title_font_size":"","mx1f_title_font_line_height":"","mx1f_title_font_style":"","mx1f_title_font_weight":"","mx1f_title_font_transform":"","mx1f_title_font_spacing":"","mx1f_title_":"","mx1f_cat_font_title":"Article category tag","mx1f_cat_font_settings":"","mx1f_cat_font_family":"","mx1f_cat_font_size":"","mx1f_cat_font_line_height":"","mx1f_cat_font_style":"","mx1f_cat_font_weight":"","mx1f_cat_font_transform":"","mx1f_cat_font_spacing":"","mx1f_cat_":"","mx1f_meta_font_title":"Article meta info","mx1f_meta_font_settings":"","mx1f_meta_font_family":"","mx1f_meta_font_size":"","mx1f_meta_font_line_height":"","mx1f_meta_font_style":"","mx1f_meta_font_weight":"","mx1f_meta_font_transform":"","mx1f_meta_font_spacing":"","mx1f_meta_":"","mx2f_title_font_header":"","mx2f_title_font_title":"Article title","mx2f_title_font_settings":"","mx2f_title_font_family":"","mx2f_title_font_size":"","mx2f_title_font_line_height":"","mx2f_title_font_style":"","mx2f_title_font_weight":"","mx2f_title_font_transform":"","mx2f_title_font_spacing":"","mx2f_title_":"","mx2f_cat_font_title":"Article category tag","mx2f_cat_font_settings":"","mx2f_cat_font_family":"","mx2f_cat_font_size":"","mx2f_cat_font_line_height":"","mx2f_cat_font_style":"","mx2f_cat_font_weight":"","mx2f_cat_font_transform":"","mx2f_cat_font_spacing":"","mx2f_cat_":"","mx2f_meta_font_title":"Article meta info","mx2f_meta_font_settings":"","mx2f_meta_font_family":"","mx2f_meta_font_size":"","mx2f_meta_font_line_height":"","mx2f_meta_font_style":"","mx2f_meta_font_weight":"","mx2f_meta_font_transform":"","mx2f_meta_font_spacing":"","mx2f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":1,"header_color":"","color_preset":"","border_top":"","class":"td_uid_114_5f8f778c5f4fe_rand","tdc_css_class":"td_uid_114_5f8f778c5f4fe_rand","tdc_css_class_style":"td_uid_114_5f8f778c5f4fe_rand_style"}';
block_td_uid_114_5f8f778c5f4fe.td_column_number = "1";
block_td_uid_114_5f8f778c5f4fe.block_type = "td_block_19";
block_td_uid_114_5f8f778c5f4fe.post_count = "5";
block_td_uid_114_5f8f778c5f4fe.found_posts = "57";
block_td_uid_114_5f8f778c5f4fe.header_color = "";
block_td_uid_114_5f8f778c5f4fe.ajax_pagination_infinite_stop = "";
block_td_uid_114_5f8f778c5f4fe.max_num_pages = "12";
tdBlocksArray.push(block_td_uid_114_5f8f778c5f4fe);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/category/tipo-de-nota/internet/" class="td-pulldown-size">INTERNET</a></h4></div><div id="td_uid_114_5f8f778c5f4fe" class="td_block_inner td-column-1">
        <div class="td_module_mx1 td_module_wrap td-animation-stack">
            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/08/06/dish-selecciona-a-vmware-para-ayudar-a-construir-la-red-5g-de-extremo-a-extremo-en-ee-uu/" rel="bookmark" class="td-image-wrap" title="DISH selecciona a VMware para ayudar a construir la red 5G de extremo a extremo en EE.UU."><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/5G_VMware.jpg?resize=356%2C220&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/5G_VMware.jpg?resize=356%2C220&amp;ssl=1 356w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/08/5G_VMware.jpg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="DISH selecciona a VMware para ayudar a construir la red 5G de extremo a extremo en EE.UU."></a></div>
            <div class="td-module-meta-info">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/08/06/dish-selecciona-a-vmware-para-ayudar-a-construir-la-red-5g-de-extremo-a-extremo-en-ee-uu/" rel="bookmark" title="DISH selecciona a VMware para ayudar a construir la red 5G de extremo a extremo en EE.UU.">DISH selecciona a VMware para ayudar a construir la red 5G de extremo a extremo en EE.UU.</a></h3>                <div class="td-editor-date">
                    <a href="https://http://www.caracasdigital.com/category/corporativo/telecomunicaciones/" class="td-post-category">Telecomunicaciones</a>                    <span class="td-author-date">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-08-06T09:12:40+00:00">6 agosto, 2020</time></span>                    </span>
                </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/04/15/para-2022-habra-mas-trafico-ip-que-en-toda-la-historia-de-internet-3/" rel="bookmark" class="td-image-wrap" title="Para 2022 habrá más tráfico IP que en toda la historia de Internet"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Vertiv.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Vertiv.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Vertiv.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Vertiv.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/04/Vertiv.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Para 2022 habrá más tráfico IP que en toda la historia de Internet"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/04/15/para-2022-habra-mas-trafico-ip-que-en-toda-la-historia-de-internet-3/" rel="bookmark" title="Para 2022 habrá más tráfico IP que en toda la historia de Internet">Para 2022 habrá más tráfico IP que en toda la historia de Internet</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-04-15T18:09:03+00:00">15 abril, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2019/12/11/cisco-anuncia-la-estrategia-internet-para-el-futuro/" rel="bookmark" class="td-image-wrap" title="Cisco anuncia la estrategia “Internet para el futuro”"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/12/Cisco.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/12/Cisco.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/12/Cisco.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/12/Cisco.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/12/Cisco.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Cisco anuncia la estrategia “Internet para el futuro”"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2019/12/11/cisco-anuncia-la-estrategia-internet-para-el-futuro/" rel="bookmark" title="Cisco anuncia la estrategia “Internet para el futuro”">Cisco anuncia la estrategia “Internet para el futuro”</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2019-12-11T23:39:13+00:00">11 diciembre, 2019</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2019/11/28/peru-primer-pais-en-latinoamerica-en-brindar-internet-a-traves-de-globos-aereos/" rel="bookmark" class="td-image-wrap" title="Perú, primer país en Latinoamérica en brindar Internet a través de globos aéreos"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/11/Loon.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/11/Loon.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/11/Loon.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/11/Loon.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/11/Loon.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Perú, primer país en Latinoamérica en brindar Internet a través de globos aéreos"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2019/11/28/peru-primer-pais-en-latinoamerica-en-brindar-internet-a-traves-de-globos-aereos/" rel="bookmark" title="Perú, primer país en Latinoamérica en brindar Internet a través de globos aéreos">Perú, primer país en Latinoamérica en brindar Internet a través de globos aéreos</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2019-11-28T09:47:22+00:00">28 noviembre, 2019</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2019/01/11/para-2022-habra-mas-trafico-ip-que-en-toda-la-historia-de-internet-2/" rel="bookmark" class="td-image-wrap" title="Para 2022 habrá más tráfico IP que en toda la historia de Internet"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/01/Jonathan_Davidson_Cisco.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/01/Jonathan_Davidson_Cisco.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/01/Jonathan_Davidson_Cisco.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/01/Jonathan_Davidson_Cisco.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2019/01/Jonathan_Davidson_Cisco.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Para 2022 habrá más tráfico IP que en toda la historia de Internet"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2019/01/11/para-2022-habra-mas-trafico-ip-que-en-toda-la-historia-de-internet-2/" rel="bookmark" title="Para 2022 habrá más tráfico IP que en toda la historia de Internet">Para 2022 habrá más tráfico IP que en toda la historia de Internet</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2019-01-11T16:54:19+00:00">11 enero, 2019</time></span>                                    </div>
            </div>

        </div>

        </div></div> <!-- ./block --></div></div><div class="vc_column td_uid_115_5f8f778c66b2e_rand  wpb_column vc_column_container tdc-column td-pb-span4"><div class="wpb_wrapper"><div class="td_block_wrap td_block_19 td_uid_116_5f8f778c66d0a_rand td-pb-border-top td_block_template_10 td-column-1" data-td-block-uid="td_uid_116_5f8f778c66d0a"><script>var block_td_uid_116_5f8f778c66d0a = new tdBlock();
block_td_uid_116_5f8f778c66d0a.id = "td_uid_116_5f8f778c66d0a";
block_td_uid_116_5f8f778c66d0a.atts = '{"custom_title":"IOT","custom_url":"https:\/\/www.itwarelatam.com\/category\/tipo-de-nota\/iot\/","block_template_id":"td_block_template_10","category_id":"234","separator":"","mx1_tl":"","mx2_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","limit":"5","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx1f_title_font_header":"","mx1f_title_font_title":"Article title","mx1f_title_font_settings":"","mx1f_title_font_family":"","mx1f_title_font_size":"","mx1f_title_font_line_height":"","mx1f_title_font_style":"","mx1f_title_font_weight":"","mx1f_title_font_transform":"","mx1f_title_font_spacing":"","mx1f_title_":"","mx1f_cat_font_title":"Article category tag","mx1f_cat_font_settings":"","mx1f_cat_font_family":"","mx1f_cat_font_size":"","mx1f_cat_font_line_height":"","mx1f_cat_font_style":"","mx1f_cat_font_weight":"","mx1f_cat_font_transform":"","mx1f_cat_font_spacing":"","mx1f_cat_":"","mx1f_meta_font_title":"Article meta info","mx1f_meta_font_settings":"","mx1f_meta_font_family":"","mx1f_meta_font_size":"","mx1f_meta_font_line_height":"","mx1f_meta_font_style":"","mx1f_meta_font_weight":"","mx1f_meta_font_transform":"","mx1f_meta_font_spacing":"","mx1f_meta_":"","mx2f_title_font_header":"","mx2f_title_font_title":"Article title","mx2f_title_font_settings":"","mx2f_title_font_family":"","mx2f_title_font_size":"","mx2f_title_font_line_height":"","mx2f_title_font_style":"","mx2f_title_font_weight":"","mx2f_title_font_transform":"","mx2f_title_font_spacing":"","mx2f_title_":"","mx2f_cat_font_title":"Article category tag","mx2f_cat_font_settings":"","mx2f_cat_font_family":"","mx2f_cat_font_size":"","mx2f_cat_font_line_height":"","mx2f_cat_font_style":"","mx2f_cat_font_weight":"","mx2f_cat_font_transform":"","mx2f_cat_font_spacing":"","mx2f_cat_":"","mx2f_meta_font_title":"Article meta info","mx2f_meta_font_settings":"","mx2f_meta_font_family":"","mx2f_meta_font_size":"","mx2f_meta_font_line_height":"","mx2f_meta_font_style":"","mx2f_meta_font_weight":"","mx2f_meta_font_transform":"","mx2f_meta_font_spacing":"","mx2f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":1,"header_color":"","color_preset":"","border_top":"","class":"td_uid_116_5f8f778c66d0a_rand","tdc_css_class":"td_uid_116_5f8f778c66d0a_rand","tdc_css_class_style":"td_uid_116_5f8f778c66d0a_rand_style"}';
block_td_uid_116_5f8f778c66d0a.td_column_number = "1";
block_td_uid_116_5f8f778c66d0a.block_type = "td_block_19";
block_td_uid_116_5f8f778c66d0a.post_count = "5";
block_td_uid_116_5f8f778c66d0a.found_posts = "139";
block_td_uid_116_5f8f778c66d0a.header_color = "";
block_td_uid_116_5f8f778c66d0a.ajax_pagination_infinite_stop = "";
block_td_uid_116_5f8f778c66d0a.max_num_pages = "28";
tdBlocksArray.push(block_td_uid_116_5f8f778c66d0a);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/category/tipo-de-nota/iot/" class="td-pulldown-size">IOT</a></h4></div><div id="td_uid_116_5f8f778c66d0a" class="td_block_inner td-column-1">
        <div class="td_module_mx1 td_module_wrap td-animation-stack">
            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/hp-lanza-tecnologias-de-impresion-patient%e2%80%90firs/" rel="bookmark" class="td-image-wrap" title="HP lanza tecnologías de impresión Patient-First"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-healthcare.jpg?resize=356%2C220&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-healthcare.jpg?resize=356%2C220&amp;ssl=1 356w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-healthcare.jpg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="HP lanza tecnologías de impresión Patient-First"></a></div>
            <div class="td-module-meta-info">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/hp-lanza-tecnologias-de-impresion-patient%e2%80%90firs/" rel="bookmark" title="HP lanza tecnologías de impresión Patient-First">HP lanza tecnologías de impresión Patient-First</a></h3>                <div class="td-editor-date">
                    <a href="https://http://www.caracasdigital.com/category/productos/hardware/" class="td-post-category">Hardware</a>                    <span class="td-author-date">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-15T13:09:58+00:00">15 octubre, 2020</time></span>                    </span>
                </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/01/intel-anuncia-procesadores-mejorados-con-iot/" rel="bookmark" class="td-image-wrap" title="Intel anuncia procesadores mejorados con IoT"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Intel-11th-Gen-Intel-Core-Iot-1.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Intel anuncia procesadores mejorados con IoT"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/01/intel-anuncia-procesadores-mejorados-con-iot/" rel="bookmark" title="Intel anuncia procesadores mejorados con IoT">Intel anuncia procesadores mejorados con IoT</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-01T10:15:21+00:00">1 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/01/ia-iot-y-blockchain-para-el-desarrollo-de-los-negocios-en-la-era-post-covid19/" rel="bookmark" class="td-image-wrap" title="IA, IoT y Blockchain para el desarrollo de los negocios en la era post-COVID19"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="IA, IoT y Blockchain para el desarrollo de los negocios en la era post-COVID19"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/01/ia-iot-y-blockchain-para-el-desarrollo-de-los-negocios-en-la-era-post-covid19/" rel="bookmark" title="IA, IoT y Blockchain para el desarrollo de los negocios en la era post-COVID19">IA, IoT y Blockchain para el desarrollo de los negocios en la era post-COVID19</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-01T10:00:15+00:00">1 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/07/11/ibm-busca-a-los-mejores-desarrolladores-de-america-latina/" rel="bookmark" class="td-image-wrap" title="IBM busca a los mejores desarrolladores de América Latina"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/maratonbehindthecodeibm.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/maratonbehindthecodeibm.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/maratonbehindthecodeibm.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/maratonbehindthecodeibm.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/maratonbehindthecodeibm.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="IBM busca a los mejores desarrolladores de América Latina"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/07/11/ibm-busca-a-los-mejores-desarrolladores-de-america-latina/" rel="bookmark" title="IBM busca a los mejores desarrolladores de América Latina">IBM busca a los mejores desarrolladores de América Latina</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-11T11:04:16+00:00">11 julio, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/06/25/tendencias-tecnologicas-para-el-mundo-post-pandemia/" rel="bookmark" class="td-image-wrap" title="Tendencias tecnológicas para el mundo post pandemia"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/RedHat_Edge.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/RedHat_Edge.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/RedHat_Edge.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/RedHat_Edge.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/RedHat_Edge.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Tendencias tecnológicas para el mundo post pandemia"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/06/25/tendencias-tecnologicas-para-el-mundo-post-pandemia/" rel="bookmark" title="Tendencias tecnológicas para el mundo post pandemia">Tendencias tecnológicas para el mundo post pandemia</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-06-25T12:39:54+00:00">25 junio, 2020</time></span>                                    </div>
            </div>

        </div>

        </div></div> <!-- ./block --></div></div><div class="vc_column td_uid_117_5f8f778c6dbee_rand  wpb_column vc_column_container tdc-column td-pb-span4"><div class="wpb_wrapper"><div class="td_block_wrap td_block_19 td_uid_118_5f8f778c6dd06_rand td-pb-border-top td_block_template_10 td-column-1" data-td-block-uid="td_uid_118_5f8f778c6dd06"><script>var block_td_uid_118_5f8f778c6dd06 = new tdBlock();
block_td_uid_118_5f8f778c6dd06.id = "td_uid_118_5f8f778c6dd06";
block_td_uid_118_5f8f778c6dd06.atts = '{"custom_title":"OPINI\u00d3N","custom_url":"https:\/\/www.itwarelatam.com\/category\/tipo-de-nota\/opinion\/","block_template_id":"td_block_template_10","category_id":"974","separator":"","mx1_tl":"","mx2_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","limit":"5","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx1f_title_font_header":"","mx1f_title_font_title":"Article title","mx1f_title_font_settings":"","mx1f_title_font_family":"","mx1f_title_font_size":"","mx1f_title_font_line_height":"","mx1f_title_font_style":"","mx1f_title_font_weight":"","mx1f_title_font_transform":"","mx1f_title_font_spacing":"","mx1f_title_":"","mx1f_cat_font_title":"Article category tag","mx1f_cat_font_settings":"","mx1f_cat_font_family":"","mx1f_cat_font_size":"","mx1f_cat_font_line_height":"","mx1f_cat_font_style":"","mx1f_cat_font_weight":"","mx1f_cat_font_transform":"","mx1f_cat_font_spacing":"","mx1f_cat_":"","mx1f_meta_font_title":"Article meta info","mx1f_meta_font_settings":"","mx1f_meta_font_family":"","mx1f_meta_font_size":"","mx1f_meta_font_line_height":"","mx1f_meta_font_style":"","mx1f_meta_font_weight":"","mx1f_meta_font_transform":"","mx1f_meta_font_spacing":"","mx1f_meta_":"","mx2f_title_font_header":"","mx2f_title_font_title":"Article title","mx2f_title_font_settings":"","mx2f_title_font_family":"","mx2f_title_font_size":"","mx2f_title_font_line_height":"","mx2f_title_font_style":"","mx2f_title_font_weight":"","mx2f_title_font_transform":"","mx2f_title_font_spacing":"","mx2f_title_":"","mx2f_cat_font_title":"Article category tag","mx2f_cat_font_settings":"","mx2f_cat_font_family":"","mx2f_cat_font_size":"","mx2f_cat_font_line_height":"","mx2f_cat_font_style":"","mx2f_cat_font_weight":"","mx2f_cat_font_transform":"","mx2f_cat_font_spacing":"","mx2f_cat_":"","mx2f_meta_font_title":"Article meta info","mx2f_meta_font_settings":"","mx2f_meta_font_family":"","mx2f_meta_font_size":"","mx2f_meta_font_line_height":"","mx2f_meta_font_style":"","mx2f_meta_font_weight":"","mx2f_meta_font_transform":"","mx2f_meta_font_spacing":"","mx2f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":1,"header_color":"","color_preset":"","border_top":"","class":"td_uid_118_5f8f778c6dd06_rand","tdc_css_class":"td_uid_118_5f8f778c6dd06_rand","tdc_css_class_style":"td_uid_118_5f8f778c6dd06_rand_style"}';
block_td_uid_118_5f8f778c6dd06.td_column_number = "1";
block_td_uid_118_5f8f778c6dd06.block_type = "td_block_19";
block_td_uid_118_5f8f778c6dd06.post_count = "5";
block_td_uid_118_5f8f778c6dd06.found_posts = "394";
block_td_uid_118_5f8f778c6dd06.header_color = "";
block_td_uid_118_5f8f778c6dd06.ajax_pagination_infinite_stop = "";
block_td_uid_118_5f8f778c6dd06.max_num_pages = "79";
tdBlocksArray.push(block_td_uid_118_5f8f778c6dd06);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/category/tipo-de-nota/opinion/" class="td-pulldown-size">OPINIÓN</a></h4></div><div id="td_uid_118_5f8f778c6dd06" class="td_block_inner td-column-1">
        <div class="td_module_mx1 td_module_wrap td-animation-stack">
            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/19/store-in-the-cloud-un-mercado-de-ti-para-que-los-minoristas-emerjan-mas-fuertes/" rel="bookmark" class="td-image-wrap" title="Store in the Cloud: un mercado de TI para que los minoristas emerjan más fuertes"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/ibm-store-in-cloud.jpg?resize=356%2C220&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/ibm-store-in-cloud.jpg?resize=356%2C220&amp;ssl=1 356w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/ibm-store-in-cloud.jpg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="Store in the Cloud: un mercado de TI para que los minoristas emerjan más fuertes"></a></div>
            <div class="td-module-meta-info">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/19/store-in-the-cloud-un-mercado-de-ti-para-que-los-minoristas-emerjan-mas-fuertes/" rel="bookmark" title="Store in the Cloud: un mercado de TI para que los minoristas emerjan más fuertes">Store in the Cloud: un mercado de TI para que los minoristas emerjan más fuertes</a></h3>                <div class="td-editor-date">
                    <a href="https://http://www.caracasdigital.com/category/tipo-de-nota/opinion/" class="td-post-category">Opinion</a>                    <span class="td-author-date">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-19T17:42:52+00:00">19 octubre, 2020</time></span>                    </span>
                </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/15/la-promesa-de-la-microfluidica-y-las-pruebas-rapidas/" rel="bookmark" class="td-image-wrap" title="La promesa de la microfluídica y las pruebas rápidas"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/andrew_bolwell_hp.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/andrew_bolwell_hp.jpg?resize=80%2C60&amp;ssl=1 80w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/andrew_bolwell_hp.jpg?resize=265%2C198&amp;ssl=1 265w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/andrew_bolwell_hp.jpg?resize=485%2C360&amp;ssl=1 485w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/andrew_bolwell_hp.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="La promesa de la microfluídica y las pruebas rápidas"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/15/la-promesa-de-la-microfluidica-y-las-pruebas-rapidas/" rel="bookmark" title="La promesa de la microfluídica y las pruebas rápidas">La promesa de la microfluídica y las pruebas rápidas</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-15T16:37:22+00:00">15 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/13/ciberseguridad-y-democracia-como-respaldar-la-seguridad-electoral-con-el-apoyo-de-la-tecnologia/" rel="bookmark" class="td-image-wrap" title="Ciberseguridad y democracia: cómo respaldar la seguridad electoral con el apoyo de la tecnología"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Marc-Asturias-vicepresidente-de-Mercadeo-Comunicaciones-RRPP-y-Asuntos-Gubernamentales-de-Fortinet.png?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Marc-Asturias-vicepresidente-de-Mercadeo-Comunicaciones-RRPP-y-Asuntos-Gubernamentales-de-Fortinet.png?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Marc-Asturias-vicepresidente-de-Mercadeo-Comunicaciones-RRPP-y-Asuntos-Gubernamentales-de-Fortinet.png?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Marc-Asturias-vicepresidente-de-Mercadeo-Comunicaciones-RRPP-y-Asuntos-Gubernamentales-de-Fortinet.png?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Marc-Asturias-vicepresidente-de-Mercadeo-Comunicaciones-RRPP-y-Asuntos-Gubernamentales-de-Fortinet.png?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Ciberseguridad y democracia: cómo respaldar la seguridad electoral con el apoyo de la tecnología"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/13/ciberseguridad-y-democracia-como-respaldar-la-seguridad-electoral-con-el-apoyo-de-la-tecnologia/" rel="bookmark" title="Ciberseguridad y democracia: cómo respaldar la seguridad electoral con el apoyo de la tecnología">Ciberseguridad y democracia: cómo respaldar la seguridad electoral con el apoyo de la tecnología</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-13T15:35:00+00:00">13 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/13/el-capitulo-argentino-de-la-wca-firmo-un-convenio-de-colaboracion-con-el-ministerio-de-obras-publicas/" rel="bookmark" class="td-image-wrap" title="El Capítulo Argentino de la WCA firmó un Convenio de Colaboración con el Ministerio de Obras Públicas"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Compliance_WCA.JPG.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Compliance_WCA.JPG.jpg?resize=80%2C60&amp;ssl=1 80w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Compliance_WCA.JPG.jpg?resize=265%2C198&amp;ssl=1 265w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Compliance_WCA.JPG.jpg?resize=485%2C360&amp;ssl=1 485w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Compliance_WCA.JPG.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="El Capítulo Argentino de la WCA firmó un Convenio de Colaboración con el Ministerio de Obras Públicas"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/13/el-capitulo-argentino-de-la-wca-firmo-un-convenio-de-colaboracion-con-el-ministerio-de-obras-publicas/" rel="bookmark" title="El Capítulo Argentino de la WCA firmó un Convenio de Colaboración con el Ministerio de Obras Públicas">El Capítulo Argentino de la WCA firmó un Convenio de Colaboración con el Ministerio de Obras Públicas</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-13T10:51:55+00:00">13 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/07/estados-unidos-condena-de-monopolio-a-grandes-empresas-de-la-tecnologia/" rel="bookmark" class="td-image-wrap" title="Estados Unidos condena de monopolio a grandes empresas de la tecnología"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/WCA-EEUU.JPG.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/WCA-EEUU.JPG.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/WCA-EEUU.JPG.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/WCA-EEUU.JPG.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/WCA-EEUU.JPG.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Estados Unidos condena de monopolio a grandes empresas de la tecnología"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/07/estados-unidos-condena-de-monopolio-a-grandes-empresas-de-la-tecnologia/" rel="bookmark" title="Estados Unidos condena de monopolio a grandes empresas de la tecnología">Estados Unidos condena de monopolio a grandes empresas de la tecnología</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-07T09:36:40+00:00">7 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        </div></div> <!-- ./block --></div></div></div></div>
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_23_5f8f778c5f06d .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_23_5f8f778c5f06d .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

			<div id="td_uid_27_5f8f778c757cc" class="tdc-row"><div class="vc_row td_uid_119_5f8f778c757d6_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_119_5f8f778c757d6_rand {
                    min-height: 0;
                }
</style><div class="vc_column td_uid_120_5f8f778c759d9_rand  wpb_column vc_column_container tdc-column td-pb-span8"><div class="wpb_wrapper"><div class="wpb_wrapper td_block_single_image td_block_wrap  td_block_wrap vc_single_image td_uid_121_5f8f778c75b0c_rand  td-single-image- td-pb-border-top td_block_template_3"><a class="td_single_image_bg" style="background-image: url('https://www.itwarelatam.com/wp-content/uploads/2017/06/banner-redes.gif'); background-size: cover; background-repeat: no-repeat; background-position: center center;" href="https://www.facebook.com/ITwareLatam/" target="_blank" rel="bookmark"></a>
<style>
/* custom css */
.td_uid_121_5f8f778c75b0c_rand .td_single_image_bg {
					height: 170px;
					padding-bottom: 0;
				}
</style></div></div></div><div class="vc_column td_uid_122_5f8f778c7cad0_rand  wpb_column vc_column_container tdc-column td-pb-span4"><div class="wpb_wrapper"><div class="wpb_wrapper td_block_wrap vc_raw_html td_uid_123_5f8f778c7cc02_rand "><div class="td-fix-index"><iframe width="100%" height="315" src="https://www.youtube.com/embed/WLRrNSDsgk4" frameborder="0" allowfullscreen="" style="height: 180px;"></iframe></div></div></div></div></div></div>
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_27_5f8f778c757cc .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_27_5f8f778c757cc .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

			<div id="td_uid_31_5f8f778c7cc6e" class="tdc-row"><div class="vc_row td_uid_124_5f8f778c7cc72_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_124_5f8f778c7cc72_rand {
                    min-height: 0;
                }
</style><div class="vc_column td_uid_125_5f8f778c7cdde_rand  wpb_column vc_column_container tdc-column td-pb-span4"><div class="wpb_wrapper"><div class="td_block_wrap td_block_19 td_uid_126_5f8f778c7ceda_rand td-pb-border-top td_block_template_10 td-column-1" data-td-block-uid="td_uid_126_5f8f778c7ceda"><script>var block_td_uid_126_5f8f778c7ceda = new tdBlock();
block_td_uid_126_5f8f778c7ceda.id = "td_uid_126_5f8f778c7ceda";
block_td_uid_126_5f8f778c7ceda.atts = '{"custom_title":"TENDENCIAS","custom_url":"https:\/\/www.itwarelatam.com\/category\/tipo-de-nota\/tendencias\/","block_template_id":"td_block_template_10","category_id":"196","separator":"","mx1_tl":"","mx2_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","limit":"5","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx1f_title_font_header":"","mx1f_title_font_title":"Article title","mx1f_title_font_settings":"","mx1f_title_font_family":"","mx1f_title_font_size":"","mx1f_title_font_line_height":"","mx1f_title_font_style":"","mx1f_title_font_weight":"","mx1f_title_font_transform":"","mx1f_title_font_spacing":"","mx1f_title_":"","mx1f_cat_font_title":"Article category tag","mx1f_cat_font_settings":"","mx1f_cat_font_family":"","mx1f_cat_font_size":"","mx1f_cat_font_line_height":"","mx1f_cat_font_style":"","mx1f_cat_font_weight":"","mx1f_cat_font_transform":"","mx1f_cat_font_spacing":"","mx1f_cat_":"","mx1f_meta_font_title":"Article meta info","mx1f_meta_font_settings":"","mx1f_meta_font_family":"","mx1f_meta_font_size":"","mx1f_meta_font_line_height":"","mx1f_meta_font_style":"","mx1f_meta_font_weight":"","mx1f_meta_font_transform":"","mx1f_meta_font_spacing":"","mx1f_meta_":"","mx2f_title_font_header":"","mx2f_title_font_title":"Article title","mx2f_title_font_settings":"","mx2f_title_font_family":"","mx2f_title_font_size":"","mx2f_title_font_line_height":"","mx2f_title_font_style":"","mx2f_title_font_weight":"","mx2f_title_font_transform":"","mx2f_title_font_spacing":"","mx2f_title_":"","mx2f_cat_font_title":"Article category tag","mx2f_cat_font_settings":"","mx2f_cat_font_family":"","mx2f_cat_font_size":"","mx2f_cat_font_line_height":"","mx2f_cat_font_style":"","mx2f_cat_font_weight":"","mx2f_cat_font_transform":"","mx2f_cat_font_spacing":"","mx2f_cat_":"","mx2f_meta_font_title":"Article meta info","mx2f_meta_font_settings":"","mx2f_meta_font_family":"","mx2f_meta_font_size":"","mx2f_meta_font_line_height":"","mx2f_meta_font_style":"","mx2f_meta_font_weight":"","mx2f_meta_font_transform":"","mx2f_meta_font_spacing":"","mx2f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":1,"header_color":"","color_preset":"","border_top":"","class":"td_uid_126_5f8f778c7ceda_rand","tdc_css_class":"td_uid_126_5f8f778c7ceda_rand","tdc_css_class_style":"td_uid_126_5f8f778c7ceda_rand_style"}';
block_td_uid_126_5f8f778c7ceda.td_column_number = "1";
block_td_uid_126_5f8f778c7ceda.block_type = "td_block_19";
block_td_uid_126_5f8f778c7ceda.post_count = "5";
block_td_uid_126_5f8f778c7ceda.found_posts = "183";
block_td_uid_126_5f8f778c7ceda.header_color = "";
block_td_uid_126_5f8f778c7ceda.ajax_pagination_infinite_stop = "";
block_td_uid_126_5f8f778c7ceda.max_num_pages = "37";
tdBlocksArray.push(block_td_uid_126_5f8f778c7ceda);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/category/tipo-de-nota/tendencias/" class="td-pulldown-size">TENDENCIAS</a></h4></div><div id="td_uid_126_5f8f778c7ceda" class="td_block_inner td-column-1">
        <div class="td_module_mx1 td_module_wrap td-animation-stack">
            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/16/estudio-de-hp-revela-el-auge-del-empleado-empoderado/" rel="bookmark" class="td-image-wrap" title="Estudio de HP revela el auge del “empleado empoderado”"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-2020-Workforce-Evolution.jpg?resize=356%2C220&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-2020-Workforce-Evolution.jpg?resize=356%2C220&amp;ssl=1 356w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/HP-2020-Workforce-Evolution.jpg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="Estudio de HP revela el auge del “empleado empoderado”"></a></div>
            <div class="td-module-meta-info">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/16/estudio-de-hp-revela-el-auge-del-empleado-empoderado/" rel="bookmark" title="Estudio de HP revela el auge del “empleado empoderado”">Estudio de HP revela el auge del “empleado empoderado”</a></h3>                <div class="td-editor-date">
                    <a href="https://http://www.caracasdigital.com/category/tipo-de-nota/tendencias/" class="td-post-category">Tendencias</a>                    <span class="td-author-date">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-16T17:23:16+00:00">16 octubre, 2020</time></span>                    </span>
                </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/01/ia-iot-y-blockchain-para-el-desarrollo-de-los-negocios-en-la-era-post-covid19/" rel="bookmark" class="td-image-wrap" title="IA, IoT y Blockchain para el desarrollo de los negocios en la era post-COVID19"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/oracle.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="IA, IoT y Blockchain para el desarrollo de los negocios en la era post-COVID19"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/01/ia-iot-y-blockchain-para-el-desarrollo-de-los-negocios-en-la-era-post-covid19/" rel="bookmark" title="IA, IoT y Blockchain para el desarrollo de los negocios en la era post-COVID19">IA, IoT y Blockchain para el desarrollo de los negocios en la era post-COVID19</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-01T10:00:15+00:00">1 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/22/en-latinoamerica-las-aplicaciones-son-el-motor-de-la-economia-digital/" rel="bookmark" class="td-image-wrap" title="En Latinoamérica, las aplicaciones son el motor de la economía digital"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/F5.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="En Latinoamérica, las aplicaciones son el motor de la economía digital"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/22/en-latinoamerica-las-aplicaciones-son-el-motor-de-la-economia-digital/" rel="bookmark" title="En Latinoamérica, las aplicaciones son el motor de la economía digital">En Latinoamérica, las aplicaciones son el motor de la economía digital</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-22T09:27:41+00:00">22 septiembre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/07/07/los-dispositivos-tecnologicos-con-mayor-intencion-de-compra-en-latinoamerica/" rel="bookmark" class="td-image-wrap" title="Los dispositivos tecnológicos con mayor intención de compra en Latinoamérica"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Screenshot_10.png?resize=80%2C60&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Screenshot_10.png?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Screenshot_10.png?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Screenshot_10.png?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/Screenshot_10.png?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Los dispositivos tecnológicos con mayor intención de compra en Latinoamérica"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/07/07/los-dispositivos-tecnologicos-con-mayor-intencion-de-compra-en-latinoamerica/" rel="bookmark" title="Los dispositivos tecnológicos con mayor intención de compra en Latinoamérica">Los dispositivos tecnológicos con mayor intención de compra en Latinoamérica</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-07T11:25:05+00:00">7 julio, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/07/02/investigacion-de-vmware-como-las-empresas-estan-operando-y-priorizando-durante-la-pandemia/" rel="bookmark" class="td-image-wrap" title="Investigación de VMware: cómo las empresas están operando y priorizando durante la pandemia"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/VMware.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/VMware.jpg?resize=80%2C60&amp;ssl=1 80w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/VMware.jpg?resize=265%2C198&amp;ssl=1 265w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/VMware.jpg?resize=485%2C360&amp;ssl=1 485w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/07/VMware.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Investigación de VMware: cómo las empresas están operando y priorizando durante la pandemia"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/07/02/investigacion-de-vmware-como-las-empresas-estan-operando-y-priorizando-durante-la-pandemia/" rel="bookmark" title="Investigación de VMware: cómo las empresas están operando y priorizando durante la pandemia">Investigación de VMware: cómo las empresas están operando y priorizando durante la pandemia</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-07-02T11:04:26+00:00">2 julio, 2020</time></span>                                    </div>
            </div>

        </div>

        </div></div> <!-- ./block --></div></div><div class="vc_column td_uid_127_5f8f778c83f8a_rand  wpb_column vc_column_container tdc-column td-pb-span4"><div class="wpb_wrapper"><div class="td_block_wrap td_block_19 td_uid_128_5f8f778c840a8_rand td-pb-border-top td_block_template_10 td-column-1" data-td-block-uid="td_uid_128_5f8f778c840a8"><script>var block_td_uid_128_5f8f778c840a8 = new tdBlock();
block_td_uid_128_5f8f778c840a8.id = "td_uid_128_5f8f778c840a8";
block_td_uid_128_5f8f778c840a8.atts = '{"custom_title":"EVENTOS","custom_url":"https:\/\/www.itwarelatam.com\/category\/tipo-de-nota\/eventos\/","block_template_id":"td_block_template_10","category_id":"195","separator":"","mx1_tl":"","mx2_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","limit":"5","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx1f_title_font_header":"","mx1f_title_font_title":"Article title","mx1f_title_font_settings":"","mx1f_title_font_family":"","mx1f_title_font_size":"","mx1f_title_font_line_height":"","mx1f_title_font_style":"","mx1f_title_font_weight":"","mx1f_title_font_transform":"","mx1f_title_font_spacing":"","mx1f_title_":"","mx1f_cat_font_title":"Article category tag","mx1f_cat_font_settings":"","mx1f_cat_font_family":"","mx1f_cat_font_size":"","mx1f_cat_font_line_height":"","mx1f_cat_font_style":"","mx1f_cat_font_weight":"","mx1f_cat_font_transform":"","mx1f_cat_font_spacing":"","mx1f_cat_":"","mx1f_meta_font_title":"Article meta info","mx1f_meta_font_settings":"","mx1f_meta_font_family":"","mx1f_meta_font_size":"","mx1f_meta_font_line_height":"","mx1f_meta_font_style":"","mx1f_meta_font_weight":"","mx1f_meta_font_transform":"","mx1f_meta_font_spacing":"","mx1f_meta_":"","mx2f_title_font_header":"","mx2f_title_font_title":"Article title","mx2f_title_font_settings":"","mx2f_title_font_family":"","mx2f_title_font_size":"","mx2f_title_font_line_height":"","mx2f_title_font_style":"","mx2f_title_font_weight":"","mx2f_title_font_transform":"","mx2f_title_font_spacing":"","mx2f_title_":"","mx2f_cat_font_title":"Article category tag","mx2f_cat_font_settings":"","mx2f_cat_font_family":"","mx2f_cat_font_size":"","mx2f_cat_font_line_height":"","mx2f_cat_font_style":"","mx2f_cat_font_weight":"","mx2f_cat_font_transform":"","mx2f_cat_font_spacing":"","mx2f_cat_":"","mx2f_meta_font_title":"Article meta info","mx2f_meta_font_settings":"","mx2f_meta_font_family":"","mx2f_meta_font_size":"","mx2f_meta_font_line_height":"","mx2f_meta_font_style":"","mx2f_meta_font_weight":"","mx2f_meta_font_transform":"","mx2f_meta_font_spacing":"","mx2f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":1,"header_color":"","color_preset":"","border_top":"","class":"td_uid_128_5f8f778c840a8_rand","tdc_css_class":"td_uid_128_5f8f778c840a8_rand","tdc_css_class_style":"td_uid_128_5f8f778c840a8_rand_style"}';
block_td_uid_128_5f8f778c840a8.td_column_number = "1";
block_td_uid_128_5f8f778c840a8.block_type = "td_block_19";
block_td_uid_128_5f8f778c840a8.post_count = "5";
block_td_uid_128_5f8f778c840a8.found_posts = "701";
block_td_uid_128_5f8f778c840a8.header_color = "";
block_td_uid_128_5f8f778c840a8.ajax_pagination_infinite_stop = "";
block_td_uid_128_5f8f778c840a8.max_num_pages = "141";
tdBlocksArray.push(block_td_uid_128_5f8f778c840a8);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/category/tipo-de-nota/eventos/" class="td-pulldown-size">EVENTOS</a></h4></div><div id="td_uid_128_5f8f778c840a8" class="td_block_inner td-column-1">
        <div class="td_module_mx1 td_module_wrap td-animation-stack">
            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/16/llega-el-eretail-week-america-central-y-el-caribe-online-live-experience/" rel="bookmark" class="td-image-wrap" title="Llega el eRetail Week América Central y el Caribe Online [Live] experience"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/IMG_16102020_155816_1000_x_600_pixel.jpg?resize=356%2C220&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/IMG_16102020_155816_1000_x_600_pixel.jpg?resize=356%2C220&amp;ssl=1 356w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/IMG_16102020_155816_1000_x_600_pixel.jpg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="Llega el eRetail Week América Central y el Caribe Online [Live] experience"></a></div>
            <div class="td-module-meta-info">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/16/llega-el-eretail-week-america-central-y-el-caribe-online-live-experience/" rel="bookmark" title="Llega el eRetail Week América Central y el Caribe Online [Live] experience">Llega el eRetail Week América Central y el Caribe Online [Live] experience</a></h3>                <div class="td-editor-date">
                    <a href="https://http://www.caracasdigital.com/category/empresas-2/comercio-electronico/" class="td-post-category">Comercio Electrónico</a>                    <span class="td-author-date">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-16T20:42:07+00:00">16 octubre, 2020</time></span>                    </span>
                </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/09/genexus-17-live-nuevas-tecnologias-para-un-nuevo-mundo/" rel="bookmark" class="td-image-wrap" title="GeneXus 17 Live: nuevas tecnologías para un nuevo mundo"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2017/10/Jodal.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="GeneXus 17 Live: nuevas tecnologías para un nuevo mundo"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/09/genexus-17-live-nuevas-tecnologias-para-un-nuevo-mundo/" rel="bookmark" title="GeneXus 17 Live: nuevas tecnologías para un nuevo mundo">GeneXus 17 Live: nuevas tecnologías para un nuevo mundo</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-09T09:38:43+00:00">9 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/06/nvidia-presento-la-solucion-dgx-superpod-para-empresas/" rel="bookmark" class="td-image-wrap" title="NVIDIA presentó la solución DGX SuperPOD para empresas"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?resize=80%2C60&amp;ssl=1 80w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?resize=265%2C198&amp;ssl=1 265w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?resize=485%2C360&amp;ssl=1 485w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2020/10/Jensen-Huang_Nvidia.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="NVIDIA presentó la solución DGX SuperPOD para empresas"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/06/nvidia-presento-la-solucion-dgx-superpod-para-empresas/" rel="bookmark" title="NVIDIA presentó la solución DGX SuperPOD para empresas">NVIDIA presentó la solución DGX SuperPOD para empresas</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-06T09:46:56+00:00">6 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/10/01/5g-es-esencial-para-el-futuro-del-trabajo-y-las-empresas-conectadas/" rel="bookmark" class="td-image-wrap" title="“5G es esencial para el futuro del trabajo y las empresas conectadas”"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Cristiano-Amon_Qualcomm.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Cristiano-Amon_Qualcomm.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Cristiano-Amon_Qualcomm.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Cristiano-Amon_Qualcomm.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Cristiano-Amon_Qualcomm.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="“5G es esencial para el futuro del trabajo y las empresas conectadas”"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/10/01/5g-es-esencial-para-el-futuro-del-trabajo-y-las-empresas-conectadas/" rel="bookmark" title="“5G es esencial para el futuro del trabajo y las empresas conectadas”">“5G es esencial para el futuro del trabajo y las empresas conectadas”</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-10-01T10:30:33+00:00">1 octubre, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/09/30/vmworld-vmware-anuncia-soluciones-para-la-fuerza-laboral-distribuida/" rel="bookmark" class="td-image-wrap" title="VMworld: VMware anuncia soluciones para la fuerza laboral distribuida"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Pat-Gelsinger-CEO-de-VMware.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Pat-Gelsinger-CEO-de-VMware.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Pat-Gelsinger-CEO-de-VMware.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Pat-Gelsinger-CEO-de-VMware.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/09/Pat-Gelsinger-CEO-de-VMware.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="VMworld: VMware anuncia soluciones para la fuerza laboral distribuida"></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/09/30/vmworld-vmware-anuncia-soluciones-para-la-fuerza-laboral-distribuida/" rel="bookmark" title="VMworld: VMware anuncia soluciones para la fuerza laboral distribuida">VMworld: VMware anuncia soluciones para la fuerza laboral distribuida</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-09-30T11:14:33+00:00">30 septiembre, 2020</time></span>                                    </div>
            </div>

        </div>

        </div></div> <!-- ./block --></div></div><div class="vc_column td_uid_129_5f8f778c8cd1c_rand  wpb_column vc_column_container tdc-column td-pb-span4"><div class="wpb_wrapper"><div class="td_block_wrap td_block_19 td_uid_130_5f8f778c8ce41_rand td-pb-border-top td_block_template_10 td-column-1" data-td-block-uid="td_uid_130_5f8f778c8ce41"><script>var block_td_uid_130_5f8f778c8ce41 = new tdBlock();
block_td_uid_130_5f8f778c8ce41.id = "td_uid_130_5f8f778c8ce41";
block_td_uid_130_5f8f778c8ce41.atts = '{"custom_title":"VIDEO ENTREVISTAS","custom_url":"https:\/\/www.itwarelatam.com\/category\/tipo-de-nota\/videoentrevistas\/","block_template_id":"td_block_template_10","category_id":"979","separator":"","mx1_tl":"","mx2_tl":"","post_ids":"","category_ids":"","tag_slug":"","autors_id":"","installed_post_types":"","sort":"","limit":"5","offset":"","el_class":"","td_ajax_filter_type":"","td_ajax_filter_ids":"","td_filter_default_txt":"All","td_ajax_preloading":"","f_header_font_header":"","f_header_font_title":"Block header","f_header_font_settings":"","f_header_font_family":"","f_header_font_size":"","f_header_font_line_height":"","f_header_font_style":"","f_header_font_weight":"","f_header_font_transform":"","f_header_font_spacing":"","f_header_":"","f_ajax_font_title":"Ajax categories","f_ajax_font_settings":"","f_ajax_font_family":"","f_ajax_font_size":"","f_ajax_font_line_height":"","f_ajax_font_style":"","f_ajax_font_weight":"","f_ajax_font_transform":"","f_ajax_font_spacing":"","f_ajax_":"","f_more_font_title":"Load more button","f_more_font_settings":"","f_more_font_family":"","f_more_font_size":"","f_more_font_line_height":"","f_more_font_style":"","f_more_font_weight":"","f_more_font_transform":"","f_more_font_spacing":"","f_more_":"","mx1f_title_font_header":"","mx1f_title_font_title":"Article title","mx1f_title_font_settings":"","mx1f_title_font_family":"","mx1f_title_font_size":"","mx1f_title_font_line_height":"","mx1f_title_font_style":"","mx1f_title_font_weight":"","mx1f_title_font_transform":"","mx1f_title_font_spacing":"","mx1f_title_":"","mx1f_cat_font_title":"Article category tag","mx1f_cat_font_settings":"","mx1f_cat_font_family":"","mx1f_cat_font_size":"","mx1f_cat_font_line_height":"","mx1f_cat_font_style":"","mx1f_cat_font_weight":"","mx1f_cat_font_transform":"","mx1f_cat_font_spacing":"","mx1f_cat_":"","mx1f_meta_font_title":"Article meta info","mx1f_meta_font_settings":"","mx1f_meta_font_family":"","mx1f_meta_font_size":"","mx1f_meta_font_line_height":"","mx1f_meta_font_style":"","mx1f_meta_font_weight":"","mx1f_meta_font_transform":"","mx1f_meta_font_spacing":"","mx1f_meta_":"","mx2f_title_font_header":"","mx2f_title_font_title":"Article title","mx2f_title_font_settings":"","mx2f_title_font_family":"","mx2f_title_font_size":"","mx2f_title_font_line_height":"","mx2f_title_font_style":"","mx2f_title_font_weight":"","mx2f_title_font_transform":"","mx2f_title_font_spacing":"","mx2f_title_":"","mx2f_cat_font_title":"Article category tag","mx2f_cat_font_settings":"","mx2f_cat_font_family":"","mx2f_cat_font_size":"","mx2f_cat_font_line_height":"","mx2f_cat_font_style":"","mx2f_cat_font_weight":"","mx2f_cat_font_transform":"","mx2f_cat_font_spacing":"","mx2f_cat_":"","mx2f_meta_font_title":"Article meta info","mx2f_meta_font_settings":"","mx2f_meta_font_family":"","mx2f_meta_font_size":"","mx2f_meta_font_line_height":"","mx2f_meta_font_style":"","mx2f_meta_font_weight":"","mx2f_meta_font_transform":"","mx2f_meta_font_spacing":"","mx2f_meta_":"","ajax_pagination":"","ajax_pagination_infinite_stop":"","css":"","tdc_css":"","td_column_number":1,"header_color":"","color_preset":"","border_top":"","class":"td_uid_130_5f8f778c8ce41_rand","tdc_css_class":"td_uid_130_5f8f778c8ce41_rand","tdc_css_class_style":"td_uid_130_5f8f778c8ce41_rand_style"}';
block_td_uid_130_5f8f778c8ce41.td_column_number = "1";
block_td_uid_130_5f8f778c8ce41.block_type = "td_block_19";
block_td_uid_130_5f8f778c8ce41.post_count = "5";
block_td_uid_130_5f8f778c8ce41.found_posts = "112";
block_td_uid_130_5f8f778c8ce41.header_color = "";
block_td_uid_130_5f8f778c8ce41.ajax_pagination_infinite_stop = "";
block_td_uid_130_5f8f778c8ce41.max_num_pages = "23";
tdBlocksArray.push(block_td_uid_130_5f8f778c8ce41);
</script><div class="td-block-title-wrap"><h4 class="td-block-title"><a href="https://http://www.caracasdigital.com/category/tipo-de-nota/videoentrevistas/" class="td-pulldown-size">VIDEO ENTREVISTAS</a></h4></div><div id="td_uid_130_5f8f778c8ce41" class="td_block_inner td-column-1">

        <div class="td_module_mx1 td_module_wrap td-animation-stack">
            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/06/30/recomendaciones-de-trend-micro-para-teletrabajadores-en-tiempos-de-pandemia/" rel="bookmark" class="td-image-wrap" title="Recomendaciones de Trend Micro para teletrabajadores en tiempos de pandemia"><img width="356" height="220" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault-1.jpg?resize=356%2C220&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault-1.jpg?resize=356%2C220&amp;ssl=1 356w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault-1.jpg?zoom=2&amp;resize=356%2C220&amp;ssl=1 712w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault-1.jpg?zoom=3&amp;resize=356%2C220&amp;ssl=1 1068w" sizes="(max-width: 356px) 100vw, 356px" alt="" title="Recomendaciones de Trend Micro para teletrabajadores en tiempos de pandemia"><span class="td-video-play-ico"><img width="40" height="40" class="td-retina td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/themes/Newspaper/images/icons/ico-video-large@2x.png?resize=40%2C40&amp;ssl=1" alt="video" data-recalc-dims="1"></span></a></div>
            <div class="td-module-meta-info">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/06/30/recomendaciones-de-trend-micro-para-teletrabajadores-en-tiempos-de-pandemia/" rel="bookmark" title="Recomendaciones de Trend Micro para teletrabajadores en tiempos de pandemia">Recomendaciones de Trend Micro para teletrabajadores en tiempos de pandemia</a></h3>                <div class="td-editor-date">
                    <a href="https://http://www.caracasdigital.com/category/corporativo/seguridad/ciberseguridad/" class="td-post-category">Ciberseguridad</a>                    <span class="td-author-date">
                                                <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-06-30T11:01:44+00:00">30 junio, 2020</time></span>                    </span>
                </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/06/17/citrix-propone-un-espacio-de-trabajo-que-potencie-la-productividad/" rel="bookmark" class="td-image-wrap" title="Citrix propone un espacio de teletrabajo que potencie la productividad"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2020/06/maxresdefault.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Citrix propone un espacio de teletrabajo que potencie la productividad"><span class="td-video-play-ico td-video-small"><img width="20" height="20" class="td-retina td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/themes/Newspaper/images/icons/video-small@2x.png?resize=20%2C20&amp;ssl=1" alt="video" data-recalc-dims="1"></span></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/06/17/citrix-propone-un-espacio-de-trabajo-que-potencie-la-productividad/" rel="bookmark" title="Citrix propone un espacio de teletrabajo que potencie la productividad">Citrix propone un espacio de teletrabajo que potencie la productividad</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-06-17T16:43:58+00:00">17 junio, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2020/05/11/la-propuesta-tecnologica-de-ciena-para-hacer-frente-a-la-demanda-actual/" rel="bookmark" class="td-image-wrap" title="La propuesta tecnológica de Ciena para hacer frente a la demanda actual"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/maxresdefault.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/maxresdefault.jpg?resize=80%2C60&amp;ssl=1 80w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/maxresdefault.jpg?resize=265%2C198&amp;ssl=1 265w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/maxresdefault.jpg?resize=485%2C360&amp;ssl=1 485w, https://i0.wp.com/www.itwarelatam.com/wp-content/uploads/2020/05/maxresdefault.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="La propuesta tecnológica de Ciena para hacer frente a la demanda actual"><span class="td-video-play-ico td-video-small"><img width="20" height="20" class="td-retina td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/themes/Newspaper/images/icons/video-small@2x.png?resize=20%2C20&amp;ssl=1" alt="video" data-recalc-dims="1"></span></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2020/05/11/la-propuesta-tecnologica-de-ciena-para-hacer-frente-a-la-demanda-actual/" rel="bookmark" title="La propuesta tecnológica de Ciena para hacer frente a la demanda actual">La propuesta tecnológica de Ciena para hacer frente a la demanda actual</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2020-05-11T09:46:53+00:00">11 mayo, 2020</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2019/09/30/inforum-2019-los-anuncios-que-mas-impactaran-en-latinoamerica/" rel="bookmark" class="td-image-wrap" title="Inforum 2019: los anuncios que más impactarán en Latinoamérica"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-9.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-9.jpg?resize=80%2C60&amp;ssl=1 80w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-9.jpg?resize=265%2C198&amp;ssl=1 265w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-9.jpg?resize=485%2C360&amp;ssl=1 485w, https://i1.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-9.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="Inforum 2019: los anuncios que más impactarán en Latinoamérica"><span class="td-video-play-ico td-video-small"><img width="20" height="20" class="td-retina td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/themes/Newspaper/images/icons/video-small@2x.png?resize=20%2C20&amp;ssl=1" alt="video" data-recalc-dims="1"></span></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2019/09/30/inforum-2019-los-anuncios-que-mas-impactaran-en-latinoamerica/" rel="bookmark" title="Inforum 2019: los anuncios que más impactarán en Latinoamérica">Inforum 2019: los anuncios que más impactarán en Latinoamérica</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2019-09-30T17:44:42+00:00">30 septiembre, 2019</time></span>                                    </div>
            </div>

        </div>

        
        <div class="td_module_mx2 td_module_wrap td-animation-stack">

            <div class="td-module-thumb"><a href="https://http://www.caracasdigital.com/2019/09/27/la-estrategia-de-canales-de-infor-en-la-era-de-la-nube/" rel="bookmark" class="td-image-wrap" title="La estrategia de canales de Infor en la era de la Nube"><img width="80" height="60" class="entry-thumb td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-8.jpg?resize=80%2C60&amp;ssl=1" srcset="https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-8.jpg?resize=80%2C60&amp;ssl=1 80w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-8.jpg?resize=265%2C198&amp;ssl=1 265w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-8.jpg?resize=485%2C360&amp;ssl=1 485w, https://i2.wp.com/www.itwarelatam.com/wp-content/uploads/2019/09/maxresdefault-8.jpg?zoom=2&amp;resize=80%2C60&amp;ssl=1 160w" sizes="(max-width: 80px) 100vw, 80px" alt="" title="La estrategia de canales de Infor en la era de la Nube"><span class="td-video-play-ico td-video-small"><img width="20" height="20" class="td-retina td-animation-stack-type0-1" src="https://i2.wp.com/www.itwarelatam.com/wp-content/themes/Newspaper/images/icons/video-small@2x.png?resize=20%2C20&amp;ssl=1" alt="video" data-recalc-dims="1"></span></a></div>
            <div class="item-details">
                <h3 class="entry-title td-module-title"><a href="https://http://www.caracasdigital.com/2019/09/27/la-estrategia-de-canales-de-infor-en-la-era-de-la-nube/" rel="bookmark" title="La estrategia de canales de Infor en la era de la Nube">La estrategia de canales de Infor en la era de la Nube</a></h3>                <div class="td-module-meta-info">
                                                            <span class="td-post-date"><time class="entry-date updated td-module-date" datetime="2019-09-27T17:49:35+00:00">27 septiembre, 2019</time></span>                                    </div>
            </div>

        </div>

        </div></div> <!-- ./block --></div></div></div></div>
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_31_5f8f778c7cc6e .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_31_5f8f778c7cc6e .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>


<!-- ./ciberceguridad -->
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_35_5f8f778c95686 .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_35_5f8f778c95686 .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

			<div id="td_uid_38_5f8f778c9f95f" class="tdc-row"><div class="vc_row td_uid_135_5f8f778c9f968_rand  wpb_row td-pb-row">
<style scoped="">

/* custom css */
.td_uid_135_5f8f778c9f968_rand {
                    min-height: 0;
                }
</style><div class="vc_column td_uid_136_5f8f778c9fb8d_rand  wpb_column vc_column_container tdc-column td-pb-span12"><div class="wpb_wrapper"><div class="wpb_wrapper td_block_empty_space td_block_wrap vc_empty_space td_uid_137_5f8f778c9fc8c_rand " style="height: 32px"></div></div></div></div></div>
		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_38_5f8f778c9f95f .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_38_5f8f778c9f95f .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>


<!-- cobertura especial-->

		<script>

			jQuery(window).load(function () {
				jQuery('body').find('#td_uid_41_5f8f778c9fcbf .td-element-style').each(function (index, element) {
					jQuery(element).css('opacity', 1);
					return;
				});
			});

		</script>

		
			<script>

				jQuery(window).ready(function () {

					// We need timeout because the content must be rendered and interpreted on client
					setTimeout(function () {

						var $content = jQuery('body').find('#tdc-live-iframe'),
							refWindow = undefined;

						if ($content.length) {
							$content = $content.contents();
							refWindow = document.getElementById('tdc-live-iframe').contentWindow || document.getElementById('tdc-live-iframe').contentDocument;

						} else {
							$content = jQuery('body');
							refWindow = window;
						}

						$content.find('#td_uid_41_5f8f778c9fcbf .td-element-style').each(function (index, element) {
							jQuery(element).css('opacity', 1);
							return;
						});
					});

				}, 200);
			</script>

			<p></p>
                </div>
                            </div> <!-- /.td-main-content-wrap -->


            <!-- Instagram -->




	<!-- Footer -->
	<div class="td-footer-wrapper td-container-wrap td-footer-template-3 td_stretch_container">
    <div class="td-container">

	    <div class="td-pb-row">
		    <div class="td-pb-span12">
                		    </div>
	    </div>

        <div class="td-pb-row">

            <div class="td-pb-span4">
                <div class="td-footer-info"><div class="footer-logo-wrap"><a href="https://http://www.caracasdigital.com/"><img class="td-retina-data td-retina-version" src="http://www.caracasdigital.com/images/caracasdigital-nm.png" data-retina="http://www.caracasdigital.com/images/caracasdigital-nm.png" alt="ITware Latam. Noticias del sector IT en Latinoamérica." title="Noticias del sector IT en Latinoamérica" width="200"></a></div><div class="footer-text-wrap">El medio de noticias para el sector IT corporativo de Latino América.</div><div class="footer-social-wrap td-social-style-2">
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.facebook.com/ITwareLatam/" title="Facebook">
                <i class="td-icon-font td-icon-facebook"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.linkedin.com/company/itwarelatam" title="Linkedin">
                <i class="td-icon-font td-icon-linkedin"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.itwarelatam.com/feed" title="RSS">
                <i class="td-icon-font td-icon-rss"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.twitter.com/ITwareLatam" title="Twitter">
                <i class="td-icon-font td-icon-twitter"></i>
            </a>
        </span>
        <span class="td-social-icon-wrap">
            <a target="_blank" href="https://www.youtube.com/itwarelatam" title="Youtube">
                <i class="td-icon-font td-icon-youtube"></i>
            </a>
        </span></div></div><aside class="td_block_template_3 widget widget_text"><h4 class="td-block-title"><span>Quiénes somos</span></h4>			<div class="textwidget"><p><a href="https://itwarelatam.com/suscripcion/" target="new" rel="noopener noreferrer">&lrm; Suscripción </a><br>
<a href="https://itwarelatam.com/publique/" target="new" rel="noopener noreferrer">&lrm; Publique aquí </a><br>
<a href="https://itwarelatam.com/empresa/" target="new" rel="noopener noreferrer">&lrm; Nosotros </a><br>
<a href="https://itwarelatam.com/oficinas/" target="new" rel="noopener noreferrer">&lrm; Nuestras Oficinas </a><br>
<a href="https://http://www.caracasdigital.com/politicas-de-privacidad/" target="new" rel="noopener noreferrer">&lrm; Políticas de privacidad</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
		</aside>            </div>

            <div class="td-pb-span4">
                <aside class="td_block_template_3 widget widget_text">			<div class="textwidget"><p>Canales IT Canales en Argentina<br>
<a href="http://www.enfasys.net/"><img src="https://i2.wp.com/www.itwarelatam.com/nuestros_medios/enfasys.png?w=696&amp;ssl=1" alt="" width="150" height="35"></a></p>
<p>Sector Retail Latino América<br>
<a href="http://www.enretail.com/" target="new" rel="noopener noreferrer"><img src="https://i2.wp.com/www.itwarelatam.com/nuestros_medios/enretail.png?w=150&amp;ssl=1" alt="" width="150" height="35"></a></p>
<p>Sector Tecnológico Pymes en Argentina<br>
<a href="http://www.tecnopymes.com.ar/" target="new" rel="noopener noreferrer"><img src="https://i2.wp.com/www.itwarelatam.com/nuestros_medios/tecno_pymes.png?w=100&amp;ssl=1" alt="" width="100" height="23"></a></p>
<p>Canales IT en Bolivia:<br>
<a href="http://www.itseller.bo/" target="new" rel="noopener noreferrer"><img src="https://i1.wp.com/www.itwarelatam.com/nuestros_medios/itseller.png?w=150&amp;ssl=1" alt="" width="150" height="35"></a></p>
<p>Canales IT en Chile:<br>
<a href="http://www.itseller.cl/" target="new" rel="noopener noreferrer"><img src="https://i1.wp.com/www.itwarelatam.com/nuestros_medios/itseller.png?w=150&amp;ssl=1" alt="" width="150" height="35"></a></p>
<p>Sector IT Corporativo en Chile<br>
<a href="http://www.corporateit.cl/" target="new" rel="noopener noreferrer"><img src="https://i2.wp.com/www.itwarelatam.com/nuestros_medios/Coporate_it.png?w=150&amp;ssl=1" alt="" width="150" height="23"></a></p>
<p>Sector Tecnológico Pymes en Chile<br>
<a href="http://www.tecnopymes.cl/" target="new" rel="noopener noreferrer"><img src="https://i2.wp.com/www.itwarelatam.com/nuestros_medios/tecno_pymes.png?w=100&amp;ssl=1" alt="" width="100" height="23"></a></p>
<p>Sector Educación en Chile<br>
<a href="https://www.tecnoeducacion.cl/" target="new" rel="noopener noreferrer"><img src="https://i2.wp.com/www.enfasys.net/wp-content/uploads/2018/03/tecno.png?w=100&amp;ssl=1" alt="" width="100" height="38"></a></p>
</div>
		</aside>            </div>

            <div class="td-pb-span4">
                <style scoped="" type="text/css">.utcw-a86gp2j {word-wrap:break-word}.utcw-a86gp2j span,.utcw-a86gp2j a{border-width:0px}.utcw-a86gp2j span:hover,.utcw-a86gp2j a:hover{border-width:0px}</style><aside class="td_block_template_3 widget widget_utcw widget_tag_cloud"><h4 class="td-block-title"><span>Principales Temas</span></h4><div class="utcw-a86gp2j tagcloud"><a class="tag-link-1741 utcw-tag utcw-tag-5g" href="https://www.itwarelatam.com/tag/5g/" style="font-size:11.272727272727px" title="8 topics">5G</a> <a class="tag-link-191 utcw-tag utcw-tag-adquisiciones" href="https://www.itwarelatam.com/category/empresas-2/adquisiciones/" style="font-size:10.254545454545px" title="4 topics">Adquisiciones</a> <a class="tag-link-219 utcw-tag utcw-tag-alianzas" href="https://www.itwarelatam.com/category/empresas-2/alianzas/" style="font-size:10.509090909091px" title="5 topics">Alianzas</a> <a class="tag-link-205 utcw-tag utcw-tag-avaya" href="https://www.itwarelatam.com/tag/avaya/" style="font-size:10.254545454545px" title="4 topics">Avaya</a> <a class="tag-link-155 utcw-tag utcw-tag-canales" href="https://www.itwarelatam.com/category/canales/" style="font-size:11.527272727273px" title="9 topics">Canales</a> <a class="tag-link-6686 utcw-tag utcw-tag-ciberseguridad" href="https://www.itwarelatam.com/category/corporativo/seguridad/ciberseguridad/" style="font-size:24px" title="58 topics">Ciberseguridad</a> <a class="tag-link-199 utcw-tag utcw-tag-cloud" href="https://www.itwarelatam.com/category/corporativo/cloud/" style="font-size:13.563636363636px" title="17 topics">Cloud</a> <a class="tag-link-835 utcw-tag utcw-tag-colaboracion" href="https://www.itwarelatam.com/category/corporativo/infraestructura/comunicaciones/colaboracion/" style="font-size:10.509090909091px" title="5 topics">Colaboración</a> <a class="tag-link-424 utcw-tag utcw-tag-comercio-electronico" href="https://www.itwarelatam.com/category/empresas-2/comercio-electronico/" style="font-size:11.272727272727px" title="8 topics">Comercio Electrónico</a> <a class="tag-link-6886 utcw-tag utcw-tag-covid-19" href="https://www.itwarelatam.com/tag/covid-19/" style="font-size:10.763636363636px" title="6 topics">COVID-19</a> <a class="tag-link-226 utcw-tag utcw-tag-data-centers" href="https://www.itwarelatam.com/category/corporativo/data-centers/" style="font-size:11.272727272727px" title="8 topics">Data Centers</a> <a class="tag-link-7135 utcw-tag utcw-tag-diego-di-giorno" href="https://www.itwarelatam.com/tag/diego-di-giorno/" style="font-size:11.781818181818px" title="10 topics">Diego Di Giorno</a> <a class="tag-link-6842 utcw-tag utcw-tag-ecommerce-institute" href="https://www.itwarelatam.com/tag/ecommerce-institute/" style="font-size:11.272727272727px" title="8 topics">eCommerce Institute</a> <a class="tag-link-1305 utcw-tag utcw-tag-empresas-2" href="https://www.itwarelatam.com/category/empresas-2/" style="font-size:14.072727272727px" title="19 topics">Empresas</a> <a class="tag-link-195 utcw-tag utcw-tag-eventos" href="https://www.itwarelatam.com/category/tipo-de-nota/eventos/" style="font-size:18.4px" title="36 topics">Eventos</a> <a class="tag-link-4400 utcw-tag utcw-tag-forcepoint" href="https://www.itwarelatam.com/tag/forcepoint/" style="font-size:10.254545454545px" title="4 topics">Forcepoint</a> <a class="tag-link-334 utcw-tag utcw-tag-fortinet" href="https://www.itwarelatam.com/tag/fortinet/" style="font-size:10.509090909091px" title="5 topics">Fortinet</a> <a class="tag-link-305 utcw-tag utcw-tag-hardware" href="https://www.itwarelatam.com/category/productos/hardware/" style="font-size:11.272727272727px" title="8 topics">Hardware</a> <a class="tag-link-2257 utcw-tag utcw-tag-hp-inc" href="https://www.itwarelatam.com/tag/hp-inc/" style="font-size:10.254545454545px" title="4 topics">HP Inc.</a> <a class="tag-link-558 utcw-tag utcw-tag-huawei" href="https://www.itwarelatam.com/tag/huawei/" style="font-size:10.509090909091px" title="5 topics">Huawei</a> <a class="tag-link-352 utcw-tag utcw-tag-ibm" href="https://www.itwarelatam.com/tag/ibm/" style="font-size:10.763636363636px" title="6 topics">IBM</a> <a class="tag-link-250 utcw-tag utcw-tag-infor" href="https://www.itwarelatam.com/tag/infor/" style="font-size:10.763636363636px" title="6 topics">Infor</a> <a class="tag-link-151 utcw-tag utcw-tag-infraestructura" href="https://www.itwarelatam.com/category/corporativo/infraestructura/" style="font-size:10.254545454545px" title="4 topics">Infraestructura</a> <a class="tag-link-331 utcw-tag utcw-tag-intel" href="https://www.itwarelatam.com/tag/intel/" style="font-size:10.254545454545px" title="4 topics">Intel</a> <a class="tag-link-4012 utcw-tag utcw-tag-inteligencia-artificial" href="https://www.itwarelatam.com/tag/inteligencia-artificial/" style="font-size:11.018181818182px" title="7 topics">Inteligencia Artificial</a> <a class="tag-link-234 utcw-tag utcw-tag-iot" href="https://www.itwarelatam.com/category/tipo-de-nota/iot/" style="font-size:10px" title="3 topics">Internet of Things</a> <a class="tag-link-4365 utcw-tag utcw-tag-kaspersky" href="https://www.itwarelatam.com/tag/kaspersky/" style="font-size:10.254545454545px" title="4 topics">Kaspersky</a> <a class="tag-link-6061 utcw-tag utcw-tag-kubernetes" href="https://www.itwarelatam.com/tag/kubernetes/" style="font-size:10.509090909091px" title="5 topics">Kubernetes</a> <a class="tag-link-524 utcw-tag utcw-tag-licencias-online" href="https://www.itwarelatam.com/tag/licencias-online/" style="font-size:11.018181818182px" title="7 topics">Licencias OnLine</a> <a class="tag-link-3703 utcw-tag utcw-tag-marcos-pueyrredon" href="https://www.itwarelatam.com/tag/marcos-pueyrredon/" style="font-size:10.509090909091px" title="5 topics">Marcos Pueyrredon</a> <a class="tag-link-212 utcw-tag utcw-tag-microsoft" href="https://www.itwarelatam.com/tag/microsoft/" style="font-size:10.763636363636px" title="6 topics">Microsoft</a> <a class="tag-link-149 utcw-tag utcw-tag-movilidad" href="https://www.itwarelatam.com/category/productos/movilidad/" style="font-size:11.018181818182px" title="7 topics">Movilidad</a> <a class="tag-link-264 utcw-tag utcw-tag-nombramiento" href="https://www.itwarelatam.com/category/empresas-2/nombramiento/" style="font-size:12.545454545455px" title="13 topics">Nombramientos</a> <a class="tag-link-387 utcw-tag utcw-tag-nvidia" href="https://www.itwarelatam.com/tag/nvidia/" style="font-size:10px" title="3 topics">nVIDIA</a> <a class="tag-link-974 utcw-tag utcw-tag-opinion" href="https://www.itwarelatam.com/category/tipo-de-nota/opinion/" style="font-size:19.672727272727px" title="41 topics">Opinion</a> <a class="tag-link-418 utcw-tag utcw-tag-ransomware" href="https://www.itwarelatam.com/tag/ransomware/" style="font-size:11.272727272727px" title="8 topics">Ransomware</a> <a class="tag-link-200 utcw-tag utcw-tag-red-hat" href="https://www.itwarelatam.com/tag/red-hat/" style="font-size:10.509090909091px" title="5 topics">Red Hat</a> <a class="tag-link-152 utcw-tag utcw-tag-software_y_servicios" href="https://www.itwarelatam.com/category/software_y_servicios/" style="font-size:11.018181818182px" title="7 topics">Software &amp; Servicios</a> <a class="tag-link-346 utcw-tag utcw-tag-telecomunicaciones" href="https://www.itwarelatam.com/category/corporativo/telecomunicaciones/" style="font-size:11.018181818182px" title="7 topics">Telecomunicaciones</a> <a class="tag-link-2675 utcw-tag utcw-tag-teletrabajo" href="https://www.itwarelatam.com/tag/teletrabajo/" style="font-size:10.254545454545px" title="4 topics">Teletrabajo</a> <a class="tag-link-951 utcw-tag utcw-tag-veeam" href="https://www.itwarelatam.com/tag/veeam/" style="font-size:11.272727272727px" title="8 topics">Veeam</a> <a class="tag-link-4285 utcw-tag utcw-tag-vertiv" href="https://www.itwarelatam.com/tag/vertiv/" style="font-size:11.272727272727px" title="8 topics">Vertiv</a> <a class="tag-link-248 utcw-tag utcw-tag-vmware" href="https://www.itwarelatam.com/tag/vmware/" style="font-size:11.527272727273px" title="9 topics">VmWare</a> <a class="tag-link-7089 utcw-tag utcw-tag-world-compliance-association" href="https://www.itwarelatam.com/tag/world-compliance-association/" style="font-size:12.290909090909px" title="12 topics">WORLD COMPLIANCE ASSOCIATION</a></div></aside>            </div>
        </div>
    </div>
</div>
	<!-- Sub Footer -->
	    <div class="td-sub-footer-container td-container-wrap td_stretch_container">
        <div class="td-container">
            <div class="td-pb-row">
                <div class="td-pb-span td-sub-footer-menu">
                                    </div>

                <div class="td-pb-span td-sub-footer-copy">
                    © 2018 Mediaware Marketing. Todos los derechos reservados.  Diseñado por DiseniaBox                </div>
            </div>
        </div>
    </div>


</div><iframe id="google_osd_static_frame_8032448411192" name="google_osd_static_frame" style="display: none; width: 0px; height: 0px;"></iframe><!--close td-outer-wrap-->

        <script type="text/javascript">
            if ( document.querySelector('.g-recaptcha.jp-recaptcha') ) {
                var appendJS = function(){
                    var js, b = document.body;
                    js = document.createElement('script');
                    js.type = 'text/javascript';
                    js.src = 'https://www.google.com/recaptcha/api.js?hl=es-419';
                    b.appendChild(js);
                }
                if(window.attachEvent) {
                    window.attachEvent('onload', appendJS);
                } else {
                    if(window.onload) {
                        var curronload = window.onload;
                        var newonload = function(evt) {
                            curronload(evt);
                            appendJS(evt);
                        };
                        window.onload = newonload;
                    } else {
                        window.onload = appendJS;
                    }
                }
            }
        </script>
        

    <!--

        Theme: Newspaper by tagDiv.com 2017
        Version: 9.0.1 (rara)
        Deploy mode: deploy
        
        uid: 5f8f778d2b878
    -->

    
<!-- Custom css form theme panel -->
<style type="text/css" media="screen">
/* custom css theme panel */
.td-main-page-wrap {
    padding-top: 0px;
}
</style>

<div class="td-container">

	<!-- <script src="https://www.google.com/recaptcha/api.js"></script> -->
<script src="https://cdn.embluemail.com/pixeltracking/pixeltracking.js?code=25a47f42782cbfe1b987f565cb58a484"></script>

</div>
<div style="position:fixed;bottom: -999999999999999999999px;"></div>

<link rel="stylesheet" id="font-awesome-css" href="https://www.itwarelatam.com/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=6.0.5" type="text/css" media="all">
<script type="text/javascript" src="https://c0.wp.com/p/jetpack/9.0.2/_inc/build/photon/photon.min.js" id="jetpack-photon-js"></script>
<script type="text/javascript" id="leadin-script-loader-js-js-extra">
/* <![CDATA[ */
var leadin_wordpress = {"userRole":"visitor","pageType":"home","leadinPluginVersion":"7.45.4"};
/* ]]> */
</script>
<script async="" defer="" id="hs-script-loader" type="text/javascript" src="//js.hs-scripts.com/7620000.js?integration=WordPress"></script>
<script type="text/javascript" src="https://www.itwarelatam.com/wp-content/themes/Newspaper/js/tagdiv_theme.min.js?ver=9.0.1" id="td-site-min-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/5.5.1/wp-includes/js/comment-reply.min.js" id="comment-reply-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/5.5.1/wp-includes/js/wp-embed.min.js" id="wp-embed-js"></script>
<script type="text/javascript" src="https://cdn.onesignal.com/sdks/OneSignalSDK.js?ver=5.5.1" async="async" id="remote_sdk-js"></script>
<script type="text/javascript" src="https://www.itwarelatam.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.0.5" id="wpb_composer_front_js-js"></script>

<!-- JS generated by theme -->

<script>
    

	

		// (function(){
		// 	var html_jquery_obj = jQuery('html');

		// 	if (html_jquery_obj.length && (html_jquery_obj.is('.ie8') || html_jquery_obj.is('.ie9'))) {

		// 		var path = 'https://www.itwarelatam.com/wp-content/themes/Newspaper/style.css';

		// 		jQuery.get(path, function(data) {

		// 			var str_split_separator = '#td_css_split_separator';
		// 			var arr_splits = data.split(str_split_separator);
		// 			var arr_length = arr_splits.length;

		// 			if (arr_length > 1) {

		// 				var dir_path = 'https://www.itwarelatam.com/wp-content/themes/Newspaper';
		// 				var splited_css = '';

		// 				for (var i = 0; i < arr_length; i++) {
		// 					if (i > 0) {
		// 						arr_splits[i] = str_split_separator + ' ' + arr_splits[i];
		// 					}
		// 					//jQuery('head').append('<style>' + arr_splits[i] + '</style>');

		// 					var formated_str = arr_splits[i].replace(/\surl\(\'(?!data\:)/gi, function regex_function(str) {
		// 						return ' url(\'' + dir_path + '/' + str.replace(/url\(\'/gi, '').replace(/^\s+|\s+$/gm,'');
		// 					});

		// 					splited_css += "<style>" + formated_str + "</style>";
		// 				}

		// 				var td_theme_css = jQuery('link#td-theme-css');

		// 				if (td_theme_css.length) {
		// 					td_theme_css.after(splited_css);
		// 				}
		// 			}
		// 		});
		// 	}
		// })();

	
	
</script>

<script type="text/javascript" src="https://stats.wp.com/e-202043.js" async="async" defer="defer"></script>
<script type="text/javascript">
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:9.0.2',blog:'70460424',post:'19946',tz:'-3',srv:'www.itwarelatam.com'} ]);
	_stq.push([ 'clickTrackerInit', '70460424', '19946' ]);
</script>


			<div id="tdw-css-writer" style="display: none" class="tdw-drag-dialog tdc-window-sidebar">
				<header>

				
					<a title="Editor" class="tdw-tab tdc-tab-active" href="#" data-tab-content="tdw-tab-editor">Edit with Live CSS</a>
					<div class="tdw-less-info" title="This will be red when errors are detected in your CSS and LESS"></div>
				
				</header>
				<div class="tdw-content">

					
					<div class="tdw-tabs-content tdw-tab-editor tdc-tab-content-active">


						<script>

							(function(jQuery, undefined) {

								jQuery(window).ready(function() {

									if ( 'undefined' !== typeof tdcAdminIFrameUI ) {
										var $liveIframe  = tdcAdminIFrameUI.getLiveIframe();

										if ( $liveIframe.length ) {
											$liveIframe.load(function() {
												$liveIframe.contents().find( 'body').append( '<textarea class="tdw-css-writer-editor" style="display: none"></textarea>' );
											});
										}
									}

								});

							})(jQuery);

						</script>


						<textarea class="tdw-css-writer-editor td_live_css_uid_1_5f8f778d2c38c"></textarea>
						<div id="td_live_css_uid_1_5f8f778d2c38c" class="td-code-editor"></div>


						<script>
							jQuery(window).load(function (){

								if ( 'undefined' !== typeof tdLiveCssInject ) {

									tdLiveCssInject.init();


									var editor_textarea = jQuery('.td_live_css_uid_1_5f8f778d2c38c');
									var languageTools = ace.require("ace/ext/language_tools");
									var tdcCompleter = {
										getCompletions: function (editor, session, pos, prefix, callback) {
											if (prefix.length === 0) {
												callback(null, []);
												return
											}

											if ('undefined' !== typeof tdcAdminIFrameUI) {

												var data = {
													error: undefined,
													getShortcode: ''
												};

												tdcIFrameData.getShortcodeFromData(data);

												if (!_.isUndefined(data.error)) {
													tdcDebug.log(data.error);
												}

												if (!_.isUndefined(data.getShortcode)) {

													var regex = /el_class=\"([A-Za-z0-9_-]*\s*)+\"/g,
														results = data.getShortcode.match(regex);

													var elClasses = {};

													for (var i = 0; i < results.length; i++) {
														var currentClasses = results[i]
															.replace('el_class="', '')
															.replace('"', '')
															.split(' ');

														for (var j = 0; j < currentClasses.length; j++) {
															if (_.isUndefined(elClasses[currentClasses[j]])) {
																elClasses[currentClasses[j]] = '';
															}
														}
													}

													var arrElClasses = [];

													for (var prop in elClasses) {
														arrElClasses.push(prop);
													}

													callback(null, arrElClasses.map(function (item) {
														return {
															name: item,
															value: item,
															meta: 'in_page'
														}
													}));
												}
											}
										}
									};
									languageTools.addCompleter(tdcCompleter);

									window.editor = ace.edit("td_live_css_uid_1_5f8f778d2c38c");

									// 'change' handler is written as function because it's called by tdc_on_add_css_live_components (of wp_footer hook)
									// We did it to reattach the existing compiled css to the new content received from server.
									window.editorChangeHandler = function () {
										//tdwState.lessWasEdited = true;

										window.onbeforeunload = function () {
											if (tdwState.lessWasEdited) {
												return "You have attempted to leave this page. Are you sure?";
											}
											return false;
										};

										var editorValue = editor.getSession().getValue();

										editor_textarea.val(editorValue);

										if ('undefined' !== typeof tdcAdminIFrameUI) {
											tdcAdminIFrameUI.getLiveIframe().contents().find('.tdw-css-writer-editor:first').val(editorValue);

											// Mark the content as modified
											// This is important for showing info when composer closes
                                            tdcMain.setContentModified();
										}

										tdLiveCssInject.less();
									};

									editor.getSession().setValue(editor_textarea.val());
									editor.getSession().on('change', editorChangeHandler);

									editor.setTheme("ace/theme/textmate");
									editor.setShowPrintMargin(false);
									editor.getSession().setMode("ace/mode/less");
									editor.setOptions({
										enableBasicAutocompletion: true,
										enableSnippets: true,
										enableLiveAutocompletion: false
									});

								}

							});
						</script>

					</div>
				</div>

				<footer>

					
						<a href="#" class="tdw-save-css">Save</a>
						<div class="tdw-more-info-text">Write CSS OR LESS and hit save. CTRL + SPACE for auto-complete.</div>

					
					<div class="tdw-resize"></div>
				</footer>
			</div>
			



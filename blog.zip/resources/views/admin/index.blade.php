<?php 

if($_REQUEST){

	print_r($datos);

}else{
	echo "Hola Mundo estare modificando por aqui ";
	echo "<BR>tiwter</br> ";
	echo "Facebook ";
	echo "Facebook Nuevo Cambio";
	echo '<h1 style="color:blue;backgorund-color:green;" >Facebook Nuevo Cambio<h1>';
	echo '<h3 style="color:blue;backgorund-color:green;" >Facebook Nuevo Cambio<h3>';

}

?>
<!DOCTYPE html>
<html>
<head>
	<title>GitHub</title>
</head>
<body>


<content>
	<h2>GitHub</h2>
	<form>
		<input placeholder="Usuario">
		<input placeholder="Clave">


	</form>

</content>

</body>
</html>